import * as THREE from 'three';
import type { Actor, HitGroup } from './Actor';
import { computeDamage } from './Actor';
import type { WeaponDef } from '../data/weapons';
import type { GameSession } from './GameSession';
import { audio } from '../core/Audio';
import { clamp, dirFromYawPitch } from '../core/util';

const _o = new THREE.Vector3(), _d = new THREE.Vector3(), _r = new THREE.Vector3(), _u = new THREE.Vector3();

export function inaccuracy(a: Actor, def: WeaponDef, scoped: boolean) {
  const sp = Math.hypot(a.vel.x, a.vel.z);
  const moveF = clamp((sp - def.speed * 0.36) / (def.speed * 0.64), 0, 1);
  let inacc = def.spread + moveF * def.moveSpread + (a.onGround ? 0 : def.airSpread) + a.spreadHeat;
  if (a.crouch > 0.5) inacc *= 0.72;
  if (def.scope && !scoped) inacc += 0.07;
  return inacc;
}

/** random direction inside a cone */
export function perturb(dir: THREE.Vector3, angle: number, out = new THREE.Vector3()) {
  _r.set(0, 1, 0).cross(dir);
  if (_r.lengthSq() < 1e-6) _r.set(1, 0, 0);
  _r.normalize();
  _u.copy(dir).cross(_r).normalize();
  const a = Math.random() * Math.PI * 2;
  const m = Math.sqrt(Math.random()) * Math.tan(angle);
  return out.copy(dir).addScaledVector(_r, Math.cos(a) * m).addScaledVector(_u, Math.sin(a) * m).normalize();
}

/** CS-like spray pattern: returns [pitchUp, yaw] offset in radians for shot index */
export function recoilOffset(def: WeaponDef, idx: number): [number, number] {
  const i = Math.min(idx, 30);
  const up = def.recoilUp * Math.min(i, 9) * (1 - Math.max(0, i - 9) * 0.0) + def.recoilUp * 0.25 * Math.max(0, i - 9);
  const side = def.recoilSide * (i < 6 ? Math.sin(i * 0.6) * 0.4 : Math.sin(i * 0.42 + 1.5) * 3.2 + Math.cos(i * 0.9) * 0.6);
  return [up, side];
}

/** fire a hitscan weapon. dir must already include recoil. returns true if an enemy was hit */
export function fireBullets(s: GameSession, a: Actor, dir: THREE.Vector3, def: WeaponDef, scoped: boolean, muzzle: THREE.Vector3 | null) {
  const eye = a.eyePos(_o).clone();
  const pellets = def.pellets ?? 1;
  const inacc = inaccuracy(a, def, scoped) * (a.isPlayer ? 1 : 1.0);
  let hitEnemy = false;
  const range = def.range ?? 250;
  for (let p = 0; p < pellets; p++) {
    const d = perturb(dir, pellets > 1 ? def.spread + inacc * 0.4 : inacc, _d).clone();
    const wh = s.collision.raycast(eye, d, range);
    const maxT = wh ? wh.t : range;
    let best: { actor: Actor; t: number; group: HitGroup } | null = null;
    for (const v of s.actors) {
      if (v === a || !v.alive || v.team === a.team) continue;
      const h = v.hitTest(eye, d, maxT);
      if (h && (!best || h.t < best.t)) best = { actor: v, t: h.t, group: h.group };
    }
    const end = eye.clone().addScaledVector(d, best ? best.t : maxT);
    if (best) {
      const dmg = computeDamage(def, def.damage, best.group, best.t, best.actor);
      s.effects.bloodHit(end, d, best.group === 'head');
      // blood splat on the wall behind
      const behind = s.collision.raycast(end, d, 3);
      if (behind && Math.random() < 0.6) s.effects.bloodSplat(behind.point, behind.normal);
      s.damage(best.actor, a, dmg.hp, dmg.armor, def.id, best.group, eye);
      hitEnemy = true;
    } else if (wh) {
      s.effects.impact(wh.point, wh.normal, wh.box.surf);
      audio.impact(wh.point, wh.box.surf);
    }
    if (p === 0 && def.tracer !== false && (Math.random() < (a.isPlayer ? 0.35 : 0.6))) {
      const from = muzzle ? muzzle.clone() : eye.clone().addScaledVector(d, 0.8);
      s.effects.tracer(from, end);
    }
    if (pellets > 1 && p > 2) continue;
  }
  // sound + noise for bots
  audio.shot(def.sound as any, a.isPlayer ? null : eye, a.isPlayer);
  s.noise(a, a.pos, def.silenced ? 12 : 45);
  return hitEnemy;
}

/** knife attack, returns true if hit */
export function knifeAttack(s: GameSession, a: Actor, heavy: boolean) {
  const eye = a.eyePos(_o).clone();
  const d = dirFromYawPitch(a.yaw, a.pitch);
  const reach = 2.0;
  let best: { actor: Actor; t: number } | null = null;
  for (const v of s.actors) {
    if (v === a || !v.alive || v.team === a.team) continue;
    // generous melee cone
    const to = v.pos.clone().add(new THREE.Vector3(0, 1.1, 0)).sub(eye);
    const dist = to.length();
    if (dist > reach + 0.4) continue;
    to.normalize();
    if (to.dot(d) < 0.72) continue;
    if (!best || dist < best.t) best = { actor: v, t: dist };
  }
  if (best) {
    const v = best.actor;
    const vf = dirFromYawPitch(v.yaw, 0);
    const back = vf.dot(new THREE.Vector3(d.x, 0, d.z).normalize()) > 0.5;
    const base = heavy ? (back ? 180 : 65) : (back ? 90 : 40);
    const armored = v.armor > 0;
    const hp = Math.round(base * (armored ? 0.85 : 1));
    s.effects.bloodHit(v.pos.clone().add(new THREE.Vector3(0, 1.2, 0)), d, false);
    s.damage(v, a, hp, armored ? Math.round(base * 0.075) : 0, 'knife', 'chest', eye);
    audio.knifeSwing(true);
    return true;
  }
  const wh = s.collision.raycast(eye, d, reach);
  if (wh) { s.effects.impact(wh.point, wh.normal, wh.box.surf); audio.knifeSwing(true); }
  else audio.knifeSwing(false);
  return false;
}
