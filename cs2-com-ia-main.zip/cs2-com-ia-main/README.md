# CS2 com IA: Claude vs Codex

Dois jogos de tiro tático em 3D para navegador, um criado pelo Claude e outro pelo Codex, a partir do mesmo desafio.

![Gameplay](docs/gameplay.png)

## Jogar agora

- [Versão Claude](https://paulogalletti.com.br/jogos/opus/)
- [Versão Codex](https://paulogalletti.com.br/jogos/astra/)
- [Sobre o experimento](https://paulogalletti.com.br/experimentos/cs2-com-ia/)
- [Vídeo: Claude vs Codex](https://paulogalletti.com.br/videos/cs2-claude-vs-codex/)

## Rodar localmente

Requer [Node.js](https://nodejs.org/) 18 ou superior.

```bash
cd claude   # ou: cd codex
npm install
npm run dev
```

## Conteúdo

| Pasta | Projeto |
| --- | --- |
| [`claude/`](claude/) | Versão do Claude |
| [`codex/`](codex/) | Versão do Codex |

Feito com TypeScript, Three.js e Vite. Os recursos deste repositório são gerados em código.

## Acompanhe

Mais experimentos no [canal do YouTube](https://www.youtube.com/@PauloGalletti8) e em [paulogalletti.com.br](https://paulogalletti.com.br/).

## Licença e aviso

Código sob licença [MIT](LICENSE). Projeto independente, sem afiliação com a Valve. Counter-Strike é marca de seus respectivos titulares.
