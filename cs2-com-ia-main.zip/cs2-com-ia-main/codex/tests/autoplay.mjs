import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

const base = process.env.TEST_URL || 'http://127.0.0.1:4173';
const seed = Number(process.env.AUTOPLAY_SEED || 2);
const maxSteps = 15000;
const dt = .1;
const browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-webgl'] });
const errors = [];
let report;

try {
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(base);
  await page.waitForFunction(() => window.game);
  await page.evaluate(async ({ seed, dt }) => {
    const g = window.game;
    g.testMode = true;
    // Rendering allocates Three.js UUIDs with Math.random as well. Stop its RAF
    // loop before seeding so headless rendering cannot perturb AI randomness.
    window.requestAnimationFrame = () => 0;
    await new Promise(resolve => setTimeout(resolve, 50));
    // Accelerated time must not enqueue thousands of real-time audio nodes.
    for (const name of Object.getOwnPropertyNames(Object.getPrototypeOf(g.audio))) {
      if (name !== 'constructor' && typeof g.audio[name] === 'function') g.audio[name] = () => {};
    }
    let randomSeed = seed >>> 0;
    Math.random = () => {
      randomSeed = (Math.imul(randomSeed, 1664525) + 1013904223) >>> 0;
      return randomSeed / 4294967296;
    };
    await g.start({ team: 'CT', size: 5, difficulty: 'hard', practice: false });
    g.paused = true;
    g.elapsed = 0;
    window.autoplay = {
      seed, dt, steps: 0, seconds: 0, rounds: [], plants: [], defuses: 0,
      blockers: [], roundSeen: 0, plantedSeen: false, endSeen: false,
      motion: {}, stalled: {}, metrics: {},
    };
  }, { seed, dt });

  for (let first = 0; first < maxSteps; first += 500) {
    const progress = await page.evaluate(({ count, dt }) => {
      const g = window.game, a = window.autoplay;
      for (let i = 0; i < count; i++) {
        if (g.screen === 'result') break;
        if (a.roundSeen !== g.round) {
          a.roundSeen = g.round;
          a.plantedSeen = false;
          a.endSeen = false;
          a.motion = {};
          a.stalled = {};
          // Human is an inactive spectator; all bot decisions and winners remain natural.
          g.player.alive = false;
          g.player.health = 0;
          g.player.deaths++;
        }
        // Rendering may run between batches; AI time always follows simulation time.
        g.elapsed = (a.steps + 1) * dt;
        g.updateBots(dt);
        g.updateGrenades(dt);
        g.updateRound(dt);
        g.updateEffects(dt);
        a.steps++;
        a.seconds += dt;
        if (g.bomb.planted && !a.plantedSeen) {
          a.plantedSeen = true;
          a.plants.push({ round: g.round, at: +a.seconds.toFixed(1),
            site: g.nearestSite(g.bomb.pos), planter: g.bomb.planter?.name,
            position: g.bomb.pos.toArray() });
        }
        for (const b of g.bots) {
          const metric = a.metrics[b.id] ||= { id: b.id, name: b.name, team: b.team,
            distance: 0, maxRouteIndex: 0, attackTicks: 0, plantTicks: 0, defuseTicks: 0 };
          const last = a.motion[b.id];
          if (last) metric.distance += Math.hypot(b.pos.x - last.x, b.pos.z - last.z);
          metric.maxRouteIndex = Math.max(metric.maxRouteIndex, b.routeIndex || 0);
          if (b.state === 'Attack') metric.attackTicks++;
          if (b.state === 'PlantBomb') metric.plantTicks++;
          if (b.state === 'DefuseBomb') metric.defuseTicks++;
          // Ts reaching their post-plant cover are expected to hold position.
          const defendingCover = g.bomb.planted && b.team === 'T';
          const idle = g.phase === 'combat' && b.alive && !b.target && !defendingCover &&
            !['PlantBomb', 'DefuseBomb'].includes(b.state) && last &&
            Math.hypot(b.pos.x - last.x, b.pos.z - last.z) < .002;
          const stationary = idle ? last.stationary + dt : 0;
          a.motion[b.id] = { x: b.pos.x, z: b.pos.z, stationary };
          if (stationary > 20 && !a.stalled[b.id]) {
            a.stalled[b.id] = true;
            a.blockers.push({ round: g.round, at: +a.seconds.toFixed(1), bot: b.name,
              team: b.team, state: b.state, position: b.pos.toArray(),
              goal: b.goal?.toArray(), routeIndex: b.routeIndex,
              route: b.route?.map(p => p.toArray()), pathLength: b.path?.length });
          }
        }
        if (g.phase === 'end' && !a.endSeen) {
          a.endSeen = true;
          if (g.bomb.defused) a.defuses++;
          a.rounds.push({ round: g.round, at: +a.seconds.toFixed(1), winner: g.roundWinner,
            reason: g.roundReason, score: { ...g.score }, planted: g.bomb.planted,
            defused: g.bomb.defused,
            alive: { T: g.actors().filter(b => b.alive && b.team === 'T').length,
              CT: g.actors().filter(b => b.alive && b.team === 'CT').length },
            kills: g.bots.reduce((n, b) => n + b.kills, 0) });
        }
      }
      return { steps: a.steps, seconds: Math.round(a.seconds), round: g.round,
        score: { ...g.score }, screen: g.screen, plants: a.plants.length,
        defuses: a.defuses, blockers: a.blockers.length };
    }, { count: Math.min(500, maxSteps - first), dt });
    console.log('AUTOPLAY', JSON.stringify(progress));
    if (progress.screen === 'result') break;
  }

  report = await page.evaluate(() => {
    const g = window.game, a = window.autoplay;
    return { seed: a.seed, stepSeconds: a.dt, steps: a.steps,
      simulationSeconds: +a.seconds.toFixed(1), matchFinished: g.matchFinished,
      screen: g.screen, score: { ...g.score }, rounds: a.rounds, plants: a.plants,
      defuses: a.defuses, blockers: a.blockers, metrics: Object.values(a.metrics),
      finalBots: g.bots.map(b => ({ id: b.id, name: b.name, team: b.team, alive: b.alive,
        position: b.pos.toArray(), state: b.state, kills: b.kills, deaths: b.deaths,
        routeIndex: b.routeIndex, goal: b.goal?.toArray(), pathLength: b.path?.length })) };
  });
  report.errors = errors;
  await fs.mkdir('artifacts', { recursive: true });
  await fs.writeFile('artifacts/autoplay.json', JSON.stringify(report, null, 2));
  assert.deepEqual(errors, [], 'no fatal browser errors during accelerated gameplay');
  assert.equal(report.matchFinished, true, 'natural match reaches seven wins');
  assert.equal(report.screen, 'result', 'natural match enters result screen');
  assert.ok(report.rounds.length >= 7, 'multiple complete round lifecycles ran');
  assert.ok(report.finalBots.some(b => b.kills > 0), 'bots naturally fought and eliminated opponents');
  assert.ok(report.plants.length > 0, 'bot carrier naturally navigated to a site and planted');
  assert.ok(report.defuses > 0, 'CT bots naturally reached and completed a defuse');
  assert.equal(report.blockers.length, 0, 'bots do not stall indefinitely while navigating');
  console.log(`PASS natural match ${report.score.T}:${report.score.CT}, ${report.rounds.length} rounds, ` +
    `${report.plants.length} plants, ${report.defuses} defuses, ${report.simulationSeconds}s simulated`);
} catch (error) {
  console.error(error);
  process.exitCode = 1;
  if (!report) {
    await fs.mkdir('artifacts', { recursive: true });
    await fs.writeFile('artifacts/autoplay.json', JSON.stringify({ error: String(error), errors }, null, 2));
  }
} finally {
  await browser.close();
}
