import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import ts from 'typescript';
import * as THREE from 'three';

// Textures do not need a GPU for geometry, navigation or raycast regression tests.
const previousDocument = globalThis.document;
globalThis.document = {
  createElement() {
    return { width: 0, height: 0, getContext() {
      return new Proxy({}, {
        get: (target, key) => target[key] ?? (() => {}),
        set: (target, key, value) => (target[key] = value, true),
      });
    } };
  },
};

async function importSource(relativePath) {
  const source = await readFile(new URL(relativePath, import.meta.url), 'utf8');
  let js = ts.transpileModule(source, { compilerOptions: {
    target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext,
  } }).outputText;
  js = js.replace(/from ['"]three['"]/g,
    `from '${new URL('../node_modules/three/build/three.module.js', import.meta.url).href}'`);
  js = js.replace(/from ['"]three\/addons\/utils\/BufferGeometryUtils.js['"]/g,
    `from '${new URL('../node_modules/three/examples/jsm/utils/BufferGeometryUtils.js', import.meta.url).href}'`);
  return import('data:text/javascript;base64,' + Buffer.from(js).toString('base64'));
}

const { createWorld } = await importSource('../src/world.ts');
const { Navigation, moveBody, blocked } = await importSource('../src/navigation.ts');
const world = createWorld();
globalThis.document = previousDocument;
const navigation = new Navigation(world.colliders);
world.group.updateMatrixWorld(true);

test('both teams can physically follow navigation paths to both bombsites', () => {
  for (const [team, spawn] of Object.entries(world.spawns)) {
    assert.equal(blocked(spawn.x, spawn.z, world.colliders), false, `${team} spawn is clear`);
    for (const [site, destination] of Object.entries(world.sites)) {
      const position = spawn.clone();
      const path = navigation.path(position, destination);
      assert.ok(path.length, `${team} has a route to ${site}`);
      let step = 0;
      for (; step < 2000 && path.length; step++) {
        const direction = path[0].clone().sub(position);
        if (direction.length() < .35) path.shift();
        else {
          direction.normalize();
          moveBody(position, direction.x * .112, direction.z * .112, world.colliders);
        }
      }
      assert.equal(path.length, 0, `${team} did not get stuck reaching ${site}`);
      assert.ok(position.distanceTo(destination) < .4, `${team} reached the actual ${site} position`);
    }
  }
});

test('each main gateway passes eye-level rays and its upper arch stops bullets', () => {
  const gateways = [
    { at: new THREE.Vector3(0, 1.65, -18), direction: new THREE.Vector3(0, 0, -1) },
    { at: new THREE.Vector3(25.5, 1.65, 20), direction: new THREE.Vector3(0, 0, -1) },
    { at: new THREE.Vector3(-25.9, 1.65, 18), direction: new THREE.Vector3(0, 0, -1) },
    { at: new THREE.Vector3(-18, 1.65, .25), direction: new THREE.Vector3(-1, 0, 0) },
  ];
  for (const { at, direction } of gateways) {
    const ray = new THREE.Raycaster(at, direction, 0, 4);
    assert.equal(ray.intersectObjects(world.solidMeshes, false).length, 0,
      `opening at ${at.toArray()} stays open after geometry batching`);
  }
  const upper = new THREE.Raycaster(new THREE.Vector3(0, 6.6, -18), new THREE.Vector3(0, 0, -1), 0, 4);
  assert.ok(upper.intersectObjects(world.solidMeshes, false).length, 'upper arch is solid');
});

test('architectural detail is batched and collision boxes remain well formed', () => {
  let meshes = 0;
  world.group.traverse(object => { if (object.isMesh) meshes++; });
  assert.ok(meshes < 100, `static map uses ${meshes} draws`);
  assert.ok(world.colliders.length > 40, 'cover and city walls have collision');
  for (const box of world.colliders) {
    assert.ok(box.minX < box.maxX && box.minZ < box.maxZ && box.bottom < box.top);
    assert.ok(Object.values(box).every(Number.isFinite));
  }
});
