# Dependências e origem dos recursos

- Three.js 0.180.0 — licença MIT. Código e licença em `node_modules/three`.
- Vite — licença MIT. Ferramenta de build/servidor, não um asset de jogo.
- TypeScript — licença Apache-2.0. Compilação e verificações.
- Playwright — licença Apache-2.0. Automação de testes.
- `@types/three` e dependências transitivas mantêm suas respectivas licenças dentro de `node_modules` e do lockfile.

Os modelos, texturas de canvas, ícones SVG, cenários e sons sintetizados deste projeto foram criados em código para este experimento. Não foram extraídos arquivos de Counter-Strike. As imagens fornecidas pelo usuário serviram como referência de composição e não são incorporadas ao jogo. Fontes são as fontes locais do sistema.

Counter-Strike é uma marca de seus respectivos titulares. Este projeto independente não é um produto oficial.
