// Pure match rules shared with regression tests; planting changes elimination rules.
export function winnerFor(state: {
    tAlive: number;
    ctAlive: number;
    planted: boolean;
    time: number;
    bombTime: number;
    defused: boolean;
}): 'T' | 'CT' | null {
    if (state.defused)
        return 'CT';
    if (state.planted) {
        if (state.bombTime <= 0)
            return 'T';
        if (state.ctAlive === 0)
            return 'T';
        return null;
    }
    if (state.tAlive === 0)
        return 'CT';
    if (state.ctAlive === 0)
        return 'T';
    if (state.time <= 0)
        return 'CT';
    return null;
}
export function damageAfterArmor(damage: number, armor: number, head: boolean, helmet: boolean) {
    const raw = damage * (head ? 4 : 1);
    const protectedHit = armor > 0 && (!head || helmet);
    const absorbed = protectedHit ? Math.min(raw * .35, armor * 2) : 0;
    return { health: raw - absorbed, armor: absorbed / 2 };
}
export function canAfford(balance: number, price: number) { return Number.isFinite(price) && price >= 0 && balance >= price; }
