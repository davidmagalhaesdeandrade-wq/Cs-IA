import { Vector3 } from 'three';
import type { Collider } from './world';
export function blocked(x: number, z: number, colliders: Collider[], radius = .34, feet = 0, height = 1.75) {
    return colliders.some(c => c.top > feet + .31 && c.bottom < feet + height && x + radius > c.minX && x - radius < c.maxX && z + radius > c.minZ && z - radius < c.maxZ);
}
export function moveBody(pos: Vector3, dx: number, dz: number, colliders: Collider[], height = 1.75) {
    const steps = Math.max(1, Math.ceil(Math.hypot(dx, dz) / .18));
    for (let i = 0; i < steps; i++) {
        if (!blocked(pos.x + dx / steps, pos.z, colliders, .32, pos.y, height))
            pos.x += dx / steps;
        if (!blocked(pos.x, pos.z + dz / steps, colliders, .32, pos.y, height))
            pos.z += dz / steps;
    }
    pos.x = Math.max(-34, Math.min(34, pos.x));
    pos.z = Math.max(-34, Math.min(34, pos.z));
}
export class Navigation {
    min = -34;
    size = 69;
    grid: Uint8Array;
    constructor(public colliders: Collider[]) { this.grid = new Uint8Array(this.size * this.size); for (let z = 0; z < this.size; z++)
        for (let x = 0; x < this.size; x++)
            this.grid[z * this.size + x] = blocked(x + this.min, z + this.min, colliders, .48) ? 1 : 0; }
    node(p: Vector3) { return this.nearest(Math.round(p.x - this.min), Math.round(p.z - this.min)); }
    nearest(x: number, z: number) { for (let r = 0; r < 12; r++)
        for (let j = -r; j <= r; j++)
            for (let i = -r; i <= r; i++) {
                const xx = x + i, zz = z + j;
                if (xx >= 0 && zz >= 0 && xx < this.size && zz < this.size && !this.grid[zz * this.size + xx])
                    return zz * this.size + xx;
            } return -1; }
    path(from: Vector3, to: Vector3): Vector3[] {
        const start = this.node(from), end = this.node(to);
        if (start < 0 || end < 0)
            return [];
        const open = [start], cost = new Float32Array(this.grid.length).fill(Infinity), parent = new Int32Array(this.grid.length).fill(-1), closed = new Uint8Array(this.grid.length);
        cost[start] = 0;
        const h = (n: number) => Math.abs(n % this.size - end % this.size) + Math.abs(Math.floor(n / this.size) - Math.floor(end / this.size));
        let guard = 0;
        while (open.length && guard++ < 6000) {
            let best = 0;
            for (let i = 1; i < open.length; i++)
                if (cost[open[i]] + h(open[i]) < cost[open[best]] + h(open[best]))
                    best = i;
            const n = open.splice(best, 1)[0];
            if (n === end) {
                const out = [];
                for (let at = end; at !== start; at = parent[at]) {
                    if (at < 0)
                        return [];
                    out.push(new Vector3(at % this.size + this.min, 0, Math.floor(at / this.size) + this.min));
                }
                return out.reverse();
            }
            closed[n] = 1;
            const x = n % this.size, z = Math.floor(n / this.size);
            for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
                const xx = x + dx, zz = z + dz, nn = zz * this.size + xx;
                if (xx < 0 || zz < 0 || xx >= this.size || zz >= this.size || this.grid[nn] || closed[nn])
                    continue;
                const g = cost[n] + 1;
                if (g < cost[nn]) {
                    parent[nn] = n;
                    cost[nn] = g;
                    if (!open.includes(nn))
                        open.push(nn);
                }
            }
        }
        return [];
    }
}
export function segmentBlocked(a: Vector3, b: Vector3, colliders: Collider[]) {
    // Segment/slab test handles overhead arch geometry as well as walls.
    for (const c of colliders) {
        let lo = 0, hi = 1;
        for (const [origin, delta, min, max] of [[a.x, b.x - a.x, c.minX, c.maxX], [a.y, b.y - a.y, c.bottom, c.top], [a.z, b.z - a.z, c.minZ, c.maxZ]]) {
            if (Math.abs(delta) < 1e-8) {
                if (origin < min || origin > max) {
                    lo = 2;
                    break;
                }
            }
            else {
                let u = (min - origin) / delta, v = (max - origin) / delta;
                if (u > v)
                    [u, v] = [v, u];
                lo = Math.max(lo, u);
                hi = Math.min(hi, v);
                if (lo > hi)
                    break;
            }
        }
        if (lo <= hi && lo < .99 && hi > .01)
            return true;
    }
    return false;
}
