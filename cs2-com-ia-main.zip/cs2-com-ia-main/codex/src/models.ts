import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

/* All meshes and finishes in this file are original procedural assets. Weapons
   share a local convention: muzzle -Z, stock +Z, receiver at the origin. */
type Point = [number, number, number];
type ProfilePoint = [number, number];
const Y = new THREE.Vector3(0, 1, 0);
const materialCache = new Map<string, THREE.MeshStandardMaterial>();

function mat(color: THREE.ColorRepresentation, roughness = 0.65, metalness = 0.1) {
  const key = `${color}:${roughness}:${metalness}`;
  let m = materialCache.get(key);
  if (!m) {
    m = new THREE.MeshStandardMaterial({ color, roughness, metalness });
    materialCache.set(key, m);
  }
  return m;
}
const steel = mat('#242c2d', 0.38, 0.82);
const dark = mat('#101718', 0.68, 0.32);
const edge = mat('#576063', 0.42, 0.82);
const rubber = mat('#171c1b', 0.95, 0.02);
const wood = mat('#754323', 0.63, 0.05);
const woodLight = mat('#a16736', 0.67, 0.04);
const brass = mat('#bd9651', 0.3, 0.8);
// Uniform fabric/rubber finishes share a shader; per-vertex colours retain each
// panel's colour without paying for a separate draw call for every olive tone.
const matteBatchMaterial = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: .92, metalness: .03, vertexColors: true });
const fabricCache = new Map<string, THREE.MeshStandardMaterial>();

/** Locally painted, seamless cloth. Canvas is used in the browser; the identical
 *  pixel raster has a DataTexture fallback for geometry validation without DOM. */
function fabric(color: string, pattern: 'canvas' | 'plaid' | 'knit' | 'skin' = 'canvas') {
  const key = `${color}:${pattern}`;
  const cached = fabricCache.get(key); if (cached) return cached;
  const size = 128, pixels = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const noise = ((x * 131 + y * 197 + x * y * 13) % 23) - 11;
    let value = 233 + noise * .65;
    let red = 0, green = 0, blue = 0;
    if (pattern === 'plaid') {
      value -= (Math.floor(x / 16) % 2 ? 8 : 0) + (Math.floor(y / 16) % 2 ? 7 : 0);
      if (x % 32 < 2 || y % 32 < 2) value -= 51;
      if (x % 16 === 7 || y % 16 === 7) value -= 17;
      if (x % 32 === 22 || y % 32 === 22) { red = 7; green = -12; blue = -13; }
    } else if (pattern === 'knit') {
      value += Math.sin(x * Math.PI / 3 + Math.sin(y * Math.PI / 4)) * 13;
      if ((x + Math.floor(y / 4) % 2 * 3) % 6 === 0) value -= 16;
    } else if (pattern === 'canvas') {
      value += (x % 3 === 0 ? 7 : -3) + (y % 3 === 0 ? 5 : -2);
      if (x % 17 === 0) value -= 4;
    } else {
      value = 240 + noise * .42;
      if ((x * 7 + y * 29) % 113 === 0) value -= 16;
    }
    const offset = (y * size + x) * 4;
    pixels[offset] = Math.max(0, Math.min(255, value + red));
    pixels[offset + 1] = Math.max(0, Math.min(255, value + green));
    pixels[offset + 2] = Math.max(0, Math.min(255, value + blue));
    pixels[offset + 3] = 255;
  }
  let texture: THREE.Texture;
  if (typeof document !== 'undefined') {
    const canvas = document.createElement('canvas'); canvas.width = canvas.height = size;
    const context = canvas.getContext('2d');
    if (context) {
      const raster = context.createImageData(size, size); raster.data.set(pixels); context.putImageData(raster, 0, 0);
      texture = new THREE.CanvasTexture(canvas);
    } else texture = new THREE.DataTexture(pixels, size, size, THREE.RGBAFormat);
  } else texture = new THREE.DataTexture(pixels, size, size, THREE.RGBAFormat);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(pattern === 'plaid' ? 1.5 : 3, pattern === 'plaid' ? 1.5 : 3);
  texture.anisotropy = 4; texture.needsUpdate = true;
  const material = new THREE.MeshStandardMaterial({ color, map: texture, bumpMap: texture,
    bumpScale: pattern === 'skin' ? .0004 : pattern === 'knit' ? .0015 : .0009,
    roughness: pattern === 'skin' ? .88 : .94, metalness: 0.01 });
  fabricCache.set(key, material); return material;
}

/** Bake static detail into one draw per material while retaining animated pivots.
 *  Hit zones are part of the batch key, so a helmet can never become torso damage.
 *  Geometry remains independent of world/root transforms and can be raycast normally. */
function mergeStatic(parent: THREE.Object3D, preserve = new Set<THREE.Object3D>()) {
  parent.updateWorldMatrix(true, true);
  const inverse = parent.matrixWorld.clone().invert();
  const batches = new Map<string, { material: THREE.Material; zone?: string; geometries: THREE.BufferGeometry[]; sources: THREE.Mesh[] }>();
  const visit = (object: THREE.Object3D) => {
    if (preserve.has(object)) return;
    if (object instanceof THREE.Mesh && !Array.isArray(object.material)) {
      const zone = object.userData.hitZone as string | undefined;
      const sourceMaterial = object.material;
      const isMatte = sourceMaterial instanceof THREE.MeshStandardMaterial &&
        sourceMaterial.roughness >= .7 && sourceMaterial.metalness <= .2 &&
        !sourceMaterial.map && !sourceMaterial.normalMap && !sourceMaterial.transparent &&
        sourceMaterial.emissive.getHex() === 0;
      const material = isMatte ? matteBatchMaterial : sourceMaterial;
      const key = `${material.uuid}:${zone || ''}`;
      let batch = batches.get(key);
      if (!batch) {
        batch = { material, zone, geometries: [], sources: [] };
        batches.set(key, batch);
      }
      // All primitives supply positions, normals and UVs. Non-indexed inputs
      // allow extrusions, spheres and tubes to share the same geometry batch.
      const geometry = object.geometry.index ? object.geometry.toNonIndexed() : object.geometry.clone();
      geometry.applyMatrix4(new THREE.Matrix4().multiplyMatrices(inverse, object.matrixWorld));
      geometry.clearGroups();
      if (isMatte) {
        const colors = new Float32Array(geometry.getAttribute('position').count * 3);
        const color = (sourceMaterial as THREE.MeshStandardMaterial).color;
        for (let i = 0; i < colors.length; i += 3) {
          colors[i] = color.r; colors[i + 1] = color.g; colors[i + 2] = color.b;
        }
        geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
      }
      batch.geometries.push(geometry);
      batch.sources.push(object);
    }
    for (const child of object.children) visit(child);
  };
  for (const child of parent.children) visit(child);
  let index = 0;
  for (const batch of batches.values()) {
    const geometry = mergeGeometries(batch.geometries, false);
    if (!geometry) {
      for (const g of batch.geometries) g.dispose();
      continue;
    }
    geometry.computeBoundingBox(); geometry.computeBoundingSphere();
    const merged = mesh(geometry, batch.material, parent);
    merged.name = `batch-${parent.name || 'static'}-${index++}`;
    if (batch.zone) merged.userData.hitZone = batch.zone;
    for (const source of batch.sources) {
      source.removeFromParent();
      source.geometry.dispose();
    }
    for (const g of batch.geometries) g.dispose();
  }
}

function magazineGroup(parent: THREE.Object3D) {
  const group = new THREE.Group(); group.name = 'magazine'; parent.add(group); return group;
}

function mesh(geometry: THREE.BufferGeometry, material: THREE.Material, parent: THREE.Object3D, position?: Point) {
  const m = new THREE.Mesh(geometry, material);
  if (position) m.position.set(...position);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}
function box(parent: THREE.Object3D, size: Point, position: Point, material = steel) {
  return mesh(new THREE.BoxGeometry(...size), material, parent, position);
}
function sphere(parent: THREE.Object3D, radius: number, position: Point, scale: Point, material = steel) {
  const m = mesh(new THREE.SphereGeometry(radius, 16, 12), material, parent, position);
  m.scale.set(...scale);
  return m;
}
function rod(parent: THREE.Object3D, a: Point, b: Point, radius: number, material = steel, endRadius = radius, segments = 12) {
  const start = new THREE.Vector3(...a), end = new THREE.Vector3(...b);
  const direction = end.clone().sub(start);
  const m = mesh(new THREE.CylinderGeometry(endRadius, radius, direction.length(), segments), material, parent);
  m.position.copy(start.add(end).multiplyScalar(0.5));
  m.quaternion.setFromUnitVectors(Y, direction.normalize());
  return m;
}
function capsule(parent: THREE.Object3D, a: Point, b: Point, radius: number, material: THREE.Material, flatten = 1) {
  const start = new THREE.Vector3(...a), end = new THREE.Vector3(...b), direction = end.clone().sub(start);
  const m = mesh(new THREE.CapsuleGeometry(radius, Math.max(0.001, direction.length() - radius * 2), 5, 12), material, parent);
  m.position.copy(start.add(end).multiplyScalar(0.5));
  m.quaternion.setFromUnitVectors(Y, direction.normalize());
  m.scale.z = flatten;
  return m;
}
function taperedLimb(parent: THREE.Object3D, a: Point, b: Point, elbowRadius: number, wristRadius: number, material: THREE.Material, folds = false) {
  const start = new THREE.Vector3(...a), end = new THREE.Vector3(...b), direction = end.clone().sub(start);
  const length = direction.length();
  const radii = [[0, -.5], [elbowRadius * .83, -.5], [elbowRadius, -.40],
    [elbowRadius * 1.015, -.24], [elbowRadius * .92, -.03],
    [(elbowRadius + wristRadius) * .49, .20], [wristRadius * 1.05, .42], [wristRadius, .5], [0, .5]];
  const geometry = new THREE.LatheGeometry(radii.map(([r, y]) => new THREE.Vector2(r, y * length)), 16);
  if (folds) {
    const positions = geometry.getAttribute('position');
    for (let i = 0; i < positions.count; i++) {
      const y = positions.getY(i) / length, angle = Math.atan2(positions.getZ(i), positions.getX(i));
      const r = 1 + Math.sin(angle * 5 + y * 23) * .035;
      positions.setX(i, positions.getX(i) * r); positions.setZ(i, positions.getZ(i) * r);
    }
    geometry.computeVertexNormals();
  }
  const m = mesh(geometry, material, parent); m.position.copy(start.add(end).multiplyScalar(.5));
  m.quaternion.setFromUnitVectors(Y, direction.normalize()); return m;
}
function extrude(parent: THREE.Object3D, shape: THREE.Shape, width: number, material = steel, bevel = 0.003) {
  const geometry = new THREE.ExtrudeGeometry(shape, {
    depth: width, bevelEnabled: bevel > 0, bevelSegments: 2,
    steps: 1, bevelSize: bevel, bevelThickness: bevel, curveSegments: 16,
  });
  geometry.translate(0, 0, -width / 2);
  geometry.rotateY(-Math.PI / 2);
  return mesh(geometry, material, parent);
}
function profile(parent: THREE.Object3D, points: ProfilePoint[], width: number, material = steel, bevel = 0.003) {
  const shape = new THREE.Shape();
  points.forEach(([z, y], i) => i ? shape.lineTo(z, y) : shape.moveTo(z, y));
  shape.closePath();
  return extrude(parent, shape, width, material, bevel);
}
function tube(parent: THREE.Object3D, points: Point[], radius: number, material: THREE.Material) {
  const path = new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p)));
  return mesh(new THREE.TubeGeometry(path, 12, radius, 5, false), material, parent);
}
function ring(parent: THREE.Object3D, radius: number, thickness: number, position: Point, material = steel) {
  return mesh(new THREE.TorusGeometry(radius, thickness, 6, 16), material, parent, position);
}
function fastener(parent: THREE.Object3D, position: Point, material = edge) {
  const b = rod(parent, [position[0] - 0.002, position[1], position[2]], [position[0] + 0.002, position[1], position[2]], 0.005, material, 0.005, 6);
  return b;
}
function rail(parent: THREE.Object3D, zStart: number, zEnd: number, y: number, width: number, material = steel) {
  box(parent, [width, 0.014, Math.abs(zEnd - zStart)], [0, y, (zStart + zEnd) / 2], material);
  const count = Math.max(3, Math.round(Math.abs(zEnd - zStart) / 0.019));
  for (let i = 0; i < count; i++) {
    box(parent, [width + 0.006, 0.008, 0.008], [0, y + 0.01, zStart + (zEnd - zStart) * i / (count - 1)], edge);
  }
}
function barrel(parent: THREE.Object3D, start: number, end: number, y: number, radius = 0.012, material = steel) {
  rod(parent, [0, y, start], [0, y, end], radius, material);
  rod(parent, [0, y, end + 0.014], [0, y, end - 0.012], radius * 1.4, material);
  rod(parent, [0, y, end - 0.013], [0, y, end - 0.014], radius * 0.76, dark);
}
function triggerGuard(parent: THREE.Object3D, z = 0.045, width = 0.027) {
  tube(parent, [[-width / 2, -0.035, z - 0.04], [-width / 2, -0.105, z - 0.025], [-width / 2, -0.111, z + 0.035], [-width / 2, -0.04, z + 0.047]], 0.004, steel);
  tube(parent, [[width / 2, -0.035, z - 0.04], [width / 2, -0.105, z - 0.025], [width / 2, -0.111, z + 0.035], [width / 2, -0.04, z + 0.047]], 0.004, steel);
  profile(parent, [[z + 0.007, -0.03], [z - 0.005, -0.06], [z + 0.005, -0.083], [z + 0.013, -0.076]], 0.008, edge, 0.001);
}
function grip(parent: THREE.Object3D, z = 0.10, material = rubber) {
  profile(parent, [[z - 0.025, -0.027], [z + 0.031, -0.034], [z + 0.075, -0.173], [z + 0.009, -0.185], [z - 0.012, -0.11]], 0.041, material, 0.005);
  for (let i = 0; i < 5; i++) {
    const y = -0.084 - i * 0.017;
    rod(parent, [-0.023, y, z + 0.013 + i * 0.004], [-0.023, y, z + 0.049 + i * 0.004], 0.0015, edge);
    rod(parent, [0.023, y, z + 0.013 + i * 0.004], [0.023, y, z + 0.049 + i * 0.004], 0.0015, edge);
  }
}
function paintFor(id: string, skin: string) {
  if (skin === 'gold') return { receiver: mat('#c29a39', 0.25, 0.92), furniture: mat('#35291c', 0.5, 0.25), accent: brass };
  if (skin === 'redline') return { receiver: mat('#212225', 0.42, 0.65), furniture: mat('#17191b', 0.65, 0.22), accent: mat('#c02c27', 0.4, 0.35) };
  if (skin === 'urban') return { receiver: mat('#c3c4b8', 0.65, 0.42), furniture: mat('#777f76', 0.75, 0.1), accent: mat('#303c3a', 0.7, 0.2) };
  if (skin === 'blue') return { receiver: mat('#28708b', 0.35, 0.72), furniture: mat('#172d3d', 0.45, 0.4), accent: mat('#76c4d1', 0.32, 0.7) };
  if (skin === 'white') return { receiver: mat('#d9d8ca', 0.35, 0.55), furniture: mat('#b9bbb2', 0.6, 0.15), accent: mat('#e88d30', 0.4, 0.4) };
  if (skin === 'dragon') return { receiver: mat('#9b793d', 0.6, 0.5), furniture: mat('#7b402e', 0.7, 0.1), accent: mat('#e6b353', 0.4, 0.65) };
  return { receiver: steel, furniture: id === 'ak' ? wood : mat(id === 'awp' ? '#667047' : '#303b37', 0.8, 0.08), accent: edge };
}

function makeAK(parent: THREE.Group, skin: string) {
  const p = paintFor('ak', skin);
  profile(parent, [[-.205, -.025], [-.205, .052], [-.143, .080], [.152, .080], [.183, .043], [.167, -.035]], .060, p.receiver);
  rod(parent, [0, .075, -.165], [0, .075, .165], .028, p.receiver, .024, 12);
  box(parent, [.009, .023, .108], [.036, .035, -.045], dark);
  rod(parent, [.038, .035, .012], [.066, .035, .012], .005, edge);
  for (const z of [-.15, -.115, .08, .134]) for (const x of [-.033, .033]) fastener(parent, [x, -.005, z]);
  // Laminate stock and handguard have independent contours and steel end caps.
  profile(parent, [[.15, .058], [.29, .060], [.445, .025], [.448, -.10], [.384, -.105], [.27, -.032], [.168, -.012]], .049, p.furniture, .006);
  profile(parent, [[.432, .03], [.454, .026], [.454, -.108], [.431, -.11]], .055, rubber, .002);
  profile(parent, [[-.20, .067], [-.405, .060], [-.415, -.013], [-.22, -.033]], .060, p.furniture, .006);
  profile(parent, [[-.22, .080], [-.382, .080], [-.395, .064], [-.216, .054]], .044, p.furniture);
  for (const z of [-.24, -.37]) {
    box(parent, [.065, .008, .013], [0, .016, z], steel);
    box(parent, [.065, .072, .012], [0, .028, z], steel);
  }
  barrel(parent, -.37, -.655, .037, .010);
  rod(parent, [0, .087, -.395], [0, .087, -.565], .009, steel);
  profile(parent, [[-.54, .04], [-.56, .105], [-.578, .105], [-.584, .034]], .026, steel);
  profile(parent, [[-.61, .03], [-.62, .125], [-.638, .125], [-.643, .035]], .022, steel);
  ring(parent, .015, .003, [0, .12, -.629]);
  box(parent, [.008, .026, .008], [0, .124, -.628], edge);
  box(parent, [.04, .018, .06], [0, .101, -.166], steel);
  box(parent, [.044, .025, .014], [0, .118, -.137], steel);
  const magazine = new THREE.Shape();
  magazine.moveTo(-.135, -.025); magazine.lineTo(-.047, -.025);
  magazine.quadraticCurveTo(-.034, -.19, -.091, -.30);
  magazine.lineTo(-.16, -.345); magazine.lineTo(-.216, -.309);
  magazine.quadraticCurveTo(-.14, -.21, -.135, -.025);
  const detachable = magazineGroup(parent);
  extrude(detachable, magazine, .048, skin === 'gold' ? p.receiver : mat('#303735', .5, .7));
  for (const x of [-.027, .027]) {
    for (let i = 0; i < 3; i++) {
      const z = -.064 - i * .022;
      tube(detachable, [[x, -.066, z], [x, -.17, z - .012], [x, -.25, z - .044], [x, -.29, z - .067]], .0022, dark);
    }
  }
  grip(parent, .085, skin === 'default' ? wood : p.furniture);
  triggerGuard(parent, .032);
  // Side-mounted safety lever and receiver stamping.
  rod(parent, [.036, .015, .08], [.036, -.012, -.065], .004, edge);
  box(parent, [.007, .013, .045], [.037, .004, -.058], p.accent);
  if (skin !== 'default') {
    for (const x of [-.034, .034]) {
      rod(parent, [x, .053, -.145], [x, .053, .13], .0025, p.accent);
      rod(parent, [x * .82, -.065, .31], [x * .82, -.085, .42], .003, p.accent);
    }
  } else {
    for (let i = 0; i < 5; i++) {
      const y = -.009 + i * .012;
      tube(parent, [[.031, y, -.232], [.032, y + .003, -.30], [.029, y + .002, -.37]], .0008, woodLight);
    }
  }
}

function makeM4(parent: THREE.Group, skin: string, suppressed = false) {
  const p = paintFor('m4', skin);
  profile(parent, [[-.21, -.027], [-.21, .057], [-.151, .079], [.145, .079], [.18, .05], [.175, -.034]], .064, p.receiver);
  profile(parent, [[-.08, -.025], [.15, -.025], [.16, -.07], [.071, -.07], [.034, -.118], [-.044, -.105]], .057, p.receiver);
  rod(parent, [0, .046, .14], [0, .046, .30], .021, steel);
  profile(parent, [[.245, .073], [.425, .067], [.433, -.105], [.394, -.12], [.346, -.035], [.245, -.022]], .055, p.furniture, .005);
  profile(parent, [[.416, .074], [.441, .07], [.444, -.109], [.422, -.12]], .059, rubber);
  box(parent, [.057, .018, .15], [0, -.028, .296], p.furniture);
  rod(parent, [0, .035, -.19], [0, .035, -.43], .035, p.furniture, .030, 12);
  rail(parent, -.39, -.205, .075, .043, p.receiver);
  rail(parent, -.16, .13, .093, .038, p.receiver);
  box(parent, [.075, .018, .205], [0, -.005, -.305], steel);
  for (const x of [-.036, .036]) {
    for (let i = 0; i < 9; i++) box(parent, [.012, .048, .008], [x, .028, -.218 - i * .023], p.receiver);
  }
  barrel(parent, -.42, suppressed ? -.675 : -.61, .038, .01);
  profile(parent, [[-.479, .034], [-.484, .143], [-.502, .148], [-.525, .038]], .026, steel);
  ring(parent, .014, .003, [0, .144, -.497]);
  if (suppressed) {
    rod(parent, [0, .038, -.57], [0, .038, -.78], .025, p.receiver);
    for (let i = 0; i < 4; i++) ring(parent, .025, .0014, [0, .038, -.59 - i * .048], edge);
    rod(parent, [0, .038, -.781], [0, .038, -.783], .010, dark);
  } else {
    rod(parent, [0, .038, -.594], [0, .038, -.64], .017, steel);
    for (let i = 0; i < 3; i++) box(parent, [.039, .004, .006], [0, .038 + (i - 1) * .01, -.627], dark);
    // Open carry handle with a small rear aperture.
    profile(parent, [[.075, .105], [.081, .168], [.036, .187], [-.124, .187], [-.161, .15], [-.159, .105], [-.135, .105], [-.131, .15], [.051, .15], [.052, .105]], .032, p.receiver, .002);
    ring(parent, .012, .004, [0, .187, .039], steel);
  }
  const mag = new THREE.Shape();
  mag.moveTo(-.106, -.052); mag.lineTo(-.033, -.052); mag.lineTo(-.032, -.188);
  mag.quadraticCurveTo(-.039, -.244, -.060, -.272); mag.lineTo(-.132, -.25); mag.lineTo(-.106, -.052);
  const detachable = magazineGroup(parent);
  extrude(detachable, mag, .041, mat('#5d6661', .55, .62));
  for (const x of [-.024, .024]) for (let i = 0; i < 3; i++) {
    rod(detachable, [x, -.087, -.052 - i * .018], [x, -.216, -.066 - i * .019], .002, dark);
  }
  grip(parent, .073, p.furniture); triggerGuard(parent, .025);
  box(parent, [.006, .021, .09], [.036, .040, -.035], dark);
  box(parent, [.007, .009, .095], [.041, .026, -.034], edge);
  rod(parent, [.04, .046, .082], [.068, .042, .109], .009, steel);
  for (const z of [-.11, .091]) for (const x of [-.035, .035]) fastener(parent, [x, -.012, z]);
  if (skin !== 'default') for (let i = 0; i < 5; i++) {
    box(parent, [.002, .052, .019], [.036, .021, -.125 + i * .052], i % 2 ? p.accent : p.furniture).rotation.x = -.34;
  }
}

function scope(parent: THREE.Group, z = -.04, y = .151, length = .265) {
  rod(parent, [0, y, z - length / 2], [0, y, z + length / 2], .023, steel);
  rod(parent, [0, y, z - length / 2 - .05], [0, y, z - length / 2 + .022], .035, steel, .028);
  rod(parent, [0, y, z + length / 2 - .02], [0, y, z + length / 2 + .04], .029, rubber);
  const lens = mat('#203b43', .13, .92);
  rod(parent, [0, y, z - length / 2 - .051], [0, y, z - length / 2 - .052], .029, lens);
  rod(parent, [0, y, z + length / 2 + .041], [0, y, z + length / 2 + .042], .024, lens);
  for (const mountZ of [z - .07, z + .075]) {
    box(parent, [.03, .044, .018], [0, y - .045, mountZ], steel);
    ring(parent, .026, .004, [0, y, mountZ]);
  }
  rod(parent, [0, y, z], [0, y + .042, z], .016, steel, .015);
  rod(parent, [0, y, z], [.039, y, z], .014, steel);
  for (let i = 0; i < 8; i++) ring(parent, .030, .001, [0, y, z + length / 2 + .005 + i * .004], edge);
}
function makeAWP(parent: THREE.Group, skin: string) {
  const p = paintFor('awp', skin);
  profile(parent, [[-.385, -.027], [-.35, .026], [.10, .035], [.20, -.005], [.41, .016], [.437, -.018], [.435, -.135], [.385, -.139], [.231, -.045], [.17, -.06], [.157, -.154], [.102, -.151], [.049, -.048]], .068, p.furniture, .008);
  profile(parent, [[.27, .032], [.416, .031], [.429, -.014], [.269, -.014]], .066, p.furniture, .006);
  profile(parent, [[.422, .034], [.445, .026], [.446, -.142], [.422, -.144]], .074, rubber);
  rod(parent, [0, .049, -.29], [0, .049, .135], .026, p.receiver, .026, 16);
  barrel(parent, -.28, -.79, .049, .015, p.receiver);
  rail(parent, -.14, .14, .080, .037, steel);
  scope(parent, -.055, .167, .30);
  rod(parent, [.027, .048, .091], [.071, .002, .115], .007, steel);
  sphere(parent, .015, [.072, -.002, .115], [1, 1, 1], steel);
  box(magazineGroup(parent), [.048, .083, .082], [0, -.083, -.044], steel);
  triggerGuard(parent, .066);
  // Folded bipod and adjustable stock screws.
  rod(parent, [-.032, -.027, -.31], [-.037, -.055, -.58], .006, steel);
  rod(parent, [.032, -.027, -.31], [.037, -.055, -.58], .006, steel);
  for (const z of [.295, .37]) for (const x of [-.036, .036]) fastener(parent, [x, -.028, z], brass);
  if (skin === 'dragon') {
    for (const x of [-.036, .036]) {
      tube(parent, [[x, -.005, -.30], [x, -.017, -.24], [x, -.005, -.18], [x, -.025, -.12], [x, -.015, -.06]], .004, p.accent);
      for (let i = 0; i < 10; i++) {
        const z = -.30 + i * .026;
        rod(parent, [x, -.025, z], [x, -.042, z + .014], .002, p.accent);
      }
    }
  } else if (skin === 'white') {
    for (const x of [-.036, .036]) box(parent, [.003, .022, .13], [x, -.021, -.24], p.accent);
  }
}

function makePistol(parent: THREE.Group, id: string) {
  const deagle = id === 'deagle', usp = id === 'usp';
  const length = deagle ? .235 : .18, width = deagle ? .041 : .033;
  const slide = deagle ? mat('#a6aba5', .3, .85) : mat('#333d3c', .43, .73);
  profile(parent, [[-length, .048], [-length, .010], [-.02, -.018], [.075, -.017], [.078, .044], [.035, .06], [-length + .02, .06]], width, slide);
  profile(parent, [[-length + .02, .005], [.061, .005], [.076, -.051], [.044, -.063], [-.018, -.054], [-.045, -.025], [-length + .02, -.025]], width * .90, rubber);
  profile(parent, [[.012, -.018], [.066, -.031], [.101, -.178], [.026, -.184], [-.001, -.071]], width * 1.1, usp ? mat('#34433d', .8, .1) : rubber, .004);
  const detachable = magazineGroup(parent);
  profile(detachable, [[.023, -.174], [.102, -.169], [.106, -.189], [.023, -.195]], width * 1.18, dark);
  triggerGuard(parent, -.031, .026);
  for (const x of [-width / 2 - .002, width / 2 + .002]) {
    for (let i = 0; i < 7; i++) rod(parent, [x, .019, .019 + i * .006], [x, .048, .024 + i * .006], .0012, dark);
    for (let i = 0; i < 5; i++) rod(parent, [x * 1.12, -.081 - i * .017, .025 + i * .005], [x * 1.12, -.077 - i * .017, .066 + i * .004], .0012, edge);
  }
  box(parent, [width * .5, .015, .014], [0, .067, .049], steel);
  box(parent, [.006, .011, .011], [0, .065, -length + .018], steel);
  sphere(parent, .002, [-.008, .071, .056], [1, 1, .5], mat('#d9e5d2', .4, .1));
  sphere(parent, .002, [.008, .071, .056], [1, 1, .5], mat('#d9e5d2', .4, .1));
  rod(parent, [0, .029, -length], [0, .029, -length - .009], deagle ? .012 : .009, steel);
  rod(parent, [0, .029, -length - .01], [0, .029, -length - .011], .006, dark);
  box(parent, [.002, .016, .037], [width / 2 + .001, .033, -.054], dark);
  if (usp) {
    rod(parent, [0, .029, -length - .005], [0, .029, -length - .182], .019, steel);
    ring(parent, .019, .0015, [0, .029, -length - .018], edge);
    ring(parent, .019, .0015, [0, .029, -length - .17], edge);
    rod(parent, [0, .029, -length - .183], [0, .029, -length - .184], .007, dark);
  }
  fastener(parent, [width * .58, -.13, .05]);
}
function makeMP9(parent: THREE.Group) {
  const polymer = mat('#424b43', .8, .15);
  profile(parent, [[-.26, .06], [.07, .06], [.09, .02], [.07, -.04], [-.23, -.04], [-.27, -.008]], .052, polymer, .005);
  rail(parent, -.24, .06, .069, .033);
  barrel(parent, -.25, -.31, .008, .012);
  grip(parent, .018, polymer);
  const detachable = magazineGroup(parent);
  box(detachable, [.032, .24, .045], [0, -.205, .04], steel).rotation.x = -.12;
  box(detachable, [.039, .014, .050], [0, -.323, .055], rubber);
  profile(parent, [[-.145, -.035], [-.174, -.032], [-.179, -.151], [-.147, -.158]], .03, rubber);
  triggerGuard(parent, -.035);
  rod(parent, [-.021, .018, .075], [-.034, .014, .27], .007, steel);
  rod(parent, [.021, .018, .075], [.034, .014, .27], .007, steel);
  box(parent, [.066, .12, .025], [0, -.025, .278], rubber);
  for (let i = 0; i < 5; i++) box(parent, [.003, .016, .014], [.028, .027, -.105 - i * .023], dark);
  box(parent, [.009, .014, .05], [.029, .023, -.011], dark);
}
function makeKnife(parent: THREE.Group) {
  const blade = mat('#b1b7b3', .28, .9);
  profile(parent, [[-.035, .026], [-.198, .035], [-.31, -.002], [-.22, -.039], [-.036, -.028]], .008, blade, .001);
  profile(parent, [[-.035, .026], [-.198, .035], [-.31, -.002], [-.205, .002], [-.035, .004]], .009, mat('#677374', .38, .85), .0005);
  box(parent, [.044, .096, .014], [0, -.005, -.03], steel);
  rod(parent, [0, -.003, -.026], [0, -.003, .13], .021, mat('#343d32', .9, .03), .019);
  for (let i = 0; i < 8; i++) ring(parent, .021, .002, [0, -.003, -.003 + i * .016], rubber);
  rod(parent, [0, -.003, .126], [0, -.003, .141], .023, steel);
  ring(parent, .009, .002, [0, -.003, .142], edge);
}
function makeC4(parent: THREE.Group) {
  const explosive = mat('#b2a074', .92, .01), tape = mat('#484d40', .95, .02);
  for (let i = 0; i < 4; i++) box(parent, [.047, .118, .17], [(i - 1.5) * .044, -.022, 0], explosive);
  for (const z of [-.05, .055]) box(parent, [.19, .125, .021], [0, -.022, z], tape);
  box(parent, [.142, .035, .14], [0, .051, -.005], mat('#292f29', .7, .25));
  const screen = mat('#82a465', .8, .05); screen.emissive.set('#3f582d'); screen.emissiveIntensity = .35;
  box(parent, [.105, .004, .032], [0, .071, -.044], screen);
  for (let row = 0; row < 4; row++) for (let col = 0; col < 3; col++) {
    box(parent, [.023, .005, .012], [(col - 1) * .032, .074, -.005 + row * .02], mat('#91958a', .7, .1));
  }
  tube(parent, [[-.078, .045, -.067], [-.10, .105, -.08], [.035, .11, -.099], [.07, .066, -.077]], .003, mat('#9e2922', .65, .2));
  tube(parent, [[-.07, .04, .066], [-.096, .073, .085], [.047, .097, .082], [.078, .045, .05]], .0025, mat('#d2bc53', .7, .15));
  for (const x of [-.059, .059]) for (const z of [-.06, .06]) sphere(parent, .003, [x, .071, z], [1, .5, 1], edge);
}
function makeGrenade(parent: THREE.Group, id: string) {
  const isFlash = id === 'flash', isSmoke = id === 'smoke';
  const shell = isFlash ? mat('#929c95', .5, .7) : mat(isSmoke ? '#758179' : '#58613c', .85, .18);
  if (isFlash || isSmoke) {
    rod(parent, [0, -.12, 0], [0, .04, 0], .035, shell, .035, 16);
    for (const y of [-.107, .027]) rod(parent, [0, y - .004, 0], [0, y + .004, 0], .039, steel);
    if (isSmoke) {
      rod(parent, [0, -.061, 0], [0, -.015, 0], .0355, mat('#c3bc96', .9, .05));
      for (let i = 0; i < 3; i++) box(parent, [.012, .003, .001], [(i - 1) * .016, -.033, -.036], dark);
    } else for (let i = 0; i < 8; i++) {
      const a = i * Math.PI / 4;
      rod(parent, [Math.cos(a) * .036, -.09, Math.sin(a) * .036], [Math.cos(a) * .036, .013, Math.sin(a) * .036], .002, dark);
    }
  } else {
    sphere(parent, .052, [0, -.041, 0], [1, 1.24, 1], shell);
    for (let i = 0; i < 4; i++) {
      const r = Math.sqrt(1 - Math.pow((i - 1.5) / 2.6, 2)) * .052;
      const rMesh = ring(parent, r, .0018, [0, -.082 + i * .027, 0], dark);
      rMesh.rotation.x = Math.PI / 2;
    }
  }
  rod(parent, [0, .026, 0], [0, .064, 0], .021, steel);
  profile(parent, [[-.022, .069], [.035, .069], [.048, .049], [.055, -.089], [.044, -.102], [.035, .037], [-.022, .047]], .012, edge, .001);
  const pin = ring(parent, .024, .0022, [-.035, .050, 0], edge); pin.rotation.y = Math.PI / 2;
  rod(parent, [-.04, .052, 0], [0, .052, 0], .002, edge);
}

/** Original, roughly life-sized meshes; no external models or textures required. */
export function createWeapon(id: string, skin = 'default'): THREE.Group {
  const group = new THREE.Group();
  group.name = `weapon-${id}-${skin}`;
  group.userData.weaponId = id;
  group.userData.skin = skin;
  if (id === 'ak') makeAK(group, skin);
  else if (id === 'm4' || id === 'm4s') makeM4(group, skin, id === 'm4s');
  else if (id === 'awp') makeAWP(group, skin);
  else if (['glock', 'usp', 'deagle'].includes(id)) makePistol(group, id);
  else if (id === 'mp9') makeMP9(group);
  else if (id === 'knife') makeKnife(group);
  else if (id === 'c4') makeC4(group);
  else if (['he', 'flash', 'smoke'].includes(id)) makeGrenade(group, id);
  else makeAK(group, skin);
  const magazine = group.getObjectByName('magazine');
  if (magazine) mergeStatic(magazine);
  mergeStatic(group, new Set(magazine ? [magazine] : []));
  return group;
}

function glove(parent: THREE.Object3D, position: Point, scale = 1, rotation: Point = [0, 0, 0]) {
  const group = new THREE.Group();
  group.position.set(...position); group.rotation.set(...rotation); group.scale.setScalar(scale); parent.add(group);
  const leather = mat('#343d35', .94, .03), panel = mat('#58604d', .93, .02);
  sphere(group, .041, [0, 0, 0], [.79, 1.10, .56], leather);
  sphere(group, .029, [0, .012, -.012], [.95, .8, .40], panel);
  for (let i = 0; i < 4; i++) {
    const x = -.022 + i * .014;
    capsule(group, [x, .022, -.008], [x, .012, -.041], .008, leather);
    sphere(group, .008, [x, .022, -.022], [1, .6, .7], rubber);
    capsule(group, [x, .01, -.037], [x, -.014, -.034], .007, leather);
  }
  capsule(group, [.025, -.017, .001], [.031, -.004, -.027], .011, leather);
  box(group, [.055, .018, .035], [0, -.034, .004], panel);
  box(group, [.048, .007, .003], [0, -.031, -.015], mat('#b3aa86', .85, .1));
  return group;
}

/** Place alongside createWeapon under the same first-person camera pivot. */
export function createArms(): THREE.Group {
  const arms = new THREE.Group(); arms.name = 'first-person-arms';
  const skin = fabric('#ae896a', 'skin'), sleeve = fabric('#626b55'), cuff = mat('#414a3d', .95, .02);
  taperedLimb(arms, [.10, -.09, .33], [.077, -.08, .09], .045, .029, skin);
  taperedLimb(arms, [.13, -.15, .43], [.10, -.09, .25], .057, .049, sleeve, true);
  taperedLimb(arms, [-.25, -.27, .33], [-.087, -.08, -.24], .046, .028, skin);
  taperedLimb(arms, [-.28, -.30, .38], [-.20, -.22, .17], .058, .048, sleeve, true);
  rod(arms, [.078, -.080, .14], [.077, -.080, .11], .049, cuff);
  rod(arms, [-.119, -.114, -.14], [-.105, -.102, -.18], .048, cuff);
  glove(arms, [.047, -.076, .074], .91, [0, 0, -.20]);
  glove(arms, [-.039, -.048, -.285], .96, [.55, .15, .52]);
  // Watch with a raised glass face on the supporting wrist.
  rod(arms, [-.13, -.128, -.103], [-.118, -.114, -.143], .048, rubber);
  sphere(arms, .023, [-.126, -.083, -.123], [1, .30, 1], steel);
  sphere(arms, .019, [-.126, -.075, -.123], [1, .22, 1], mat('#132c2a', .16, .6));
  mergeStatic(arms);
  return arms;
}

function torso(parent: THREE.Object3D, material: THREE.Material) {
  const points = [[.13, .89], [.16, .96], [.18, 1.10], [.22, 1.32], [.24, 1.39], [.18, 1.45], [.095, 1.48]].map(([x, y]) => new THREE.Vector2(x, y));
  const m = mesh(new THREE.LatheGeometry(points, 20), material, parent); m.scale.z = .63;
  return m;
}
function pouch(parent: THREE.Object3D, position: Point, width: number, height: number, material: THREE.MeshStandardMaterial) {
  const group = new THREE.Group(); group.position.set(...position); parent.add(group);
  const shape = new THREE.Shape();
  shape.moveTo(-.027, -height / 2); shape.lineTo(.026, -height / 2); shape.lineTo(.033, height / 2 - .008); shape.lineTo(-.024, height / 2); shape.closePath();
  extrude(group, shape, width, material, .005);
  box(group, [width * 1.02, height * .28, .012], [0, height * .30, -.032], material);
  box(group, [.009, height * .44, .004], [0, height * .12, -.04], mat('#696955', .95, .03));
  return group;
}
function makeLeg(parent: THREE.Object3D, side: number, cloth: THREE.MeshStandardMaterial, team: 'T' | 'CT') {
  const leg = new THREE.Group(); leg.position.set(side * .107, .90, 0); parent.add(leg);
  // One continuous garment surface crosses the knee rather than two capsule
  // end caps touching at a point. The calf tapers naturally into the boot.
  const profilePoints = [[0, -.80], [.054, -.80], [.060, -.75], [.061, -.70], [.066, -.64],
    [.067, -.57], [.072, -.52], [.070, -.47], [.075, -.43], [.075, -.38],
    [.080, -.33], [.082, -.27], [.087, -.18], [.089, -.10], [.085, -.035], [.073, .006], [0, .006]];
  const geometry = new THREE.LatheGeometry(profilePoints.map(([r, y]) => new THREE.Vector2(r, y)), 20);
  const positions = geometry.getAttribute('position');
  for (let i = 0; i < positions.count; i++) {
    const y = positions.getY(i), x = positions.getX(i), z = positions.getZ(i);
    const angle = Math.atan2(z, x);
    const fold = Math.sin(y * 96 + angle * 3) * .0018 * (Math.abs(y + .45) < .16 ? 1 : .5);
    positions.setXYZ(i, x + Math.cos(angle) * fold + side * .008 * Math.sin(-y * 3), y,
      z * .87 + Math.sin(-y * 3.7) * -.010 + Math.sin(angle) * fold);
  }
  geometry.computeVertexNormals(); mesh(geometry, cloth, leg);
  const seam = mat(team === 'CT' ? '#697064' : '#858268', .97, .01);
  for (const x of [-.068, .068]) {
    tube(leg, [[x, -.10, .025], [x * .97, -.28, .030], [x * .91, -.45, .027], [x * .82, -.64, .023], [x * .78, -.77, .016]], .0011, seam);
  }
  if (team === 'CT') {
    sphere(leg, .070, [side * .009, -.435, -.063], [.77, .97, .19], mat('#3d4540', .9, .06));
    for (const y of [-.405, -.453]) tube(leg, [[-.05, y, -.068], [0, y, -.082], [.05, y, -.068]], .0022, mat('#657062', .95, .01));
  } else {
    // Reinforced fabric knee panel and its stitched outline stay close to cloth.
    sphere(leg, .064, [side * .009, -.432, -.059], [.80, .93, .12], cloth);
    tube(leg, [[-.038, -.386, -.059], [-.049, -.434, -.066], [-.037, -.484, -.059], [.038, -.484, -.059], [.052, -.434, -.066], [.039, -.386, -.059]], .0011, seam);
  }
  pouch(leg, [side * .078, -.21, .007], .034, .13, cloth).rotation.y = -side * Math.PI / 2;
  sphere(leg, .077, [side * .009, -.815, -.041], [.86, .65, 1.52], mat('#302d24', .9, .08));
  taperedLimb(leg, [side * .009, -.70, .005], [side * .009, -.83, .002], .052, .060, mat('#39382b', .93, .03));
  box(leg, [.133, .026, .215], [side * .009, -.883, -.044], rubber);
  for (let i = 0; i < 4; i++) rod(leg, [-.035, -.789 + i * .009, -.094], [.044, -.789 + i * .009, -.094], .002, mat('#797660', .95, .01));
  return leg;
}
function head(parent: THREE.Object3D, team: 'T' | 'CT') {
  const group = new THREE.Group(); group.position.y = 1.635; parent.add(group);
  const skin = fabric('#b8977b', 'skin');
  rod(group, [0, -.15, .006], [0, -.065, .006], .046, skin);
  if (team === 'T') {
    const mask = fabric('#575b42', 'knit');
    const hood = sphere(group, .102, [0, .004, .002], [1, 1.25, .96], mask);
    const vertices = hood.geometry.getAttribute('position');
    for (let i = 0; i < vertices.count; i++) {
      const y = vertices.getY(i);
      if (y < -.025) vertices.setX(i, vertices.getX(i) * (1 - Math.min(.21, (-y - .025) * 2.5)));
    }
    hood.geometry.computeVertexNormals();
    // A continuous knitted balaclava surrounds two recessed eye openings.
    for (const x of [-.037, .037]) {
      sphere(group, .024, [x, .023, -.088], [1.04, .35, .25], dark);
      sphere(group, .019, [x, .023, -.094], [1, .32, .16], skin);
      sphere(group, .0032, [x, .024, -.098], [.80, .70, .30], mat('#282d24', .8, .03));
      rod(group, [x - .019, .033, -.093], [x + .020, .033, -.093], .0015, mask);
    }
    sphere(group, .021, [0, -.049, -.084], [1.06, .30, .28], dark);
    sphere(group, .014, [0, -.050, -.091], [1.04, .21, .13], skin);
    sphere(group, .014, [0, -.003, -.094], [.65, 1.05, .75], mask);
    rod(group, [0, -.107, .008], [0, -.148, .008], .044, mask, .044);
    for (const x of [-.066, .066]) {
      tube(group, [[x, -.068, -.057], [x * 1.08, -.006, -.068], [x * .96, .078, -.050], [x * .6, .116, -.017]], .0007, mat('#696e51', .99, 0));
    }
  } else {
    sphere(group, .103, [0, .003, .002], [1, 1.24, .98], mat('#343b35', .95, .02));
    const helmetMat = mat('#5e6552', .85, .12);
    const helmet = mesh(new THREE.SphereGeometry(.116, 20, 12, 0, Math.PI * 2, 0, Math.PI * .59), helmetMat, group, [0, .045, .008]);
    helmet.scale.set(1, .81, 1.04);
    const rim = ring(group, .114, .007, [0, .009, .008], mat('#41483b', .9, .08)); rim.rotation.x = Math.PI / 2; rim.scale.y = 1.04;
    box(group, [.042, .052, .018], [0, .086, -.105], steel);
    sphere(group, .087, [0, -.027, -.048], [1.04, .93, .78], rubber);
    const lens = mat('#102a2a', .16, .6);
    for (const x of [-.044, .044]) {
      rod(group, [x, .015, -.098], [x, .015, -.132], .034, steel, .035, 16);
      rod(group, [x, .015, -.133], [x, .015, -.134], .027, lens, .027, 16);
      ring(group, .030, .003, [x, .015, -.136], edge);
    }
    rod(group, [0, -.055, -.111], [0, -.055, -.160], .031, steel);
    ring(group, .025, .002, [0, -.055, -.161], edge);
    rod(group, [-.061, -.058, -.071], [-.105, -.058, -.092], .033, helmetMat);
    for (let i = 0; i < 4; i++) rod(group, [-.113, -.074 + i * .011, -.11], [-.113, -.074 + i * .011, -.077], .002, dark);
    tube(group, [[.074, -.044, -.04], [.094, -.105, -.002], [.045, -.121, .052]], .008, dark);
  }
  group.traverse(object => { if (object instanceof THREE.Mesh) object.userData.hitZone = 'head'; });
  return group;
}

/** Upright human rig, feet at y=0, facing -Z. The returned root is safe to move. */
export function createCharacter(team: 'T' | 'CT', weapon = 'ak'): THREE.Group {
  const root = new THREE.Group(); root.name = `character-${team}`;
  const pose = new THREE.Group(); pose.position.y = .90; root.add(pose);
  const body = new THREE.Group(); body.position.y = -.90; pose.add(body);
  const cloth = fabric(team === 'T' ? '#6c7054' : '#414c47');
  const shirt = fabric(team === 'T' ? '#c0b5a0' : '#546158', team === 'T' ? 'plaid' : 'canvas');
  const armor = fabric(team === 'T' ? '#959077' : '#5b6651');
  const strap = mat(team === 'T' ? '#706b4d' : '#3f4b40', .95, .02);
  torso(body, shirt);
  sphere(body, .15, [0, .93, .005], [1.12, .70, .69], cloth);
  const leftLeg = makeLeg(body, -1, cloth, team), rightLeg = makeLeg(body, 1, cloth, team);
  // Plate carrier wraps a shaped torso. Separate panels leave shoulders and waist readable.
  const carrier = torso(body, armor); carrier.scale.set(1.025, .89, .68); carrier.position.y = .139;
  profile(body, [[-.14, 1.10], [-.14, 1.31], [-.11, 1.38], [.025, 1.38], [.035, 1.09]], .31, armor, .014);
  box(body, [.30, .022, .014], [0, 1.29, -.157], strap);
  box(body, [.29, .022, .014], [0, 1.23, -.16], strap);
  for (const x of [-.145, .145]) {
    capsule(body, [x, 1.42, -.084], [x, 1.14, -.133], .023, strap, .42);
    box(body, [.047, .047, .012], [x, 1.355, -.146], mat('#9e9e80', .85, .15));
  }
  for (let i = 0; i < 3; i++) pouch(body, [(i - 1) * .091, 1.129, -.159], .076, .129, armor);
  pouch(body, [-.165, 1.13, .055], .066, .135, strap).rotation.y = Math.PI / 2;
  pouch(body, [.169, 1.05, .04], .054, .12, strap).rotation.y = -Math.PI / 2;
  // Belt and worn metal buckle.
  const beltPoints = [[.152, .94], [.158, .97], [.158, 1.0], [.15, 1.005]].map(([x, y]) => new THREE.Vector2(x, y));
  const belt = mesh(new THREE.LatheGeometry(beltPoints, 20), mat('#474537', .9, .06), body); belt.scale.z = .76;
  box(body, [.062, .042, .013], [0, .975, -.128], brass);
  box(body, [.041, .024, .014], [0, .975, -.137], dark);
  // Bent, naturally proportioned arms; gloved support hand meets the forestock.
  const rightArm = new THREE.Group(), leftArm = new THREE.Group(); body.add(rightArm, leftArm);
  const forearmMat = team === 'T' ? fabric('#b48f70', 'skin') : shirt;
  const upperMat = team === 'T' ? forearmMat : shirt;
  taperedLimb(rightArm, [.216, 1.385, -.008], [.278, 1.158, -.146], .054, .042, upperMat, team === 'CT');
  taperedLimb(leftArm, [-.216, 1.385, -.006], [-.255, 1.131, -.192], .054, .042, upperMat, team === 'CT');
  taperedLimb(rightArm, [.278, 1.158, -.146], [.081, 1.193, -.392], .043, .029, forearmMat, team === 'CT');
  taperedLimb(leftArm, [-.255, 1.131, -.192], [-.040, 1.239, -.674], .043, .029, forearmMat, team === 'CT');
  sphere(rightArm, .042, [.278, 1.158, -.146], [1, 1, .94], forearmMat);
  sphere(leftArm, .042, [-.255, 1.131, -.192], [1, 1, .94], forearmMat);
  if (team === 'T') {
    taperedLimb(rightArm, [.214, 1.390, -.006], [.252, 1.255, -.087], .063, .053, shirt, true);
    taperedLimb(leftArm, [-.214, 1.390, -.004], [-.239, 1.245, -.109], .063, .053, shirt, true);
    // Rolled cuffs have thickness, a folded edge and a stitched seam.
    rod(rightArm, [.250, 1.266, -.080], [.255, 1.246, -.093], .055, shirt, .054);
    rod(leftArm, [-.237, 1.256, -.102], [-.241, 1.235, -.116], .055, shirt, .054);
  } else {
    sphere(rightArm, .048, [.279, 1.159, -.138], [1, .95, .72], strap);
    sphere(leftArm, .048, [-.255, 1.132, -.185], [1, .95, .72], strap);
  }
  for (const side of [-1, 1]) {
    sphere(body, .060, [side * .220, 1.365, -.008], [.95, 1.00, .84], shirt);
    if (team === 'CT') {
      box(body, [.009, .060, .054], [side * .276, 1.345, -.014], strap);
      box(body, [.010, .037, .035], [side * .281, 1.348, -.018], mat('#aaa98a', .9, .02));
    }
  }
  glove(rightArm, [.065, 1.185, -.393], .95, [0, 0, -.30]);
  glove(leftArm, [-.031, 1.242, -.688], 1.0, [.40, .1, .55]);
  const heldWeapon = createWeapon(weapon); heldWeapon.position.set(.020, 1.27, -.44); body.add(heldWeapon);
  // Radio, shoulder cable and a compact backpack silhouette.
  box(body, [.11, .20, .065], [.08, 1.30, .129], strap);
  rod(body, [.10, 1.38, .15], [.10, 1.59, .15], .003, dark);
  tube(body, [[.10, 1.35, .15], [.17, 1.48, .10], [.18, 1.42, -.08], [.13, 1.30, -.164]], .004, dark);
  if (team === 'CT') {
    const tank = capsule(body, [-.03, 1.12, .17], [-.03, 1.38, .17], .076, strap);
    tank.scale.z = .62;
  }
  const headGroup = head(body, team);
  root.traverse(object => { if (object instanceof THREE.Mesh && !object.userData.hitZone) object.userData.hitZone = 'body'; });
  root.userData.isCharacter = true;
  root.userData.team = team;
  root.userData.rig = pose;
  root.userData.body = body;
  root.userData.head = headGroup;
  root.userData.leftLeg = leftLeg;
  root.userData.rightLeg = rightLeg;
  root.userData.leftArm = leftArm;
  root.userData.rightArm = rightArm;
  root.userData.weapon = heldWeapon;
  root.userData.deathProgress = 0;
  leftLeg.name = 'left-leg'; rightLeg.name = 'right-leg';
  leftArm.name = 'left-arm'; rightArm.name = 'right-arm'; headGroup.name = 'head'; body.name = 'torso';
  for (const part of [leftLeg, rightLeg, leftArm, rightArm, headGroup]) mergeStatic(part);
  mergeStatic(body, new Set([leftLeg, rightLeg, leftArm, rightArm, headGroup, heldWeapon]));
  return root;
}

/** Animate the internal pose only; navigation, root yaw and hit ownership stay intact. */
export function animateCharacter(group: THREE.Group, time: number, moving: boolean, dead = false): void {
  const d = group.userData;
  if (!d.rig) return;
  const dt = Math.min(.05, Math.max(.001, time - (d.lastAnimationTime ?? time - .016)));
  d.lastAnimationTime = time;
  if (dead) {
    d.deathProgress = Math.min(1, (d.deathProgress || 0) + dt * 3.8);
    const t = d.deathProgress, eased = 1 - Math.pow(1 - t, 3);
    d.rig.position.y = .90 - .68 * eased;
    d.rig.rotation.z = -1.53 * eased;
    d.rig.rotation.x = -.10 * eased;
    d.leftLeg.rotation.x = .23 * eased;
    d.rightLeg.rotation.x = -.19 * eased;
    d.head.rotation.z = -.12 * eased;
    return;
  }
  d.deathProgress = 0;
  d.rig.rotation.set(0, 0, 0);
  const phase = time * 9.4;
  const stride = moving ? Math.sin(phase) * .48 : 0;
  const amount = Math.min(1, dt * 14);
  d.leftLeg.rotation.x = THREE.MathUtils.lerp(d.leftLeg.rotation.x, stride, amount);
  d.rightLeg.rotation.x = THREE.MathUtils.lerp(d.rightLeg.rotation.x, -stride, amount);
  d.rig.position.y = .90 + (moving ? Math.abs(Math.sin(phase)) * .021 : Math.sin(time * 2.1) * .003);
  d.head.rotation.z = Math.sin(time * 1.3) * .012;
  d.body.rotation.y = moving ? Math.sin(phase) * .022 : 0;
}
