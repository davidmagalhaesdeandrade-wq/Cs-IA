import * as THREE from 'three';
/** Original blue-lit equipment vault for the interactive item viewer. */
export function createInspectionStudio(environment: THREE.Texture) {
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#101b28');
    scene.environment = environment;
    scene.environmentIntensity = .8;
    scene.fog = new THREE.Fog('#14283c', 4, 20);
    scene.add(new THREE.HemisphereLight(0xc7e4ff, 0x223040, 2));
    const key = new THREE.DirectionalLight(0xd7efff, 4);
    key.position.set(21, 5, -15);
    scene.add(key);
    const rim = new THREE.PointLight(0x7dc8ff, 45, 12);
    rim.position.set(25, 3, -19);
    scene.add(rim);
    const fill = new THREE.PointLight(0xffe3ae, 20, 10);
    fill.position.set(21, 2, -16);
    scene.add(fill);
    const materials = { floor: new THREE.MeshStandardMaterial({ color: 0x263747, roughness: .5, metalness: .4 }), crate: new THREE.MeshStandardMaterial({ color: 0x354859, roughness: .75, metalness: .25 }), edge: new THREE.MeshStandardMaterial({ color: 0x151e28, roughness: .5, metalness: .6 }), handle: new THREE.MeshStandardMaterial({ color: 0x6e8290, roughness: .4, metalness: .8 }), light: new THREE.MeshBasicMaterial({ color: 0xc0e6ff }) };
    function box(x: number, y: number, z: number, w: number, h: number, d: number, mat: THREE.Material) { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); scene.add(m); return m; }
    box(23, -.08, -23, 12, .15, 25, materials.floor);
    box(23, 3.7, -23, 12, .2, 25, materials.edge);
    box(23, 2, -33, 12, 5, .2, materials.crate);
    for (let row = 0; row < 7; row++) {
        const z = -18 - row * 2.3;
        for (const side of [-1, 1]) {
            const x = 23 + side * 2.5;
            for (let level = 0; level < 3; level++) {
                const y = .5 + level * 1.05;
                box(x, y, z, 1.2, .85, 1.9, materials.crate);
                for (const off of [-.42, .42])
                    box(x + off, y, z, .045, .9, 1.95, materials.edge);
                box(x - side * .62, y, z, .035, .13, .4, materials.handle);
                box(x - side * .64, y - .03, z, .035, .1, .27, materials.edge);
            }
            box(x, 1.0, z, 1.4, .08, 2.1, materials.edge);
            box(x, 2.05, z, 1.4, .08, 2.1, materials.edge);
            for (const off of [-.62, .62])
                box(x + off, 1.5, z - .98, .07, 3, .07, materials.handle);
        }
        box(23, 3.55, z, .35, .025, .6, materials.light);
    }
    return scene;
}
