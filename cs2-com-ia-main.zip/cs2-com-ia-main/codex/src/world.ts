import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export type Collider = { minX: number; maxX: number; minZ: number; maxZ: number; bottom: number; top: number };

/** A self-contained, locally textured, walkable North African training map. */
export function createWorld() {
  const group = new THREE.Group();
  group.name = 'Dust — old city';
  const colliders: Collider[] = [];
  const solidMeshes: THREE.Object3D[] = [];
  const random = (() => { let seed = 43871; return () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; }; })();

  function texture(kind: 'plaster' | 'stone' | 'ground' | 'wood' | 'metal', base: string) {
    const canvas = document.createElement('canvas'); canvas.width = canvas.height = 512;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = base; ctx.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 21000; i++) {
      const light = random() > .5; ctx.fillStyle = light ? `rgba(255,246,219,${random() * .13})` : `rgba(50,38,21,${random() * .11})`;
      const s = 1 + random() * 4; ctx.fillRect(random() * 512, random() * 512, s, s);
    }
    if (kind === 'plaster') {
      for (let i = 0; i < 38; i++) {
        const x = random() * 512, y = random() * 512;
        ctx.fillStyle = `rgba(94,77,48,${.025 + random() * .06})`;
        ctx.beginPath(); ctx.ellipse(x, y, 10 + random() * 60, 2 + random() * 22, random() * 3, 0, Math.PI * 2); ctx.fill();
      }
      ctx.strokeStyle = 'rgba(77,65,43,.13)'; ctx.lineWidth = .7;
      for (let i = 0; i < 10; i++) { let x = random() * 512, y = random() * 512; ctx.beginPath(); ctx.moveTo(x, y); for (let n = 0; n < 5; n++) { x += random() * 16 - 8; y += random() * 20; ctx.lineTo(x, y); } ctx.stroke(); }
    }
    if (kind === 'stone' || kind === 'ground') {
      const rows = kind === 'stone' ? 8 : 4, height = 512 / rows;
      ctx.lineWidth = kind === 'stone' ? 3 : 2;
      ctx.strokeStyle = kind === 'stone' ? 'rgba(74,60,39,.24)' : 'rgba(238,222,180,.55)';
      for (let row = 0; row < rows; row++) {
        const offset = row % 2 ? -64 : 0;
        for (let x = offset; x < 512; x += kind === 'stone' ? 128 : 171) {
          const w = kind === 'stone' ? 128 : 171;
          ctx.fillStyle = `rgba(${random() > .5 ? '255,238,191' : '78,61,38'},${.025 + random() * .055})`;
          ctx.fillRect(x + 2, row * height + 2, w - 4, height - 4); ctx.strokeRect(x, row * height, w, height);
        }
      }
    }
    if (kind === 'wood') {
      for (let i = 0; i < 100; i++) { ctx.strokeStyle = `rgba(54,37,20,${.04 + random() * .16})`; ctx.beginPath(); const y = random() * 512; ctx.moveTo(0, y); ctx.bezierCurveTo(150, y + random() * 10, 340, y - random() * 10, 512, y + random() * 5); ctx.stroke(); }
      ctx.strokeStyle = 'rgba(53,35,18,.45)'; ctx.lineWidth = 3; for (let y = 0; y < 512; y += 85) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(512, y); ctx.stroke(); }
      for (let i = 0; i < 9; i++) { ctx.strokeStyle = 'rgba(50,34,20,.22)'; ctx.beginPath(); ctx.ellipse(random() * 512, random() * 512, 12, 3, 0, 0, Math.PI * 2); ctx.stroke(); }
    }
    if (kind === 'metal') { for (let i = 0; i < 40; i++) { ctx.fillStyle = 'rgba(112,64,30,.09)'; ctx.fillRect(random() * 512, random() * 512, 1 + random() * 80, 2); } }
    const map = new THREE.CanvasTexture(canvas); map.colorSpace = THREE.SRGBColorSpace; map.wrapS = map.wrapT = THREE.RepeatWrapping; map.anisotropy = 8;
    return map;
  }
  const plaster = new THREE.MeshStandardMaterial({ map: texture('plaster', '#c4aa7b'), roughness: .97 });
  const cream = new THREE.MeshStandardMaterial({ map: texture('plaster', '#d7c39b'), roughness: 1 });
  const ochre = new THREE.MeshStandardMaterial({ map: texture('plaster', '#ad8c5d'), roughness: 1 });
  const stone = new THREE.MeshStandardMaterial({ map: texture('stone', '#b4a284'), roughness: 1 });
  const ground = new THREE.MeshStandardMaterial({ map: texture('ground', '#b4a58b'), roughness: 1 });
  const wood = new THREE.MeshStandardMaterial({ map: texture('wood', '#88704c'), roughness: .96 });
  const woodLight = new THREE.MeshStandardMaterial({ map: texture('wood', '#aa9063'), roughness: .94 });
  const steel = new THREE.MeshStandardMaterial({ map: texture('metal', '#4c514b'), metalness: .55, roughness: .64 });
  const dark = new THREE.MeshStandardMaterial({ color: '#242d2b', roughness: .9 });
  const shutter = new THREE.MeshStandardMaterial({ map: texture('wood', '#4b6d66'), roughness: .95 });
  const trim = new THREE.MeshStandardMaterial({ color: '#dbca9e', roughness: .9 });
  const rust = new THREE.MeshStandardMaterial({ color: '#805b3c', roughness: .82, metalness: .25 });
  const red = new THREE.MeshStandardMaterial({ color: '#a34b35', roughness: 1 });

  function addSolid(mesh: THREE.Mesh, solid = true) { mesh.castShadow = true; mesh.receiveShadow = true; group.add(mesh); if (solid) solidMeshes.push(mesh); return mesh; }
  function collision(x: number, z: number, w: number, d: number, bottom: number, top: number) { colliders.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2, bottom, top }); }
  function box(x: number, y: number, z: number, w: number, h: number, d: number, material: THREE.Material, collide = false, shoot = true) {
    const geo = new THREE.BoxGeometry(w, h, d);
    const uv = geo.getAttribute('uv');
    const dimensions = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
    for (let face = 0; face < 6; face++) for (let p = 0; p < 4; p++) { const i = face * 4 + p; uv.setXY(i, uv.getX(i) * dimensions[face][0] / 3, uv.getY(i) * dimensions[face][1] / 3); }
    const m = new THREE.Mesh(geo, material); m.position.set(x, y, z); addSolid(m, shoot); if (collide) collision(x, z, w, d, y - h / 2, y + h / 2); return m;
  }
  function cylinder(x: number, y: number, z: number, r1: number, r2: number, height: number, material: THREE.Material, segments = 12, shoot = true) { const m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, height, segments), material); m.position.set(x, y, z); return addSolid(m, shoot); }
  function tube(points: THREE.Vector3[], radius: number, material: THREE.Material, segments = 20) { const m = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), segments, radius, 5, false), material); return addSolid(m, false); }

  // Sunlight and cool bounce light preserve the bright, dusty look inside corridors.
  group.add(new THREE.HemisphereLight('#dceeff', '#8a785b', 2.5));
  const sun = new THREE.DirectionalLight('#fff1d0', 3.5); sun.position.set(-24, 48, 18); sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048); sun.shadow.camera.left = -48; sun.shadow.camera.right = 48; sun.shadow.camera.top = 48; sun.shadow.camera.bottom = -48; sun.shadow.camera.near = 1; sun.shadow.camera.far = 120; sun.shadow.normalBias = .035; sun.shadow.bias = -.00015; sun.shadow.radius = 3;
  group.add(sun); group.add(sun.target);
  box(0, -.16, 0, 94, .3, 94, ground, false);

  function facadeWindow(x: number, y: number, z: number, rotation = 0, shutters = true) {
    const frame = new THREE.Group(); frame.position.set(x, y, z); frame.rotation.y = rotation;
    const make = (xx: number, yy: number, zz: number, w: number, h: number, d: number, mat: THREE.Material) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(xx, yy, zz); m.castShadow = true; frame.add(m); };
    make(0, 0, 0, 1.1, 1.55, .08, dark);
    make(-.61, 0, .04, .16, 1.83, .16, stone); make(.61, 0, .04, .16, 1.83, .16, stone); make(0, .85, .04, 1.36, .16, .16, stone); make(0, -.85, .15, 1.5, .16, .37, trim);
    if (shutters) {
      make(-.29, 0, .08, .5, 1.48, .1, shutter); make(.29, 0, .08, .5, 1.48, .1, shutter);
      for (let i = 0; i < 7; i++) make(0, -.62 + i * .2, .15, 1.05, .055, .07, shutter);
      make(0, 0, .2, .035, 1.5, .035, dark);
    } else {
      for (let i = -2; i <= 2; i++) make(i * .19, 0, .14, .025, 1.56, .025, rust);
      make(0, 0, .14, 1.05, .03, .03, rust);
    }
    group.add(frame);
  }

  function building(x: number, z: number, w: number, d: number, h: number, mat = plaster, windows = true) {
    box(x, h / 2, z, w, h, d, mat, true);
    box(x, .48, z, w + .14, .95, d + .14, stone, false);
    box(x, h - .1, z, w + .4, .23, d + .4, trim, false);
    box(x, h + .32, z - d / 2 + .12, w, .64, .24, mat); box(x, h + .32, z + d / 2 - .12, w, .64, .24, mat);
    box(x - w / 2 + .12, h + .32, z, .24, .64, d, mat); box(x + w / 2 - .12, h + .32, z, .24, .64, d, mat);
    // Eroded bands give facades a legible human scale.
    if (h > 7) { box(x, 3.8, z - d / 2 - .035, w, .12, .12, stone); box(x, 3.8, z + d / 2 + .035, w, .12, .12, stone); }
    if (windows) {
      const n = Math.max(1, Math.floor(w / 3.1));
      for (let i = 0; i < n; i++) { const px = x - w / 2 + (i + .5) * w / n; facadeWindow(px, Math.min(5.2, h - 2), z + d / 2 + .06, 0, i % 3 !== 1); facadeWindow(px, Math.min(5.2, h - 2), z - d / 2 - .06, Math.PI, i % 3 !== 0); }
      const count = Math.max(1, Math.floor(d / 4));
      for (let i = 0; i < count; i++) { const pz = z - d / 2 + (i + .5) * d / count; facadeWindow(x - w / 2 - .06, Math.min(5.2, h - 2), pz, -Math.PI / 2, i % 2 === 0); facadeWindow(x + w / 2 + .06, Math.min(5.2, h - 2), pz, Math.PI / 2, i % 2 !== 0); }
    }
    return h;
  }

  // The occupied blocks define three different routes, with connectors around them.
  building(-13.2, 8.7, 13.2, 11, 8.4, cream);
  building(13, 10.5, 13.5, 12, 9.5, plaster);
  building(-13.4, -12.4, 13, 11.2, 10.2, plaster);
  building(13, -10, 12.5, 10.5, 11.1, cream);
  // Crooked wings break up long sightlines while keeping every route connected.
  building(-9.8, 19, 6, 4.2, 6.3, ochre, false);
  building(8.2, -22.9, 8.5, 4, 7.8, ochre);
  building(-9.2, -26.8, 8, 6, 8.5, cream);
  building(26, 28.8, 13, 8, 8, ochre);
  building(-27.7, 28.8, 13, 8, 9, plaster);

  // Irregular city perimeter; facades and skyline extend beyond the walkable lanes.
  building(-36, -7, 6, 55, 9.7, cream);
  building(36, -5, 6, 57, 11.6, plaster);
  building(-23, -32.2, 23, 5, 8.1, ochre);
  building(22.8, -32.5, 24, 5.5, 12, cream);
  building(0, -37, 23, 6, 12, plaster);
  box(0, 3.1, 34.3, 70, 6.2, .8, ochre, true);
  box(0, 6.25, 34.3, 70.5, .18, 1.1, trim);
  box(-33, 1.7, 24, 1, 3.4, 10, stone, true);
  box(33, 1.7, 23, 1, 3.4, 8, stone, true);

  function gateway(x: number, z: number, width: number, passage: number, height: number, rotation = 0, mat = stone) {
    const spring = 2.3, radius = passage / 2, depth = 1.1;
    // The opening reaches the bottom edge, so use a concave outline rather
    // than a hole touching the outer polygon (which triangulates as a wall).
    const shape = new THREE.Shape(); shape.moveTo(-width / 2, 0); shape.lineTo(-radius, 0); shape.lineTo(-radius, spring); shape.absarc(0, spring, radius, Math.PI, 0, true); shape.lineTo(radius, 0); shape.lineTo(width / 2, 0); shape.lineTo(width / 2, height); shape.lineTo(-width / 2, height); shape.closePath();
    const mesh = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: false, curveSegments: 24 }), mat); mesh.position.set(x, 0, z); mesh.rotation.y = rotation; mesh.translateZ(-depth / 2); addSolid(mesh);
    const frame = new THREE.Mesh(new THREE.TorusGeometry(radius + .12, .19, 8, 32, Math.PI), trim); frame.position.set(x, spring, z); frame.rotation.y = rotation; frame.translateZ(depth / 2 + .03); addSolid(frame, false);
    for (const side of [-1, 1]) {
      const local = new THREE.Vector3(side * (radius + .13), spring / 2, depth / 2 + .04).applyAxisAngle(new THREE.Vector3(0, 1, 0), rotation);
      const pillar = box(x + local.x, local.y, z + local.z, .34, spring, .28, trim, false); pillar.rotation.y = rotation;
      const sideW = (width - passage) / 2;
      const p = new THREE.Vector3(side * (passage / 2 + sideW / 2), 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), rotation);
      collision(x + p.x, z + p.z, rotation === 0 ? sideW : depth, rotation === 0 ? depth : sideW, 0, height);
    }
    collision(x, z, rotation === 0 ? passage : depth, rotation === 0 ? depth : passage, spring + radius - .12, height);
  }

  gateway(0, -20, 9.4, 5.4, 7.5, 0, plaster);
  gateway(25.5, 17.7, 14.2, 6.4, 7.1, 0, cream);
  gateway(-25.9, 16.2, 13.4, 5.5, 6.8, 0, ochre);
  gateway(-25.9, -7.7, 13.4, 5.5, 6.5, 0, ochre);

  // West tunnels: a shaded, roofed route with stone ribs, side exits and warm lamps.
  box(-31.5, 2.5, 4, 1.2, 5, 23.5, stone, true);
  box(-20.9, 2.5, 9.8, 1.2, 5, 10.9, stone, true);
  box(-20.9, 2.5, -5.7, 1.2, 5, 3.9, stone, true);
  box(-26.1, 5.1, 4, 11.7, .5, 24.2, stone, true);
  for (const pz of [-6, .5, 7, 13.5]) {
    box(-30.65, 2.4, pz, .45, 4.8, .6, trim); if (pz !== .5) box(-21.75, 2.4, pz, .45, 4.8, .6, trim); box(-26.2, 4.7, pz, 9.4, .36, .6, trim);
    const lamp = new THREE.PointLight('#ffd29a', 11, 9, 2); lamp.position.set(-26, 4.2, pz); group.add(lamp);
    box(-26, 4.65, pz, .6, .12, .3, dark); const bulb = new THREE.Mesh(new THREE.SphereGeometry(.08, 6, 5), new THREE.MeshBasicMaterial({ color: '#ffe4af' })); bulb.position.set(-26, 4.48, pz); group.add(bulb);
  }
  // The center side opening remains clear (z -3.75..4.35).
  gateway(-20.9, .25, 8, 4.4, 5, Math.PI / 2, stone);

  // A long low wall and a recessed door make the eastern lane feel like a street.
  box(31.9, 1.15, 3, 1, 2.3, 21, stone, true); box(31.9, 2.35, 3, 1.2, .16, 21.3, trim);
  box(20.5, 1.2, -22.7, 1.1, 2.4, 6.2, stone, true);
  box(-17.6, .9, -23.2, .85, 1.8, 5, stone, true);

  // Rooftop silhouettes: a tiled dome, minaret, water tanks and television antennas.
  cylinder(-12.2, 11, -12.4, 2.7, 2.7, 1.5, cream, 24);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(2.8, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: '#8ba7a2', roughness: .65, metalness: .14 })); dome.position.set(-12.2, 11.7, -12.4); addSolid(dome);
  cylinder(-12.2, 14.62, -12.4, .045, .07, .52, rust, 8);
  building(-36.4, -29.5, 3.8, 3.8, 19.6, cream, false);
  box(-36.4, 15.8, -29.5, 4.4, .3, 4.4, trim); box(-36.4, 18.2, -29.5, 4.3, .35, 4.3, trim);
  const roof = new THREE.Mesh(new THREE.ConeGeometry(2.8, 2, 4), new THREE.MeshStandardMaterial({ color: '#70908b', roughness: .85 })); roof.position.set(-36.4, 21, -29.5); roof.rotation.y = Math.PI / 4; addSolid(roof);
  for (const p of [[13, 10.5, 9.5], [30, -32, 12], [-10, 8, 8.4]]) {
    const [x, z, h] = p;
    cylinder(x + 1.4, h + 1, z - 1.3, 1.08, 1.08, 1.7, steel, 16);
    cylinder(x + 1.4, h + 1.88, z - 1.3, 1.12, 1.12, .08, dark, 16);
    box(x - 2, h + .75, z + 1.1, 1.3, 1.5, 1.1, stone);
    cylinder(x - 2, h + 2.1, z + 1.1, .025, .025, 2.1, rust, 5);
    for (let k = 0; k < 3; k++) box(x - 2, h + 2.3 + k * .25, z + 1.1, 1.8 - k * .3, .025, .035, rust);
  }

  function wallSign(text: string, x: number, y: number, z: number, width: number, rotation = 0, bg = '#264347', fg = '#eee2bd') {
    const c = document.createElement('canvas'); c.width = 768; c.height = 240; const ctx = c.getContext('2d')!;
    ctx.fillStyle = bg; ctx.fillRect(0, 0, c.width, c.height); ctx.strokeStyle = fg; ctx.lineWidth = 5; ctx.strokeRect(12, 12, 744, 216);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = fg; ctx.font = `bold ${text.length > 20 ? 43 : 58}px Arial`; ctx.fillText(text, 384, 123);
    for (let i = 0; i < 250; i++) { ctx.fillStyle = `rgba(220,200,157,${random() * .16})`; ctx.fillRect(random() * 768, random() * 240, random() * 14, random() * 4); }
    const map = new THREE.CanvasTexture(c); map.colorSpace = THREE.SRGBColorSpace;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(width, width * 240 / 768), new THREE.MeshStandardMaterial({ map, roughness: .9 })); m.position.set(x, y, z); m.rotation.y = rotation; group.add(m); return m;
  }
  wallSign('HÔTEL AURORE  ★★★', 13, 3.1, 16.57, 5.6);
  wallSign('CAFÉ  ·  مقهى', -12, 3.1, 14.27, 4.6, 0, '#4c6b65');
  wallSign('RUE PRINCIPALE', 19.31, 3, -8.5, 3.7, Math.PI / 2);
  wallSign('ZONE A  →', 19.32, 2.15, -4.8, 2.3, Math.PI / 2, '#e4d3a9', '#9e3927');
  wallSign('←  B', -6.83, 2.15, -9, 1.8, Math.PI / 2, '#e4d3a9', '#9e3927');
  wallSign('ENTREPÔT  /  مخزن', -26, 5.15, 16.8, 5.1, 0, '#72553a');
  wallSign('SECTEUR CENTRAL', 0, 6.5, -19.42, 4.2, 0, '#73604a');

  function door(x: number, z: number, rotation = 0, material = wood) {
    const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = rotation;
    const shape = new THREE.Shape(); shape.moveTo(-.85, 0); shape.lineTo(.85, 0); shape.lineTo(.85, 2.1); shape.absarc(0, 2.1, .85, 0, Math.PI, false); shape.closePath();
    const m = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth: .1, bevelEnabled: false, curveSegments: 18 }), material); m.castShadow = true; g.add(m);
    const torus = new THREE.Mesh(new THREE.TorusGeometry(.99, .16, 6, 24, Math.PI), stone); torus.position.set(0, 2.1, .04); g.add(torus);
    for (const side of [-1, 1]) { const p = new THREE.Mesh(new THREE.BoxGeometry(.3, 2.1, .22), stone); p.position.set(side * .99, 1.05, .03); g.add(p); }
    for (let y = .45; y < 2.3; y += .8) { const bar = new THREE.Mesh(new THREE.BoxGeometry(1.55, .1, .1), dark); bar.position.set(0, y, .12); g.add(bar); }
    const seam = new THREE.Mesh(new THREE.BoxGeometry(.025, 2.75, .04), dark); seam.position.set(0, 1.375, .15); g.add(seam);
    for (const side of [-1, 1]) { const handle = new THREE.Mesh(new THREE.TorusGeometry(.065, .015, 5, 12), steel); handle.position.set(side * .15, 1.15, .18); g.add(handle); }
    group.add(g);
  }
  door(9.4, 16.56); door(-14, 14.25, 0, shutter); door(32.94, -12, -Math.PI / 2, shutter); door(-19.96, 8, -Math.PI / 2); door(5.02, 8.9, -Math.PI / 2); door(32.94, 8.6, -Math.PI / 2); door(-25, -29.65);

  function crate(x: number, z: number, w = 2.4, h = 2.2, d = 2.2, y = 0) {
    box(x, y + h / 2, z, w, h, d, woodLight, true);
    for (const side of [-1, 1]) {
      for (const xx of [-w / 2 + .14, w / 2 - .14]) box(x + xx, y + h / 2, z + side * (d / 2 + .045), .16, h + .03, .11, wood);
      for (const yy of [.13, h - .13]) box(x, y + yy, z + side * (d / 2 + .06), w + .03, .2, .12, wood);
      const strap = box(x + w * .22, y + h / 2, z + side * (d / 2 + .13), .085, h, .045, steel); strap.rotation.z = .06;
      box(x + side * (w / 2 + .03), y + .14, z, .12, .2, d, wood); box(x + side * (w / 2 + .03), y + h - .14, z, .12, .2, d, wood);
    }
    box(x, y + h + .04, z, w * .95, .08, d * .98, wood);
    box(x - w * .3, y + h + .09, z, .12, .05, d, steel); box(x + w * .3, y + h + .09, z, .12, .05, d, steel);
  }
  // Carefully placed cover leaves wide lanes and exposes alternate angles.
  crate(24.8, -20.6, 3.8, 2.3, 2.9); crate(24.8, -20.6, 2.6, 1.7, 2.5, 2.35);
  crate(29, -24.1, 3, 2.6, 3); crate(29, -24.1, 2.65, 2.4, 2.65, 2.68);
  crate(22.2, -11.5, 2.1, 1.25, 1.9);
  crate(-27, -20, 3.5, 2.2, 2.8); crate(-27, -20, 2.65, 1.8, 2.5, 2.28);
  crate(-21.5, -27.1, 4.1, 2.5, 2.6);
  crate(-1.5, -7.1, 2.3, 1.55, 2.1);
  crate(2.35, 8.1, 1.9, 1.9, 2.1);
  crate(28.7, 7.4, 2.5, 1.3, 2.5);
  crate(-29.7, 9.8, 1.6, 1.6, 2.3);
  crate(-14.6, 24.3, 2.9, 1.6, 2.1);

  function barrel(x: number, z: number, material = steel) {
    cylinder(x, .62, z, .42, .43, 1.24, material, 16); collision(x, z, .86, .86, 0, 1.24);
    for (const y of [.1, .36, .94, 1.16]) cylinder(x, y, z, .44, .44, .055, dark, 16);
    cylinder(x, 1.25, z, .4, .4, .025, dark, 16); cylinder(x + .15, 1.28, z, .04, .04, .04, steel, 8);
  }
  barrel(30.5, -12); barrel(30, -10.9, rust); barrel(-30.5, -16.5); barrel(-29.5, -16.7, rust); barrel(-18, 2); barrel(-17, 2.1, rust); barrel(8, 24, rust);

  // Bombsite stencils lie flat on the same ground as players and cover.
  function stencil(letter: string, x: number, z: number) {
    const c = document.createElement('canvas'); c.width = c.height = 512; const ctx = c.getContext('2d')!;
    ctx.translate(256, 256); ctx.strokeStyle = '#a13d29'; ctx.fillStyle = '#a13d29'; ctx.lineWidth = 17; ctx.beginPath(); ctx.arc(0, 0, 185, .1, Math.PI * 2 - .08); ctx.stroke(); ctx.rotate(-.13); ctx.font = 'bold 330px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(letter, 0, 10);
    ctx.globalCompositeOperation = 'destination-out'; for (let i = 0; i < 1500; i++) ctx.clearRect(random() * 512 - 256, random() * 512 - 256, random() * 7, random() * 5);
    const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
    const plane = new THREE.Mesh(new THREE.PlaneGeometry(5.5, 5.5), new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: .8, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1 })); plane.rotation.x = -Math.PI / 2; plane.rotation.z = -.12; plane.position.set(x, .012, z); group.add(plane);
  }
  stencil('A', 26, -14.6); stencil('B', -24.5, -24.1);

  // Cylindrical shells on site A echo the memorable stacked munitions cover.
  const shellMat = new THREE.MeshStandardMaterial({ color: '#aaa47a', metalness: .22, roughness: .63 });
  for (let i = 0; i < 3; i++) {
    const shell = cylinder(23.5 + i * .77, 3.04, -20.6, .26, .29, 1.4, shellMat, 12); shell.rotation.x = Math.PI / 2;
    const rim = cylinder(23.5 + i * .77, 3.04, -19.88, .31, .31, .08, steel, 12); rim.rotation.x = Math.PI / 2;
  }

  function palm(x: number, z: number, height = 9) {
    const bark = new THREE.MeshStandardMaterial({ color: '#867251', roughness: 1 });
    const leaves = new THREE.MeshStandardMaterial({ color: '#526e42', roughness: .85, side: THREE.DoubleSide });
    const lean = .6;
    for (let i = 0; i < 12; i++) {
      const y = height * (i + .5) / 12; const trunk = cylinder(x + lean * (y / height) ** 2, y, z, .18 + (1 - i / 12) * .1, .2 + (1 - i / 12) * .12, height / 12 + .035, bark, 9, false); trunk.rotation.z = -lean / height;
      cylinder(x + lean * (y / height) ** 2, y - height / 25, z, .21 + (1 - i / 12) * .12, .21 + (1 - i / 12) * .12, .08, bark, 9, false);
    }
    for (let a = 0; a < 9; a++) {
      const angle = a * Math.PI * 2 / 9 + .2, len = 2.9 + random() * 1.2;
      const points: THREE.Vector3[] = [];
      for (let i = 0; i <= 8; i++) { const t = i / 8; points.push(new THREE.Vector3(x + lean + Math.cos(angle) * len * t, height + .6 * Math.sin(t * Math.PI) - 1.2 * t * t, z + Math.sin(angle) * len * t)); }
      tube(points, .025, bark, 12);
      const vertices: number[] = [];
      for (let i = 1; i < 9; i++) {
        const t = i / 9, center = new THREE.Vector3(x + lean + Math.cos(angle) * len * t, height + .6 * Math.sin(t * Math.PI) - 1.2 * t * t, z + Math.sin(angle) * len * t);
        const length = .75 * Math.sin(t * Math.PI) + .15;
        for (const side of [-1, 1]) {
          const end = center.clone().add(new THREE.Vector3(Math.cos(angle + side * 1.05) * length, -.18, Math.sin(angle + side * 1.05) * length));
          const next = center.clone().add(new THREE.Vector3(Math.cos(angle) * .24, .015, Math.sin(angle) * .24)); vertices.push(...center.toArray(), ...end.toArray(), ...next.toArray());
        }
      }
      const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3)); geo.computeVertexNormals(); const leaf = new THREE.Mesh(geo, leaves); leaf.castShadow = true; group.add(leaf);
    }
  }
  palm(29.8, 20.8, 10); palm(-29.6, 21.6, 9.5); palm(31, -27.7, 11); palm(-31.1, -27.1, 10.7); palm(12, 31, 11);

  // Awnings, drainpipes, wall lamps, satellite dishes, overhead wires and street litter.
  for (const p of [[12.5, 16.7], [-12.3, 14.3]]) {
    const [x, z] = p; const awning = box(x, 3, z + .75, 4.8, .07, 1.6, new THREE.MeshStandardMaterial({ color: '#677f72', roughness: 1, side: THREE.DoubleSide }), false, false); awning.rotation.x = .16;
    for (const side of [-1, 1]) { cylinder(x + side * 2.25, 1.45, z + 1.4, .035, .035, 2.9, rust, 6, false); }
  }
  for (const p of [[5.95, 15.8, 9], [-6.85, 13.7, 8], [19.4, -14.6, 10.8]]) {
    const [x, z, h] = p; cylinder(x, h / 2, z, .07, .07, h, rust, 8, false); cylinder(x, .45, z, .11, .11, .15, rust, 8, false);
  }
  const cableMat = new THREE.MeshStandardMaterial({ color: '#343c38', roughness: .95 });
  tube([new THREE.Vector3(-6.2, 7, 9), new THREE.Vector3(0, 6, 8), new THREE.Vector3(6.2, 8.2, 6)], .018, cableMat);
  tube([new THREE.Vector3(-19.8, 7, -10), new THREE.Vector3(-25, 5.8, -12), new THREE.Vector3(-33, 7.5, -14)], .023, cableMat);
  tube([new THREE.Vector3(19.5, 8.3, 3), new THREE.Vector3(26.5, 6.5, 3), new THREE.Vector3(33, 9, 3)], .018, cableMat);
  tube([new THREE.Vector3(-5, 8.4, -12), new THREE.Vector3(1, 6.3, -10), new THREE.Vector3(6.7, 9.5, -11)], .02, cableMat);
  for (const p of [[11, 12, 10], [-12, -11, 11], [28, -31, 12.5]]) {
    const [x, z, y] = p; const dish = new THREE.Mesh(new THREE.SphereGeometry(.7, 12, 8, 0, Math.PI * 2, 0, Math.PI * .42), steel); dish.position.set(x, y + .5, z); dish.rotation.x = .7; addSolid(dish, false); cylinder(x, y, z, .045, .045, .9, steel, 6, false);
  }
  for (const p of [[19.4, 2.4], [-6.55, -14], [5.1, 12.7], [-19.9, 11]]) {
    const [x, z] = p; box(x, 3.4, z, .35, .6, .3, dark, false, false); box(x, 3.4, z + .16, .25, .4, .025, new THREE.MeshBasicMaterial({ color: '#e8d7a8' }), false, false);
  }
  for (let i = 0; i < 35; i++) {
    // Confine loose debris to edges instead of filling combat lanes.
    const side = i % 2 ? 1 : -1, x = side * (30.9 + random() * 1.4), z = -26 + random() * 51;
    const paper = box(x, .015, z, .12 + random() * .3, .012, .12 + random() * .2, i % 3 ? cream : steel, false, false); paper.rotation.y = random() * Math.PI;
  }

  // Open courtyards gain pavement edges and drains without invisible collision.
  for (const x of [-32.5, 32.5]) box(x, .035, -2, .18, .07, 57, stone, false, false);
  for (const p of [[0, 21], [24, 4], [-25, -12], [1, -16]]) {
    const [x, z] = p; box(x, .014, z, .8, .02, .38, dark, false, false);
    for (let i = 0; i < 7; i++) box(x - .33 + i * .11, .03, z, .045, .025, .4, steel, false, false);
  }

  const sites = { A: new THREE.Vector3(24, 0, -18), B: new THREE.Vector3(-24, 0, -18) };
  const spawns = { T: new THREE.Vector3(0, 0, 26), CT: new THREE.Vector3(0, 0, -26) };
  const groundHeight = (_x: number, _z: number) => 0;
  const location = (x: number, z: number) => {
    if (z > 21) return 'BASE T';
    if (z < -22 && Math.abs(x) < 9) return 'BASE CT';
    if (x > 19 && z < -10) return 'BOMB A';
    if (x < -19 && z < -12) return 'BOMB B';
    if (x < -20 && z < 17) return 'TÚNEIS';
    if (x > 20) return 'LONGA A';
    if (Math.abs(x) < 6) return z < -10 ? 'PORTAS DO MEIO' : 'MEIO';
    if (z > 14) return 'PÁTIO T';
    return x > 0 ? 'PASSAGEM A' : 'PASSAGEM B';
  };

  // Static detail shares a few materials. Bake it into material batches so the
  // hundreds of shutters, stone trims and palm leaflets cost only a few draws.
  group.updateMatrixWorld(true);
  const raycastObjects = new Set(solidMeshes);
  const batches = new Map<string, { material: THREE.Material; meshes: THREE.Mesh[]; geometries: THREE.BufferGeometry[]; solid: boolean; cast: boolean; receive: boolean }>();
  group.traverse(object => {
    if (!(object instanceof THREE.Mesh) || Array.isArray(object.material) || object.material.transparent) return;
    const solid = raycastObjects.has(object);
    const attributes = Object.keys(object.geometry.attributes).sort().join(',');
    const key = `${object.material.uuid}/${solid}/${object.castShadow}/${object.receiveShadow}/${attributes}/${!!object.geometry.index}`;
    let batch = batches.get(key);
    if (!batch) { batch = { material: object.material, meshes: [], geometries: [], solid, cast: object.castShadow, receive: object.receiveShadow }; batches.set(key, batch); }
    batch.meshes.push(object); batch.geometries.push(object.geometry.clone().applyMatrix4(object.matrixWorld));
  });
  solidMeshes.length = 0;
  for (const batch of batches.values()) {
    const geometry = mergeGeometries(batch.geometries, false);
    if (!geometry) { for (const mesh of batch.meshes) if (batch.solid) solidMeshes.push(mesh); continue; }
    const mesh = new THREE.Mesh(geometry, batch.material); mesh.castShadow = batch.cast; mesh.receiveShadow = batch.receive;
    mesh.name = batch.solid ? 'Architecture and cover' : 'Facade details';
    for (const original of batch.meshes) { original.removeFromParent(); original.geometry.dispose(); }
    for (const original of batch.geometries) original.dispose();
    group.add(mesh); if (batch.solid) solidMeshes.push(mesh);
  }

  return { group, colliders, solidMeshes, sites, spawns, groundHeight, location };
}
