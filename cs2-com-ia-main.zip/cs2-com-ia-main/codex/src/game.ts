import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { createWorld } from './world';
import { createWeapon, createCharacter, animateCharacter, createArms } from './models';
import { UI } from './ui';
import { WEAPONS, PRICES, defaults, readStore, saveStore, other, type Team } from './data';
import { Navigation, moveBody, segmentBlocked, blocked } from './navigation';
import { AudioSystem } from './audio';
import { winnerFor, damageAfterArmor, canAfford } from './rules';
import { createInspectionStudio } from './presentation';
interface Actor {
    id: number;
    name: string;
    team: Team;
    pos: THREE.Vector3;
    health: number;
    armor: number;
    helmet: boolean;
    money: number;
    kills: number;
    deaths: number;
    weapon: string;
    alive: boolean;
    model?: THREE.Group;
    path?: THREE.Vector3[];
    goal?: THREE.Vector3;
    route?: THREE.Vector3[];
    routeIndex?: number;
    think?: number;
    attack?: number;
    reaction?: number;
    target?: Actor;
    moving?: boolean;
    state?: string;
    ammo?: number;
    reload?: number;
}
interface Item {
    id: string;
    ammo: number;
    reserve: number;
}
interface Particle {
    mesh: THREE.Object3D;
    velocity: THREE.Vector3;
    life: number;
    maxLife: number;
    gravity?: number;
}
interface Grenade {
    id: string;
    mesh: THREE.Group;
    velocity: THREE.Vector3;
    life: number;
    owner: Actor;
}
const V = THREE.Vector3;
const names = ['Viper', 'Atlas', 'Ghost', 'Nomad', 'Rook', 'Sable', 'Wolf', 'Echo', 'Blaze', 'Falcon'];
export class Game {
    renderer: THREE.WebGLRenderer;
    scene = new THREE.Scene();
    inspectionScene: THREE.Scene;
    camera = new THREE.PerspectiveCamera(80, innerWidth / innerHeight, .06, 170);
    viewScene = new THREE.Scene();
    viewCamera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, .03, 10);
    rig = new THREE.Group();
    weaponModel: THREE.Group;
    arms: THREE.Group;
    flash: THREE.Mesh;
    flashLight: THREE.PointLight;
    world: ReturnType<typeof createWorld>;
    nav: Navigation;
    ui: UI;
    audio = new AudioSystem();
    ray = new THREE.Raycaster();
    settings = readStore('ts2.settings', { ...defaults });
    skins = readStore('ts2.skins', { ak: 'default', m4: 'default', awp: 'default' });
    screen = 'home';
    inMatch = false;
    paused = true;
    config = { team: 'T', difficulty: 'normal', size: 5, practice: true };
    player: Actor;
    bots: Actor[] = [];
    items: Item[] = [];
    current = 0;
    previous = 0;
    velocity = new V();
    vertical = 0;
    yaw = 0;
    pitch = 0;
    eye = 1.65;
    grounded = true;
    keys = new Set<string>();
    mouseDown = false;
    scoped = false;
    reloading = 0;
    reloadTotal = 0;
    equipTime = 0;
    inspectTime = 0;
    kick = 0;
    spray = 0;
    shotCooldown = 0;
    stepTime = 0;
    hit = 0;
    hurt = 0;
    flashBlind = 0;
    score = { T: 0, CT: 0 };
    round = 0;
    phase = 'prep';
    timer = 15;
    buyElapsed = 0;
    endTimer = 0;
    roundWinner: Team;
    roundReason = '';
    matchFinished = false;
    bomb = { planted: false, defused: false, time: 40, pos: new V(), carrier: null as Actor | null, model: null as THREE.Group | null, progress: 0, beep: 0, botProgress: 0, planter: null as Actor | null };
    particles: Particle[] = [];
    decals: THREE.Mesh[] = [];
    grenades: Grenade[] = [];
    smokes: {
        pos: THREE.Vector3;
        life: number;
        group: THREE.Group;
    }[] = [];
    drops: {
        id: string;
        pos: THREE.Vector3;
        mesh: THREE.Group;
        ammo: number;
        reserve: number;
    }[] = [];
    killfeed: any[] = [];
    clock = new THREE.Clock();
    elapsed = 0;
    hudClock = 0;
    fps = 60;
    menuCharacter: THREE.Group;
    inspectModel: THREE.Group;
    inspectYaw = 0;
    inspectPitch = 0;
    inspectZoom = 1;
    drag = false;
    lastMouse = { x: 0, y: 0 };
    testMode = false;
    constructor() {
        this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
        this.renderer.setSize(innerWidth, innerHeight);
        this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.renderer.outputColorSpace = THREE.SRGBColorSpace;
        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = 1.03;
        this.renderer.autoClear = false;
        this.renderer.domElement.id = 'game-canvas';
        document.body.prepend(this.renderer.domElement);
        const pmrem = new THREE.PMREMGenerator(this.renderer);
        const room = new RoomEnvironment();
        const env = pmrem.fromScene(room, .06);
        this.scene.environment = env.texture;
        this.scene.environmentIntensity = .18;
        this.viewScene.environment = env.texture;
        this.viewScene.environmentIntensity = .9;
        this.inspectionScene = createInspectionStudio(env.texture);
        room.dispose();
        pmrem.dispose();
        this.scene.background = new THREE.Color('#9fcce4');
        this.scene.fog = new THREE.FogExp2('#c2c9c4', .006);
        this.world = createWorld();
        this.scene.add(this.world.group);
        this.nav = new Navigation(this.world.colliders);
        this.menuCharacter = createCharacter('T', 'ak');
        this.menuCharacter.position.set(23, 0, -18);
        this.menuCharacter.rotation.y = 2.9;
        this.menuCharacter.scale.setScalar(2.15);
        this.scene.add(this.menuCharacter);
        const menuFill = new THREE.PointLight(0xffead1, 35, 14);
        menuFill.position.set(24, 4, -14);
        this.menuCharacter.userData.fill = menuFill;
        this.scene.add(menuFill);
        this.viewScene.add(new THREE.HemisphereLight(0xe8f3ff, 0x656050, 2));
        const vl = new THREE.DirectionalLight(0xffecd1, 3.3);
        vl.position.set(-2, 4, 1);
        this.viewScene.add(vl);
        this.viewScene.add(this.rig);
        this.arms = createArms();
        this.rig.add(this.arms);
        this.flash = new THREE.Mesh(new THREE.ConeGeometry(.07, .25, 6), new THREE.MeshBasicMaterial({ color: 0xffdc83, transparent: true, opacity: .9, depthWrite: false }));
        this.flash.rotation.x = -Math.PI / 2;
        this.flash.position.set(0, .04, -.85);
        this.flash.visible = false;
        this.rig.add(this.flash);
        this.flashLight = new THREE.PointLight(0xffae42, 0, 3);
        this.rig.add(this.flashLight);
        this.ui = new UI({ navigate: (s: string) => this.navigate(s), start: (c: any) => this.start(c), resume: () => this.resume(), restart: () => this.start(this.config), home: () => this.home(), buy: (id: string) => this.buy(id), equip: (id: string, skin: string) => this.equipSkin(id, skin), inspect: (id: string, skin: string) => this.inspect(id, skin), settings: (v: any) => this.applySettings(v), quit: () => this.quit() });
        this.applySettings(this.settings, false);
        this.navigate('home');
        this.bindInput();
        this.animate();
    }
    applySettings(values: any, notify = true) { this.settings = { ...this.settings, ...values }; this.settings.fov = Number(this.settings.fov); this.settings.scale = Number(this.settings.scale); this.settings.sensitivity = Number(this.settings.sensitivity); this.audio.volume = Number(this.settings.volume); this.audio.effects = Number(this.settings.effects); if (this.audio.master)
        this.audio.master.gain.value = this.audio.volume * this.audio.effects; this.renderer.shadowMap.enabled = !!this.settings.shadows; this.renderer.setPixelRatio(Math.min(devicePixelRatio, this.settings.quality === 'high' ? 2 : this.settings.quality === 'low' ? 1 : 1.5) * this.settings.scale); this.camera.fov = this.settings.fov; this.camera.updateProjectionMatrix(); document.documentElement.style.setProperty('--crosshair', this.settings.crosshair); document.documentElement.style.setProperty('--crosshair-size', this.settings.crosshairSize + 'px'); saveStore('ts2.settings', this.settings); if (notify)
        this.ui.toast('Configurações aplicadas e salvas'); }
    bindInput() {
        window.addEventListener('resize', () => { this.camera.aspect = innerWidth / innerHeight; this.viewCamera.aspect = this.camera.aspect; this.camera.updateProjectionMatrix(); this.viewCamera.updateProjectionMatrix(); this.renderer.setSize(innerWidth, innerHeight); });
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('pointerlockchange', () => { if (document.pointerLockElement !== this.renderer.domElement && this.inMatch && this.screen === 'game' && !this.testMode)
            this.pause(); });
        document.addEventListener('pointerlockerror', () => { if (!this.testMode)
            this.ui.toast('Clique em Continuar para ativar o mouse'); });
        document.addEventListener('mousemove', e => { if (document.pointerLockElement === this.renderer.domElement && this.screen === 'game' && this.player?.alive) {
            const factor = .002 * this.settings.sensitivity * (this.scoped ? .35 : 1);
            this.yaw -= e.movementX * factor;
            this.pitch = Math.max(-1.48, Math.min(1.48, this.pitch - e.movementY * factor));
        }
        else if (this.screen === 'inspect' && this.drag) {
            this.inspectYaw += (e.clientX - this.lastMouse.x) * .008;
            this.inspectPitch = Math.max(-.8, Math.min(.8, this.inspectPitch + (e.clientY - this.lastMouse.y) * .005));
        } this.lastMouse = { x: e.clientX, y: e.clientY }; });
        document.addEventListener('mousedown', e => { this.audio.init(); if (this.screen === 'inspect') {
            if (!(e.target as HTMLElement).closest('button'))
                this.drag = true;
            return;
        } if (this.screen !== 'game' || !this.player?.alive)
            return; if (e.button === 0) {
            this.mouseDown = true;
            if (this.activeWeapon && !WEAPONS[this.activeWeapon.id].auto)
                this.fire();
        } if (e.button === 2) {
            this.scoped = !this.scoped;
            this.audio.click();
        } });
        document.addEventListener('mouseup', () => { this.mouseDown = false; this.drag = false; });
        document.addEventListener('wheel', e => { if (this.screen === 'inspect') {
            this.inspectZoom = THREE.MathUtils.clamp(this.inspectZoom - e.deltaY * .0006, .65, 1.65);
        }
        else if (this.screen === 'game' && this.player.alive) {
            this.switchWeapon((this.current + (e.deltaY > 0 ? 1 : -1) + this.items.length) % this.items.length);
        } }, { passive: true });
        document.addEventListener('keydown', e => {
            if ((e.target as HTMLElement).matches('input,select,textarea'))
                return;
            const k = e.code;
            if (['Tab', 'Space', 'ControlLeft', 'ControlRight', 'AltLeft'].includes(k))
                e.preventDefault();
            if (e.repeat)
                return;
            this.keys.add(k);
            if (k === 'Escape') {
                if (this.screen === 'game')
                    this.pause();
                else if (this.screen === 'pause' || this.screen === 'buy')
                    this.resume();
                else if (this.screen === 'settings' && this.inMatch)
                    this.navigate('pause');
                else
                    this.navigate('home');
                return;
            }
            if (k === 'Tab' && this.inMatch) {
                this.updateScoreboard();
                this.ui.setScoreboard(true);
                return;
            }
            if (k === 'KeyB' && this.inMatch && this.player.alive) {
                if (this.screen === 'buy')
                    this.resume();
                else if (this.canBuy())
                    this.openBuy();
                else
                    this.ui.toast('Compre no seu spawn durante os primeiros 15 segundos');
                return;
            }
            if (this.screen !== 'game' || !this.player?.alive)
                return;
            if (k === 'KeyR')
                this.reload();
            if (k === 'KeyF') {
                this.inspectTime = 3.3;
                this.audio.click();
            }
            if (k === 'KeyQ')
                this.switchWeapon(this.previous);
            if (k === 'Digit1')
                this.switchSlot(1);
            if (k === 'Digit2')
                this.switchSlot(2);
            if (k === 'Digit3')
                this.switchSlot(3);
            if (k === 'Digit4')
                this.switchSlot(4, true);
            if (k === 'Digit5')
                this.switchSlot(5);
            if (k === 'KeyG')
                this.dropWeapon();
            if (k === 'Space' && this.grounded) {
                this.vertical = 6.1;
                this.grounded = false;
                this.audio.step();
            }
        });
        document.addEventListener('keyup', e => { this.keys.delete(e.code); if (e.code === 'Tab')
            this.ui.setScoreboard(false); });
        window.addEventListener('blur', () => { this.keys.clear(); this.mouseDown = false; if (this.inMatch && this.screen === 'game')
            this.pause(); });
        document.addEventListener('click', e => { if ((e.target as HTMLElement).closest('button')) {
            this.audio.init();
            this.audio.click();
        } });
    }
    get activeWeapon() { return this.items[this.current]; }
    unlock() { this.mouseDown = false; this.scoped = false; this.keys.clear(); if (document.pointerLockElement)
        document.exitPointerLock(); }
    navigate(screen: string) {
        if (screen === 'home' && this.inMatch) {
            this.home();
            return;
        }
        this.screen = screen;
        this.paused = true;
        this.unlock();
        this.menuCharacter.visible = !this.inMatch && screen !== 'inspect';
        if (this.inspectModel) {
            this.inspectModel.removeFromParent();
            this.inspectModel = undefined;
        }
        this.ui.show(screen, { settings: this.settings, skins: this.skins, score: this.score, inMatch: this.inMatch });
    }
    home() { this.inMatch = false; this.bots.forEach(b => b.model && this.scene.remove(b.model)); this.bots = []; this.clearRoundObjects(); this.navigate('home'); }
    quit() { this.home(); this.ui.toast('Sessão encerrada. Você pode fechar esta aba.'); }
    pause() { if (!this.inMatch)
        return; this.screen = 'pause'; this.paused = true; this.ui.show('pause', { score: this.score, inMatch: this.inMatch }); this.unlock(); }
    resume() { if (!this.inMatch)
        return; this.screen = 'game'; this.paused = false; this.ui.show('game'); this.mouseDown = false; this.clock.getDelta(); if (!this.testMode) {
        try {
            const result = this.renderer.domElement.requestPointerLock();
            if (result)
                (result as Promise<void>).catch(() => { });
        }
        catch { }
    } }
    async start(config: any) {
        this.audio.init();
        this.config = { ...this.config, ...config };
        if (this.config.team === 'random')
            this.config.team = Math.random() < .5 ? 'T' : 'CT';
        this.config.size = Number(this.config.size);
        this.inMatch = false;
        this.navigate('loading');
        await new Promise(r => setTimeout(r, 550));
        this.score = { T: 0, CT: 0 };
        this.round = 0;
        this.matchFinished = false;
        this.killfeed = [];
        this.bots.forEach(b => b.model && this.scene.remove(b.model));
        this.bots = [];
        const team = this.config.team as Team;
        this.player = { id: 0, name: 'Operador', team, pos: new V(), health: 100, armor: 0, helmet: false, money: this.config.practice ? 16000 : 800, kills: 0, deaths: 0, weapon: team === 'T' ? 'glock' : 'usp', alive: true };
        let id = 1;
        for (const t of ['T', 'CT'] as Team[])
            for (let i = 0; i < this.config.size - (t === team ? 1 : 0); i++) {
                const model = createCharacter(t, t === 'T' ? 'ak' : 'm4');
                const b: Actor = { id, name: names[id - 1], team: t, pos: new V(), health: 100, armor: 100, helmet: true, money: 800, kills: 0, deaths: 0, weapon: t === 'T' ? 'ak' : 'm4', alive: true, model };
                model.userData.actor = b;
                this.scene.add(model);
                this.bots.push(b);
                id++;
            }
        this.menuCharacter.visible = false;
        this.inMatch = true;
        this.newRound();
        this.resume();
    }
    clearRoundObjects() { for (const p of this.particles)
        this.scene.remove(p.mesh); this.particles = []; for (const d of this.decals) {
        this.scene.remove(d);
        d.geometry.dispose();
    } this.decals = []; for (const g of this.grenades)
        this.scene.remove(g.mesh); this.grenades = []; for (const s of this.smokes)
        this.scene.remove(s.group); this.smokes = []; for (const d of this.drops)
        this.scene.remove(d.mesh); this.drops = []; if (this.bomb.model)
        this.scene.remove(this.bomb.model); }
    spawnPosition(team: Team, index: number) { const base = this.world.spawns[team]; let p = base.clone().add(new V((index % 3 - 1) * 1.3, 0, Math.floor(index / 3) * 1.4)); if (blocked(p.x, p.z, this.world.colliders)) {
        const n = this.nav.node(p);
        p.set(n % this.nav.size + this.nav.min, 0, Math.floor(n / this.nav.size) + this.nav.min);
    } p.y = this.world.groundHeight(p.x, p.z); return p; }
    newRound() {
        this.clearRoundObjects();
        this.round++;
        this.phase = 'prep';
        this.timer = 15;
        this.buyElapsed = 0;
        this.endTimer = 0;
        this.roundReason = '';
        this.bomb = { planted: false, defused: false, time: 40, pos: new V(), carrier: this.player.team === 'T' ? this.player : this.bots.find(b => b.team === 'T'), model: null, progress: 0, beep: 0, botProgress: 0, planter: null };
        const keep = this.player.alive && this.round > 1 ? this.items.filter(i => !['c4', 'he', 'flash', 'smoke'].includes(i.id)).map(i => ({ ...i, ammo: WEAPONS[i.id].mag, reserve: WEAPONS[i.id].reserve })) : [];
        this.player.pos.copy(this.spawnPosition(this.player.team, 0));
        this.player.health = 100;
        if (!this.player.alive) {
            this.player.armor = 0;
            this.player.helmet = false;
            (this.player as any).kit = false;
        }
        this.player.alive = true;
        this.items = keep.length ? keep : [this.makeItem(this.player.team === 'T' ? 'glock' : 'usp'), this.makeItem('knife')];
        if (this.player.team === 'T')
            this.items.push(this.makeItem('c4'));
        this.current = 0;
        this.previous = 0;
        this.reloading = 0;
        this.vertical = 0;
        this.velocity.set(0, 0, 0);
        this.yaw = this.player.team === 'T' ? 0 : Math.PI;
        this.pitch = 0;
        this.scoped = false;
        this.inspectTime = 0;
        this.shotCooldown = 0;
        this.bomb.progress = 0;
        let counts = { T: 1, CT: 1 };
        for (const b of this.bots) {
            b.pos.copy(this.spawnPosition(b.team, counts[b.team]++));
            b.health = 100;
            b.alive = true;
            b.model.visible = true;
            b.model.position.copy(b.pos);
            b.path = [];
            b.target = null;
            b.think = 0;
            b.reaction = 0;
            b.attack = .5 + Math.random();
            b.ammo = 30;
            b.reload = 0;
            b.routeIndex = 0;
            b.state = 'Idle';
            const routeX = [-25, 0, 25][(b.id + this.round) % 3];
            const site = routeX < 0 ? this.world.sites.B : this.world.sites.A;
            b.route = b.team === 'T' ? [new V(routeX, 0, 20), new V(routeX, 0, 1), site.clone()] : [new V(routeX === 25 ? 23 : routeX, 0, -17), new V(routeX, 0, -3), new V(routeX, 0, 15)];
            if (b.team === 'T' && this.bomb.carrier === b)
                b.route = [new V(-25, 0, 20), new V(-25, 0, -2), this.world.sites.B.clone()];
        }
        this.setWeaponModel();
        this.ui.toast('ROUND ' + this.round + ' · B para comprar · ' + (this.player.team === 'T' ? 'Você está com a C4' : 'Defenda os bombsites'));
        this.audio.round(true);
    }
    makeItem(id: string): Item { return { id, ammo: WEAPONS[id].mag, reserve: WEAPONS[id].reserve }; }
    canBuy() { return this.inMatch && this.player.alive && this.phase !== 'end' && this.buyElapsed < 15 && this.player.pos.distanceTo(this.world.spawns[this.player.team]) < 10; }
    openBuy() { this.screen = 'buy'; this.ui.show('buy', { money: this.player.money, buyTime: Math.max(0, Math.ceil(15 - this.buyElapsed)), team: this.player.team }); this.unlock(); }
    buy(id: string) {
        if (!this.canBuy()) {
            this.ui.toast('Período de compra encerrado ou fora do spawn');
            return;
        }
        const price = PRICES[id];
        if (!canAfford(this.player.money, price)) {
            this.ui.toast('Saldo insuficiente');
            return;
        }
        if (id === 'armor' && this.player.armor >= 100 || id === 'helmet' && this.player.helmet && this.player.armor >= 100 || id === 'kit' && (this.player as any).kit) {
            this.ui.toast('Você já possui este equipamento');
            return;
        }
        if (['he', 'flash', 'smoke'].includes(id) && this.items.some(i => i.id === id)) {
            this.ui.toast('Você já possui esta granada');
            return;
        }
        if (id === 'kit' && this.player.team !== 'CT') {
            this.ui.toast('Kit disponível para Contra-Terroristas');
            return;
        }
        this.player.money -= price;
        if (id === 'armor')
            this.player.armor = 100;
        else if (id === 'helmet') {
            this.player.armor = 100;
            this.player.helmet = true;
        }
        else if (id === 'kit')
            (this.player as any).kit = true;
        else {
            const data = WEAPONS[id];
            if (data.slot < 3)
                this.items = this.items.filter(i => WEAPONS[i.id].slot !== data.slot);
            this.items.push(this.makeItem(id));
            this.current = this.items.length - 1;
            this.previous = 0;
            this.setWeaponModel();
        }
        this.audio.tone(880, .1, 'triangle', .12);
        this.openBuy();
        this.ui.toast('Adquirido: ' + (WEAPONS[id]?.name || ({ armor: 'Colete', helmet: 'Colete + capacete', kit: 'Kit de desarme' } as any)[id]));
    }
    equipSkin(id: string, skin: string) { this.skins[id] = skin; saveStore('ts2.skins', this.skins); if (this.activeWeapon?.id === id)
        this.setWeaponModel(); this.ui.toast('Acabamento equipado'); }
    inspect(id: string, skin: string) { this.navigate('inspect'); this.ui.show('inspect', { weapon: id, skin }); this.inspectModel = createWeapon(id, skin); this.inspectModel.position.set(23, 1.2, -18); this.inspectionScene.add(this.inspectModel); this.inspectYaw = -1.05; this.inspectPitch = .1; this.inspectZoom = 1; }
    setWeaponModel() { if (this.weaponModel)
        this.rig.remove(this.weaponModel); if (!this.activeWeapon)
        return; this.weaponModel = createWeapon(this.activeWeapon.id, this.skins[this.activeWeapon.id] || 'default'); this.rig.add(this.weaponModel); this.player.weapon = this.activeWeapon.id; this.reloading = 0; this.inspectTime = 0; this.equipTime = .35; this.scoped = false; }
    switchWeapon(index: number) { if (index < 0 || index >= this.items.length || index === this.current)
        return; this.previous = this.current; this.current = index; this.setWeaponModel(); this.audio.click(); }
    switchSlot(slot: number, cycle = false) { const indexes = this.items.map((i, k) => WEAPONS[i.id].slot === slot ? k : -1).filter(k => k >= 0); if (!indexes.length)
        return; const index = cycle ? indexes[(indexes.indexOf(this.current) + 1) % indexes.length] : indexes[0]; this.switchWeapon(index); }
    reload() { const w = this.activeWeapon; if (!w || this.reloading || w.ammo >= WEAPONS[w.id].mag || !w.reserve || WEAPONS[w.id].slot > 2)
        return; this.reloading = this.reloadTotal = WEAPONS[w.id].reload; this.inspectTime = 0; this.scoped = false; this.audio.reload(); }
    dropWeapon() { const w = this.activeWeapon; if (!w || WEAPONS[w.id].slot > 2)
        return; const dir = new V(-Math.sin(this.yaw), 0, -Math.cos(this.yaw)); const pos = this.player.pos.clone().addScaledVector(dir, 1); const mesh = createWeapon(w.id, this.skins[w.id]); mesh.position.copy(pos).add(new V(0, .12, 0)); mesh.rotation.set(Math.PI / 2, 0, this.yaw); this.scene.add(mesh); this.drops.push({ id: w.id, pos, mesh, ammo: w.ammo, reserve: w.reserve }); this.items.splice(this.current, 1); this.current = Math.max(0, this.items.findIndex(i => WEAPONS[i.id].slot === 2)); this.previous = 0; this.setWeaponModel(); this.ui.toast('Arma solta · E para recolher'); }
    fire() {
        if (!this.player?.alive || this.screen !== 'game' || this.phase === 'end' || this.phase === 'prep' || this.reloading || this.equipTime > 0 || this.shotCooldown > 0)
            return;
        const item = this.activeWeapon;
        if (!item)
            return;
        const data = WEAPONS[item.id];
        if (item.id === 'c4')
            return;
        if (data.slot === 4) {
            this.throwGrenade(item.id);
            return;
        }
        if (data.slot < 3 && item.ammo <= 0) {
            this.audio.tone(100, .06, 'square', .06);
            this.shotCooldown = .2;
            this.ui.toast('Sem munição · R para recarregar');
            return;
        }
        this.inspectTime = 0;
        this.shotCooldown = data.rate;
        if (data.slot < 3)
            item.ammo--;
        this.kick = 1;
        this.spray = Math.min(1, this.spray + .16);
        this.audio.shoot(item.id);
        if (item.id === 'knife') {
            this.audio.burst(.15, .12, 2400);
        }
        else {
            this.flash.visible = true;
            this.flash.scale.setScalar(.7 + Math.random() * .6);
            this.flash.rotation.z = Math.random() * 6;
            this.flashLight.intensity = 4;
        }
        const moving = Math.hypot(this.velocity.x, this.velocity.z);
        const spread = (item.id === 'awp' ? (this.scoped ? .0005 : .025) : data.spread) + moving * .002 + this.spray * .006;
        const direction = new V((Math.random() - .5) * spread, (Math.random() - .5) * spread, -1).applyQuaternion(this.camera.quaternion).normalize();
        this.scene.updateMatrixWorld(true);
        this.ray.set(this.camera.position, direction);
        this.ray.far = item.id === 'knife' ? 2.3 : 110;
        const enemies = this.bots.filter(b => b.alive && b.team !== this.player.team);
        const hits = this.ray.intersectObjects([...this.world.solidMeshes, ...enemies.map(b => b.model)], true);
        if (hits.length) {
            const hit = hits[0];
            let node: THREE.Object3D = hit.object;
            let actor: Actor;
            let head = false;
            while (node) {
                head = head || node.userData.hitZone === 'head';
                if (node.userData.actor) {
                    actor = node.userData.actor;
                    break;
                }
                node = node.parent;
            }
            if (actor) {
                this.damage(actor, data.damage, this.player, head, item.id);
                this.hit = .15;
                this.audio.hit();
                this.emit(hit.point, 0xb0775c, 6, .07, 2);
            }
            else {
                this.impact(hit);
            }
            if (item.id !== 'knife')
                this.tracer(this.camera.position.clone().add(new V(0, -.1, 0)), hit.point, 0xffe7b1);
        }
        if (item.id !== 'knife') {
            this.pitch = Math.min(1.48, this.pitch + data.recoil * (.6 + this.spray));
            this.yaw += Math.sin(this.spray * 15) * data.recoil * .22;
        }
    }
    damage(target: Actor, amount: number, attacker: Actor, head = false, weapon = attacker.weapon) { if (!target.alive || target.team === attacker.team)
        return; const d = damageAfterArmor(amount, target.armor, head, target.helmet); target.health = Math.max(0, target.health - d.health); target.armor = Math.max(0, target.armor - d.armor); if (target === this.player) {
        this.hurt = .5;
        this.audio.tone(70, .16, 'triangle', .15);
    } if (target.health <= 0) {
        target.alive = false;
        target.deaths++;
        attacker.kills++;
        attacker.money = Math.min(16000, attacker.money + 300);
        if (target.model) {
            target.model.userData.deathTime = this.elapsed;
            target.state = 'Dead';
        }
        this.killfeed.unshift({ killer: attacker.name, victim: target.name, weapon: WEAPONS[weapon]?.name || weapon, team: attacker.team, time: this.elapsed, headshot: head });
        this.killfeed = this.killfeed.slice(0, 5);
        if (this.bomb.carrier === target && !this.bomb.planted) {
            const carrier = this.bots.find(b => b.alive && b.team === 'T' && b !== target);
            this.bomb.carrier = carrier || null;
            if (carrier) {
                carrier.route = [this.world.sites.B.clone()];
                carrier.routeIndex = 0;
                carrier.path = [];
            }
        }
        if (target === this.player) {
            this.scoped = false;
            this.mouseDown = false;
            this.ui.toast('Você foi eliminado · Aguarde o próximo round');
        }
        if (attacker === this.player)
            this.ui.toast(head ? 'HEADSHOT · +$300' : 'ELIMINAÇÃO · +$300');
    } }
    impact(hit: THREE.Intersection) { const normal = hit.face?.normal.clone().transformDirection(hit.object.matrixWorld) || new V(0, 1, 0); const p = hit.point.clone().addScaledVector(normal, .015); const mark = new THREE.Mesh(new THREE.CircleGeometry(.035, 7), new THREE.MeshBasicMaterial({ color: 0x352f28, transparent: true, opacity: .72, depthWrite: false, side: THREE.DoubleSide })); mark.position.copy(p); mark.quaternion.setFromUnitVectors(new V(0, 0, 1), normal); this.scene.add(mark); this.decals.push(mark); if (this.decals.length > 70) {
        const old = this.decals.shift();
        this.scene.remove(old);
        old.geometry.dispose();
    } this.emit(p, 0xc7af86, 4, .025, 1.4); }
    emit(pos: THREE.Vector3, color: number, count: number, size: number, speed: number) { const geo = new THREE.IcosahedronGeometry(size, 0); for (let i = 0; i < count; i++) {
        const mesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color, transparent: true, opacity: .8 }));
        mesh.position.copy(pos);
        this.scene.add(mesh);
        const life = .3 + Math.random() * .4;
        this.particles.push({ mesh, velocity: new V(Math.random() - .5, Math.random(), Math.random() - .5).multiplyScalar(speed), life, maxLife: life, gravity: 4 });
    } }
    tracer(start: THREE.Vector3, end: THREE.Vector3, color: number) { const mesh = new THREE.Line(new THREE.BufferGeometry().setFromPoints([start, end]), new THREE.LineBasicMaterial({ color, transparent: true, opacity: .5 })); this.scene.add(mesh); this.particles.push({ mesh, velocity: new V(), life: .06, maxLife: .06 }); }
    throwGrenade(id: string) { const mesh = createWeapon(id); mesh.position.copy(this.camera.position); this.scene.add(mesh); const dir = new V(0, .15, -1).applyQuaternion(this.camera.quaternion).normalize(); this.grenades.push({ id, mesh, velocity: dir.multiplyScalar(12).add(new V(0, 2, 0)), life: 1.65, owner: this.player }); this.items.splice(this.current, 1); this.current = this.items.findIndex(i => WEAPONS[i.id].slot < 3); if (this.current < 0)
        this.current = 0; this.setWeaponModel(); this.audio.burst(.2, .08, 1600); }
    updateGrenades(dt: number) { for (let i = this.grenades.length - 1; i >= 0; i--) {
        const g = this.grenades[i];
        g.life -= dt;
        g.velocity.y -= 12 * dt;
        const next = g.mesh.position.clone().addScaledVector(g.velocity, dt);
        if (blocked(next.x, next.z, this.world.colliders, .1, Math.max(0, next.y), .15)) {
            g.velocity.x *= -.5;
            g.velocity.z *= -.5;
        }
        else {
            g.mesh.position.x = next.x;
            g.mesh.position.z = next.z;
        }
        g.mesh.position.y = next.y;
        if (g.mesh.position.y < .12) {
            g.mesh.position.y = .12;
            g.velocity.y = Math.abs(g.velocity.y) * .38;
            g.velocity.x *= .9;
            g.velocity.z *= .9;
        }
        g.mesh.rotation.x += dt * 4;
        if (g.life <= 0) {
            const pos = g.mesh.position.clone();
            this.scene.remove(g.mesh);
            this.grenades.splice(i, 1);
            if (g.id === 'smoke')
                this.createSmoke(pos);
            else if (g.id === 'flash') {
                const dist = this.camera.position.distanceTo(pos);
                if (dist < 28 && !segmentBlocked(pos, this.camera.position, this.world.colliders)) {
                    const dot = new V(0, 0, -1).applyQuaternion(this.camera.quaternion).dot(pos.clone().sub(this.camera.position).normalize());
                    this.flashBlind = Math.min(1, 18 / Math.max(1, dist)) * (dot > 0 ? 1 : .35);
                }
                for (const b of this.bots)
                    if (b.pos.distanceTo(pos) < 18)
                        b.reaction = 4;
                this.audio.burst(.35, .3, 7500, pos);
                this.emit(pos, 0xfffaf0, 15, .1, 3);
            }
            else {
                this.audio.explosion(pos);
                this.emit(pos, 0xffb15b, 25, .16, 6);
                for (const a of [this.player, ...this.bots]) {
                    const dist = a.pos.distanceTo(pos);
                    if (dist < 7 && !segmentBlocked(pos.clone().add(new V(0, .4, 0)), a.pos.clone().add(new V(0, 1, 0)), this.world.colliders))
                        this.damage(a, Math.max(0, 100 - dist * 14), g.owner, false, 'he');
                }
            }
        }
    } for (let i = this.smokes.length - 1; i >= 0; i--) {
        const s = this.smokes[i];
        s.life -= dt;
        const growth = Math.min(1, (17 - s.life) / 2);
        s.group.scale.setScalar(growth);
        s.group.children.forEach((m: THREE.Mesh) => { (m.material as THREE.MeshStandardMaterial).opacity = Math.min(.7, s.life * .3); m.rotation.y += dt * .05; });
        if (s.life <= 0) {
            this.scene.remove(s.group);
            this.smokes.splice(i, 1);
        }
    } }
    createSmoke(pos: THREE.Vector3) { const group = new THREE.Group(); for (let i = 0; i < 16; i++) {
        const m = new THREE.Mesh(new THREE.SphereGeometry(1.4 + Math.random() * .6, 9, 7), new THREE.MeshStandardMaterial({ color: 0xbcc0b9, transparent: true, opacity: .65, roughness: 1, depthWrite: false }));
        m.position.set((Math.random() - .5) * 4, 1 + Math.random() * 2, (Math.random() - .5) * 4);
        group.add(m);
    } group.position.copy(pos); this.scene.add(group); this.smokes.push({ pos: pos.clone(), life: 17, group }); this.audio.burst(.8, .15, 700, pos); }
    smokeBlocks(a: THREE.Vector3, b: THREE.Vector3) { for (const s of this.smokes) {
        const ab = b.clone().sub(a);
        const t = THREE.MathUtils.clamp(s.pos.clone().sub(a).dot(ab) / ab.lengthSq(), 0, 1);
        if (a.clone().addScaledVector(ab, t).distanceTo(s.pos.clone().add(new V(0, 1.5, 0))) < 2.7)
            return true;
    } return false; }
    updatePlayer(dt: number) {
        if (!this.player.alive)
            return;
        const crouch = this.keys.has('ControlLeft') || this.keys.has('ControlRight');
        const walk = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight');
        const w = WEAPONS[this.activeWeapon.id];
        const speed = w.speed * (crouch ? .44 : walk ? .52 : 1);
        let x = Number(this.keys.has('KeyD')) - Number(this.keys.has('KeyA')), z = Number(this.keys.has('KeyS')) - Number(this.keys.has('KeyW'));
        const length = Math.hypot(x, z);
        if (length) {
            x /= length;
            z /= length;
        }
        const target = new V((x * Math.cos(this.yaw) + z * Math.sin(this.yaw)) * speed, 0, (-x * Math.sin(this.yaw) + z * Math.cos(this.yaw)) * speed);
        const accel = length ? 16 : 12;
        this.velocity.lerp(target, 1 - Math.exp(-dt * accel));
        const old = this.player.pos.clone();
        moveBody(this.player.pos, this.velocity.x * dt, this.velocity.z * dt, this.world.colliders, crouch ? 1.15 : 1.75);
        this.vertical -= 17 * dt;
        this.player.pos.y += this.vertical * dt;
        let floor = this.world.groundHeight(this.player.pos.x, this.player.pos.z);
        for (const c of this.world.colliders) {
            if (this.player.pos.x > c.minX - .25 && this.player.pos.x < c.maxX + .25 && this.player.pos.z > c.minZ - .25 && this.player.pos.z < c.maxZ + .25 && c.top <= old.y + .35)
                floor = Math.max(floor, c.top);
            if (this.vertical > 0 && c.bottom > old.y + 1 && this.player.pos.y + (crouch ? 1.15 : 1.75) >= c.bottom && this.player.pos.x > c.minX - .25 && this.player.pos.x < c.maxX + .25 && this.player.pos.z > c.minZ - .25 && this.player.pos.z < c.maxZ + .25) {
                this.vertical = 0;
                this.player.pos.y = Math.min(this.player.pos.y, c.bottom - (crouch ? 1.15 : 1.75));
            }
        }
        if (this.player.pos.y <= floor) {
            if (!this.grounded && this.vertical < -3)
                this.audio.step();
            this.player.pos.y = floor;
            this.vertical = 0;
            this.grounded = true;
        }
        else
            this.grounded = false;
        this.eye = THREE.MathUtils.lerp(this.eye, crouch ? 1.06 : 1.65, Math.min(1, dt * 12));
        const moving = this.player.pos.distanceToSquared(old) > .00001;
        this.stepTime += dt;
        if (moving && this.grounded && this.stepTime > (walk || crouch ? .52 : .34)) {
            this.stepTime = 0;
            if (!crouch)
                this.audio.step();
        }
    }
    cameraPlayer(dt: number) { const moving = Math.hypot(this.velocity.x, this.velocity.z); const bob = this.grounded ? Math.sin(this.elapsed * 12) * Math.min(moving / 5, 1) * .016 : 0; this.camera.position.copy(this.player.pos).add(new V(0, this.player.alive ? this.eye + bob : .7, 0)); this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ'); const fov = this.scoped ? (this.activeWeapon.id === 'awp' ? 25 : Math.max(50, this.settings.fov - 18)) : this.settings.fov; this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, fov, Math.min(1, dt * 15)); this.camera.updateProjectionMatrix(); this.audio.listener.copy(this.camera.position); this.audio.yaw = this.yaw; }
    updateWeapon(dt: number) {
        this.shotCooldown = Math.max(0, this.shotCooldown - dt);
        this.equipTime = Math.max(0, this.equipTime - dt);
        this.inspectTime = Math.max(0, this.inspectTime - dt);
        this.kick = Math.max(0, this.kick - dt * 10);
        this.spray = Math.max(0, this.spray - dt * .4);
        if (this.reloading > 0) {
            this.reloading -= dt;
            if (this.reloading <= 0) {
                const w = this.activeWeapon, n = Math.min(WEAPONS[w.id].mag - w.ammo, w.reserve);
                w.ammo += n;
                w.reserve -= n;
                this.audio.reload();
            }
        }
        const bob = Math.sin(this.elapsed * 10) * Math.min(this.velocity.length() / 5, 1);
        this.rig.position.set(.27 + bob * .008, -.20 + Math.abs(bob) * .012 - this.equipTime * .9, -.56 + this.kick * .065);
        this.rig.rotation.set(this.kick * .09, 0, 0);
        if (this.activeWeapon.id === 'knife') {
            this.rig.rotation.z = -this.kick * .8;
            this.rig.position.x -= this.kick * .2;
        }
        if (this.reloading > 0) {
            const t = 1 - this.reloading / this.reloadTotal, s = Math.sin(t * Math.PI);
            this.rig.rotation.z = -s * .55;
            this.rig.rotation.x = s * .3;
            this.rig.position.y -= s * .13;
            const mag = this.weaponModel.getObjectByName('magazine');
            if (mag)
                mag.position.y = -Math.sin(t * Math.PI) * .15;
        }
        if (this.inspectTime > 0) {
            const t = (3.3 - this.inspectTime) / 3.3, s = Math.sin(t * Math.PI);
            this.rig.position.set(.12, -.18, -.62);
            this.rig.rotation.set(s * .25, s * -.65, s * -.65);
        }
        if (this.bomb.progress > 0) {
            this.rig.position.y -= .2;
            this.rig.rotation.x = -.4;
        }
        this.rig.visible = this.player.alive && !(this.scoped && this.activeWeapon.id === 'awp');
        this.flash.visible = this.kick > .62 && WEAPONS[this.activeWeapon.id].slot < 3;
        this.flashLight.intensity = this.flash.visible ? 3 : 0;
        if (this.mouseDown && WEAPONS[this.activeWeapon.id].auto)
            this.fire();
    }
    actors() { return [this.player, ...this.bots]; }
    botGoal(b: Actor) { if (this.bomb.planted) {
        if (b.team === 'CT')
            return this.bomb.pos.clone();
        const cover = this.bomb.pos.clone().add(new V(b.id % 2 ? 4 : -4, 0, b.id % 3 ? 3 : -3));
        return cover;
    } if (b.routeIndex < b.route.length) {
        const g = b.route[b.routeIndex];
        if (b.pos.distanceTo(g) < 2)
            b.routeIndex++;
        return b.route[Math.min(b.routeIndex, b.route.length - 1)];
    } if (b.team === 'T' && this.bomb.carrier === b)
        return this.world.sites.B.clone(); const enemy = this.actors().find(a => a.alive && a.team !== b.team); return enemy ? enemy.pos.clone() : b.pos; }
    updateBots(dt: number) {
        const difficulty = { easy: { reaction: 1, accuracy: .2, rate: .7 }, normal: { reaction: .55, accuracy: .37, rate: .42 }, hard: { reaction: .28, accuracy: .58, rate: .25 } }[this.config.difficulty] || { reaction: .55, accuracy: .37, rate: .42 };
        for (const b of this.bots) {
            if (!b.alive) {
                animateCharacter(b.model, this.elapsed, false, true);
                continue;
            }
            b.model.position.copy(b.pos);
            if (this.phase === 'prep' || this.phase === 'end') {
                animateCharacter(b.model, this.elapsed, false);
                continue;
            }
            b.think -= dt;
            b.attack -= dt;
            b.reaction = Math.max(0, b.reaction - dt);
            b.reload = Math.max(0, b.reload - dt);
            let moving = false;
            if (b.think <= 0) {
                b.think = .22 + Math.random() * .1;
                const eye = b.pos.clone().add(new V(0, 1.48, 0));
                const candidates = this.actors().filter(a => a.alive && a.team !== b.team && a.pos.distanceTo(b.pos) < 43).sort((a, c) => a.pos.distanceToSquared(b.pos) - c.pos.distanceToSquared(b.pos));
                let target: Actor = null;
                for (const a of candidates) {
                    const aim = a.pos.clone().add(new V(0, 1.15, 0));
                    const facing = new V(-Math.sin(b.model.rotation.y), 0, -Math.cos(b.model.rotation.y));
                    const direction = aim.clone().sub(eye).normalize();
                    const aware = a === b.target || a.pos.distanceTo(b.pos) < 8 || this.elapsed % 6 < .4;
                    const inFov = facing.dot(direction) > -.2;
                    if ((aware || inFov) && !segmentBlocked(eye, aim, this.world.colliders) && !this.smokeBlocks(eye, aim)) {
                        target = a;
                        break;
                    }
                }
                if (target !== b.target && target)
                    b.reaction = difficulty.reaction + Math.random() * .25;
                b.target = target;
            }
            if (b.target?.alive) {
                b.state = 'Attack';
                const direction = b.target.pos.clone().sub(b.pos);
                b.model.rotation.y = Math.atan2(-direction.x, -direction.z);
                if (b.attack <= 0 && b.reaction <= 0 && b.reload <= 0) {
                    const eye = b.pos.clone().add(new V(0, 1.4, 0)), aim = b.target.pos.clone().add(new V(0, 1.2, 0));
                    if (!segmentBlocked(eye, aim, this.world.colliders) && !this.smokeBlocks(eye, aim)) {
                        b.attack = difficulty.rate + Math.random() * .12;
                        b.ammo--;
                        this.audio.shoot(b.weapon, eye);
                        this.tracer(eye, aim.clone().add(new V((Math.random() - .5) * 1.3, Math.random() * .5, 0)), 0xffcf89);
                        this.emit(eye.clone().add(new V(-Math.sin(b.model.rotation.y) * .6, 0, -Math.cos(b.model.rotation.y) * .6)), 0xffca75, 1, .055, .8);
                        const distance = b.pos.distanceTo(b.target.pos);
                        const chance = difficulty.accuracy * Math.min(1, 18 / Math.max(1, distance));
                        if (Math.random() < chance)
                            this.damage(b.target, WEAPONS[b.weapon].damage * .8, b, Math.random() < .035);
                        if (b.ammo <= 0) {
                            b.reload = 2.5;
                            b.ammo = 30;
                        }
                    }
                }
                if (b.health < 35 || this.config.difficulty === 'hard') {
                    const strafe = Math.sin(this.elapsed * 1.3 + b.id) * .75;
                    moveBody(b.pos, Math.cos(b.model.rotation.y) * strafe * dt, -Math.sin(b.model.rotation.y) * strafe * dt, this.world.colliders);
                    moving = true;
                }
            }
            else {
                b.state = 'MoveToObjective';
                const goal = this.botGoal(b);
                if (!b.goal || goal.distanceTo(b.goal) > 2 || !b.path?.length) {
                    b.goal = goal.clone();
                    b.path = this.nav.path(b.pos, goal);
                }
                if (b.path?.length) {
                    const point = b.path[0], direction = point.clone().sub(b.pos);
                    direction.y = 0;
                    if (direction.length() < .35)
                        b.path.shift();
                    else {
                        direction.normalize();
                        const old = b.pos.clone();
                        moveBody(b.pos, direction.x * 2.8 * dt, direction.z * 2.8 * dt, this.world.colliders);
                        moving = b.pos.distanceToSquared(old) > .000001;
                        b.model.rotation.y = Math.atan2(-direction.x, -direction.z);
                        if (!moving) {
                            b.path = [];
                            b.goal = null;
                        }
                    }
                }
            }
            b.pos.y = this.world.groundHeight(b.pos.x, b.pos.z);
            b.model.position.copy(b.pos);
            b.moving = moving;
            animateCharacter(b.model, this.elapsed, moving);
            if (moving && b.id % 3 === Math.floor(this.elapsed * 3) % 3 && Math.random() < dt * 1.2)
                this.audio.step(b.pos);
        }
    }
    nearestSite(pos: THREE.Vector3) { return pos.distanceTo(this.world.sites.A) < 5.5 ? 'A' : pos.distanceTo(this.world.sites.B) < 5.5 ? 'B' : null; }
    plant(actor: Actor) { this.bomb.planted = true; this.bomb.time = 40; this.bomb.pos.copy(actor.pos); this.bomb.progress = 0; this.bomb.botProgress = 0; this.bomb.planter = actor; this.bomb.model = createWeapon('c4'); this.bomb.model.position.copy(actor.pos).add(new V(0, .12, 0)); this.bomb.model.rotation.x = -Math.PI / 2; this.scene.add(this.bomb.model); this.audio.beep(); this.ui.toast('C4 PLANTADA · ' + (this.nearestSite(actor.pos) || 'B')); if (actor === this.player) {
        this.items = this.items.filter(i => i.id !== 'c4');
        this.current = 0;
        this.setWeaponModel();
    } for (const b of this.bots) {
        b.path = [];
        b.goal = null;
        b.target = null;
    } }
    updateBomb(dt: number) {
        if (this.phase !== 'combat')
            return;
        const p = this.player, holding = this.keys.has('KeyE') && this.screen === 'game' && p.alive;
        if (!this.bomb.planted) {
            if (holding && p.team === 'T' && this.bomb.carrier === p && this.nearestSite(p.pos) && this.grounded && this.velocity.length() < .5) {
                this.bomb.progress += dt;
                this.inspectTime = 0;
                if (this.bomb.progress >= 3.2)
                    this.plant(p);
            }
            else
                this.bomb.progress = 0;
            const b = this.bomb.carrier;
            if (b && b !== p && b.alive && this.nearestSite(b.pos) && !b.target) {
                b.state = 'PlantBomb';
                this.bomb.botProgress += dt;
                if (this.bomb.botProgress >= 3.2)
                    this.plant(b);
            }
            else
                this.bomb.botProgress = 0;
        }
        else {
            this.bomb.time -= dt;
            this.bomb.beep -= dt;
            if (this.bomb.beep <= 0) {
                this.bomb.beep = Math.max(.12, this.bomb.time / 40);
                this.audio.beep();
                this.bomb.model?.traverse((obj: THREE.Mesh) => { if (obj.name === 'bomb-light')
                    (obj.material as THREE.MeshStandardMaterial).emissiveIntensity = 5; });
            }
            if (holding && p.team === 'CT' && p.pos.distanceTo(this.bomb.pos) < 2.7) {
                this.bomb.progress += dt;
                if (this.bomb.progress >= ((p as any).kit ? 5 : 10)) {
                    this.bomb.defused = true;
                    this.audio.tone(1500, .4, 'sine', .15);
                }
            }
            else
                this.bomb.progress = 0;
            const defuser = this.bots.find(b => b.alive && b.team === 'CT' && b.pos.distanceTo(this.bomb.pos) < 2.4 && !b.target);
            if (defuser) {
                defuser.state = 'DefuseBomb';
                this.bomb.botProgress += dt;
                if (this.bomb.botProgress >= 10)
                    this.bomb.defused = true;
            }
            else
                this.bomb.botProgress = 0;
            if (this.bomb.time <= 0) {
                this.audio.explosion(this.bomb.pos);
                this.emit(this.bomb.pos.clone().add(new V(0, 1, 0)), 0xffa537, 65, .3, 12);
                this.flashBlind = .7;
                for (const a of this.actors())
                    if (a.alive && a.pos.distanceTo(this.bomb.pos) < 16) {
                        a.health = 0;
                        a.alive = false;
                        a.deaths++;
                    }
            }
        }
    }
    interaction() { if (!this.player?.alive)
        return 'ELIMINADO · Aguarde o próximo round'; if (this.phase === 'prep')
        return 'PREPARAÇÃO · B para comprar'; if (this.phase === 'end')
        return ''; if (this.bomb.planted && this.player.team === 'CT' && this.player.pos.distanceTo(this.bomb.pos) < 2.7)
        return 'SEGURE E · DESARMAR C4'; if (!this.bomb.planted && this.player.team === 'T' && this.bomb.carrier === this.player && this.nearestSite(this.player.pos))
        return 'SEGURE E PARADO · PLANTAR C4'; if (this.drops.some(d => d.pos.distanceTo(this.player.pos) < 2))
        return 'E · RECOLHER ARMA'; return ''; }
    pickup() { const index = this.drops.findIndex(d => d.pos.distanceTo(this.player.pos) < 2); if (index < 0)
        return; const d = this.drops[index], slot = WEAPONS[d.id].slot; this.items = this.items.filter(i => WEAPONS[i.id].slot !== slot); this.items.push({ id: d.id, ammo: d.ammo, reserve: d.reserve }); this.current = this.items.length - 1; this.scene.remove(d.mesh); this.drops.splice(index, 1); this.setWeaponModel(); this.keys.delete('KeyE'); }
    endRound(winner: Team, reason: string) { if (this.phase === 'end')
        return; this.phase = 'end'; this.roundWinner = winner; this.roundReason = reason; this.score[winner]++; this.endTimer = 5; this.matchFinished = this.score[winner] >= 7; this.mouseDown = false; this.scoped = false; for (const a of this.actors())
        a.money = Math.min(16000, a.money + (a.team === winner ? 3250 : 1900)); this.audio.round(winner === this.player.team); this.ui.toast((winner === 'T' ? 'TERRORISTAS' : 'CONTRA-TERRORISTAS') + ' VENCEM · ' + reason); }
    updateRound(dt: number) { this.buyElapsed += dt; if (this.phase === 'prep') {
        this.timer -= dt;
        if (this.timer <= 0) {
            this.phase = 'combat';
            this.timer = 115;
            this.ui.toast('ROUND INICIADO · ' + (this.player.team === 'T' ? 'Plante a C4 em A ou B' : 'Defenda A e B'));
            this.audio.tone(700, .2, 'triangle', .12);
        }
    }
    else if (this.phase === 'combat') {
        this.timer -= dt;
        this.updateBomb(dt);
        const tAlive = this.actors().filter(a => a.alive && a.team === 'T').length, ctAlive = this.actors().filter(a => a.alive && a.team === 'CT').length;
        const winner = winnerFor({ tAlive, ctAlive, planted: this.bomb.planted, time: this.timer, bombTime: this.bomb.time, defused: this.bomb.defused });
        if (winner) {
            const reason = this.bomb.defused ? 'C4 desarmada' : this.bomb.planted && this.bomb.time <= 0 ? 'C4 detonada' : this.timer <= 0 ? 'Tempo esgotado' : 'Equipe adversária eliminada';
            this.endRound(winner, reason);
        }
    }
    else if (this.phase === 'end') {
        this.endTimer -= dt;
        if (this.endTimer <= 0) {
            if (this.matchFinished) {
                this.screen = 'result';
                this.paused = true;
                this.ui.show('result', { winner: this.roundWinner, score: this.score, kills: this.player.kills, deaths: this.player.deaths, victory: this.roundWinner === this.player.team });
                this.unlock();
            }
            else
                this.newRound();
        }
    } }
    updateScoreboard() { this.ui.updateScoreboard(this.actors().map(a => ({ name: a.name, team: a.team, kills: a.kills, deaths: a.deaths, assists: 0, score: a.kills * 2, money: a.money, ping: 'OFFLINE', alive: a.alive, player: a === this.player })), this.score); }
    updateHUD() { const w = this.activeWeapon; const alive = { T: 0, CT: 0 }; for (const a of this.actors())
        if (a.alive)
            alive[a.team]++; const progress = this.bomb.progress / (this.bomb.planted ? ((this.player as any).kit ? 5 : 10) : 3.2); this.ui.updateHUD({ health: Math.ceil(this.player.health), armor: Math.ceil(this.player.armor), money: this.player.money, ammo: w.ammo, reserve: w.reserve, weapon: WEAPONS[w.id].name, weaponId: w.id, score: this.score, time: this.bomb.planted ? this.bomb.time : this.phase === 'end' ? this.endTimer : this.timer, alive, phase: this.phase === 'prep' ? 'PREPARAÇÃO' : this.phase === 'end' ? this.roundReason : '', site: this.world.location(this.player.pos.x, this.player.pos.z), hasBomb: this.bomb.carrier === this.player && !this.bomb.planted, bomb: this.bomb.planted, interaction: this.interaction(), progress: Math.min(1, progress), kills: this.killfeed.filter(k => this.elapsed - k.time < 7), grenades: this.items.filter(i => WEAPONS[i.id].slot === 4).map(i => i.id), fps: Math.round(this.fps), hit: this.hit > 0, hurt: this.hurt, flash: this.flashBlind, scoped: this.scoped && w.id === 'awp', reloading: this.reloading > 0, round: this.round, buyTime: Math.max(0, Math.ceil(15 - this.buyElapsed)), winner: this.phase === 'end' ? this.roundWinner : null, map: { colliders: this.world.colliders, player: { x: this.player.pos.x, z: this.player.pos.z, yaw: this.yaw, team: this.player.team }, bots: this.bots.filter(b => b.alive && (b.team === this.player.team || this.elapsed % 2 < .3 && b.target === this.player)).map(b => ({ x: b.pos.x, z: b.pos.z, team: b.team })), sites: this.world.sites } }); if (this.keys.has('Tab'))
        this.updateScoreboard(); }
    updateEffects(dt: number) { for (let i = this.particles.length - 1; i >= 0; i--) {
        const p = this.particles[i];
        p.life -= dt;
        p.mesh.position.addScaledVector(p.velocity, dt);
        p.velocity.y -= (p.gravity || 0) * dt;
        const mat = (p.mesh as THREE.Mesh).material as THREE.Material & {
            opacity: number;
        };
        mat.opacity = Math.max(0, p.life / p.maxLife);
        if (p.life <= 0) {
            this.scene.remove(p.mesh);
            if ((p.mesh as THREE.Mesh).geometry)
                (p.mesh as THREE.Mesh).geometry.dispose();
            mat.dispose();
            this.particles.splice(i, 1);
        }
    } this.hit = Math.max(0, this.hit - dt); this.hurt = Math.max(0, this.hurt - dt); this.flashBlind = Math.max(0, this.flashBlind - dt * .33); }
    menuCamera(dt: number) { if (this.screen === 'inspect' && this.inspectModel) {
        this.camera.position.set(23, 1.35, -15.9);
        this.camera.lookAt(23, 1.15, -18);
        this.camera.fov = 57;
        this.inspectModel.position.set(23, 1.15, -18);
        this.inspectModel.rotation.set(this.inspectPitch, this.inspectYaw + this.elapsed * .17, 0);
        this.inspectModel.scale.setScalar(this.inspectZoom * 1.8);
    }
    else {
        this.camera.position.set(25.2 + Math.sin(this.elapsed * .12) * .13, 2.5, -13.5);
        this.camera.lookAt(22.25, 1.8, -18.4);
        this.camera.fov = 52;
        animateCharacter(this.menuCharacter, this.elapsed, false);
    } this.camera.updateProjectionMatrix(); }
    animate = () => {
        requestAnimationFrame(this.animate);
        const dt = Math.min(.04, this.clock.getDelta());
        this.elapsed += dt;
        this.fps = THREE.MathUtils.lerp(this.fps, 1 / Math.max(.001, dt), .025);
        (this.menuCharacter.userData.fill as THREE.PointLight).visible = !this.inMatch;
        if (this.inMatch) {
            if (!this.paused) {
                if (this.screen === 'game')
                    this.updatePlayer(dt);
                this.updateWeapon(dt);
                this.updateBots(dt);
                this.updateGrenades(dt);
                this.updateRound(dt);
                this.updateEffects(dt);
                if (this.keys.has('KeyE') && this.player.alive && this.bomb.progress === 0 && this.screen === 'game')
                    this.pickup();
            }
            this.cameraPlayer(dt);
            this.hudClock += dt;
            if (this.hudClock > .05) {
                this.hudClock = 0;
                this.updateHUD();
            }
        }
        else
            this.menuCamera(dt);
        this.renderer.clear();
        this.renderer.render(this.screen === 'inspect' ? this.inspectionScene : this.scene, this.camera);
        if (this.inMatch && ['game', 'buy', 'pause', 'settings'].includes(this.screen) && this.player?.alive && this.weaponModel) {
            this.renderer.clearDepth();
            this.renderer.render(this.viewScene, this.viewCamera);
        }
    };
}
