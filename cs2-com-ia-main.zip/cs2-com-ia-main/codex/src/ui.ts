type Callback = (...args: any[]) => void;
const esc = (s: any) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const cash = (n: any) => '$ ' + Number(n || 0).toLocaleString('pt-BR');
const icon = (name: string) => {
 const paths: Record<string,string> = {
  home:'M3 11 12 3l9 8M5 10v11h5v-7h4v7h5V10',play:'m8 4 13 8-13 8Z',box:'m3 7 9-4 9 4-9 4Zm0 0v11l9 4 9-4V7m-9 4v11',gear:'m9 3 6 0 1 3 3 1 3 5-2 3v4l-5 3-3-1-3 1-5-3v-4l-2-3 3-5 3-1Zm3 5a4 4 0 1 0 0 8 4 4 0 0 0 0-8',arrow:'M4 12h16m-6-6 6 6-6 6',back:'M20 12H4m6-6-6 6 6 6',close:'m6 6 12 12M6 18 18 6',shield:'m12 2 9 4v6c0 6-9 10-9 10S3 18 3 12V6Zm-4 9 3 3 5-6',target:'M12 2v4m0 12v4M2 12h4m12 0h4M12 5a7 7 0 1 0 0 14 7 7 0 0 0 0-14m0 5a2 2 0 1 0 0 4 2 2 0 0 0 0-4',quit:'M12 2v10M6 5a9 9 0 1 0 12 0',star:'m12 2 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z',lock:'M6 10h12v11H6Zm2 0V6a4 4 0 0 1 8 0v4',user:'M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10M3 22c0-10 18-10 18 0',clock:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18m0 4v6l4 2',check:'m5 12 5 5L20 7',sound:'m3 9 5 0 5-5v16l-5-5H3Zm14-2c4 2 4 8 0 10m3-13c6 4 6 12 0 16',bolt:'m14 2-9 12h7l-2 8 9-12h-7Z',info:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18m0 7v7m0-11v1',pause:'M8 4v16M16 4v16',flag:'M5 22V3c7-4 8 5 15 1v11c-7 4-8-5-15-1',bomb:'M11 6a8 8 0 1 0 8 8 8 8 0 0 0-8-8Zm5 2 3-3m-1-4 2 2 3-1m-3 3 3 1',skull:'M5 17c-8-16 22-20 14 0l-2 1v4H7v-4Zm3-7v3m8-3v3m-4 1v3',refresh:'M20 5v6h-6m6 0A8 8 0 1 0 19 18',monitor:'M2 3h20v14H2Zm10 14v5m-6 0h12',mouse:'M6 10a6 6 0 0 1 12 0v6a6 6 0 0 1-12 0Zm6-6v7',sun:'M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10M12 1v3m0 16v3M1 12h3m16 0h3M4 4l2 2m12 12 2 2M4 20l2-2M18 6l2-2',chevron:'m8 4 8 8-8 8',key:'M14 4a6 6 0 1 0 6 6 6 6 0 0 0-6-6m-4 10-8 8m2-4 3 3',cross:'M12 3v18M3 12h18'
 };
 return `<svg viewBox="0 0 24 24" class="icon" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name] || paths.target}"/></svg>`;
};

const WEAPONS: any[] = [
 {id:'ak',name:'AK-47',type:'RIFLE',price:2700,team:'T',tag:'7.62 × 39 MM'},
 {id:'m4',name:'M4A4',type:'RIFLE',price:3000,team:'CT',tag:'5.56 × 45 MM'},
 {id:'m4s',name:'M4A1-S',type:'RIFLE',price:2900,team:'CT',tag:'5.56 × 45 MM'},
 {id:'awp',name:'AWP',type:'PRECISÃO',price:4750,team:'',tag:'.338 LAPUA'},
 {id:'mp9',name:'MP9',type:'SUBMETRALHADORA',price:1250,team:'',tag:'9 × 19 MM'},
 {id:'glock',name:'Glock-18',type:'PISTOLA',price:200,team:'T',tag:'9 × 19 MM'},
 {id:'usp',name:'USP-S',type:'PISTOLA',price:200,team:'CT',tag:'.45 ACP'},
 {id:'deagle',name:'Desert Eagle',type:'PISTOLA',price:700,team:'',tag:'.50 AE'},
 {id:'knife',name:'Faca tática',type:'FACA',price:0,team:'',tag:'AÇO TEMPERADO'},
];
const SKINS = [
 {id:'default',name:'Original',rarity:'PADRÃO',color:'#a6b3ba',desc:'Acabamento original. Precisão sem distrações.'},
 {id:'redline',name:'Linha Vermelha',rarity:'CONFIDENCIAL',color:'#dc625c',desc:'Carbono negro. Um traço de vermelho. Intenção pura.'},
 {id:'gold',name:'Ouro Tático',rarity:'SECRETO',color:'#e1c078',desc:'Metal dourado e detalhes escuros. Presença em cada round.'},
 {id:'urban',name:'Camuflagem Urbana',rarity:'MILITAR',color:'#c4c8b7',desc:'Acabamento mineral, preparado para operações urbanas.'},
 {id:'blue',name:'Maré Profunda',rarity:'RESTRITO',color:'#77bdd5',desc:'Metal azul profundo e detalhes em aço escurecido.'},
 {id:'white',name:'Branco Ártico',rarity:'CONFIDENCIAL',color:'#e3e1ce',desc:'Cerâmica clara com detalhes em laranja de alta visibilidade.'},
 {id:'dragon',name:'Dragão do Deserto',rarity:'SECRETO',color:'#deb76d',desc:'Ocre, ouro e detalhes em vermelho. A lenda do deserto.'}
];
const weaponSkins = (id:string) => SKINS.filter(s=>s.id==='default'||(id==='ak'?['redline','gold']:['m4','m4s'].includes(id)?['urban','blue']:id==='awp'?['white','dragon']:[]).includes(s.id));

export function weaponSVG(id: string, color='currentColor') {
 const pistol = ['glock','usp','deagle'].includes(id);
 const p = id === 'knife' ? 'M29 68 119 25 197 24 121 66 78 72 60 91 42 90 51 68Z' : pistol ? `M30 36H${id==='usp'?173:146}V48H135L128 67H100L94 92H67L73 58H32ZM96 54H116L111 63H97Z${id==='usp'?'M172 36h36v12h-36Z':''}` : id==='awp' ? 'M12 53H98V43H117V31H157V43H173V48H220V53H173V63H139L128 84H113L120 63H95L63 73H16L23 57H12ZM121 26H151V36H121Z' : id==='mp9' ? 'M24 40H153V46H184V52H146V65H118L112 89H94L97 63H85L77 92H56L59 61H24ZM147 34H160V44H147Z' : `M12 47H53V40H138V43H161V47H218V53H162V61H127L119 92H100L106 62H87L77 81H65L69 60H58L28 73H12L23 56H12ZM${id==='ak'?'135 31H157V43H135ZM116 63Q109 89 127 101L145 94Q128 80 134 63Z':'125 33H160V40H125ZM153 57H176V62H153Z'}`;
 return `<svg class="weapon-svg weapon-${id}" viewBox="0 0 232 116" fill="${color}" aria-hidden="true"><path d="${p}"/><path d="M30 51H197M75 46H129" stroke="rgba(255,255,255,.2)" stroke-width="1.1"/></svg>`;
}

export class UI {
 public root: HTMLDivElement;
 private actions: Record<string, Callback>;
 private screen = 'home';
 private data: any = {};
 private config = {map:'dust2',team:'T',difficulty:'normal',size:5,practice:true};
 private values: any = {sensitivity:1,volume:.5,effects:.8,fov:80,quality:'medium',shadows:true,scale:1,crosshair:'#98e8c2',crosshairSize:8};
 private skins: Record<string,string> = {};
 private selectedWeapon = 'ak';
 private selectedSkin = 'default';
 private filter = 'all';
 private hud: HTMLDivElement;
 private overlay: HTMLDivElement;
 private notice: HTMLDivElement;
 private scoreboard: HTMLDivElement;
 private hudCache: any = {};
 private toastTimer: any;
 private lastMap = 0;

 constructor(actions: any) {
  this.actions = actions;
  this.root = document.createElement('div');
  this.root.id = 'game-ui';
  this.root.innerHTML = `<div class="menu-overlay"></div><div class="fps-hud" hidden>${this.hudHTML()}</div><div class="scoreboard-overlay" hidden></div><div class="toast" role="status"></div>`;
  document.body.appendChild(this.root);
  this.overlay = this.root.querySelector('.menu-overlay')!;
  this.hud = this.root.querySelector('.fps-hud')!;
  this.notice = this.root.querySelector('.toast')!;
  this.scoreboard = this.root.querySelector('.scoreboard-overlay')!;
  this.root.addEventListener('click', (e) => this.click(e));
  this.root.addEventListener('change', (e) => this.change(e));
  this.root.addEventListener('input', (e) => this.input(e));
 }

 show(screen: string, data: any = {}) {
  this.screen = screen;
  this.data = data || {};
  if (data.settings) this.values = {...this.values,...data.settings};
  if (data.skins) this.skins = {...this.skins,...data.skins};
  const inGame = ['game','pause','buy','result'].includes(screen);
  this.hud.hidden = !inGame;
  this.overlay.hidden = screen === 'game';
  this.overlay.className = `menu-overlay screen-${screen}`;
  this.root.dataset.screen = screen;
  if (screen === 'game') { this.overlay.innerHTML = ''; return; }
  const content: Record<string, () => string> = {
   home:()=>this.home(), play:()=>this.play(), inventory:()=>this.inventory(), loadout:()=>this.inventory(true), settings:()=>this.settings(), pause:()=>this.pause(), buy:()=>this.buy(), loading:()=>this.loading(), result:()=>this.result(), inspect:()=>this.inspect()
  };
  this.overlay.innerHTML = (content[screen] || content.home)();
 }

 private nav() {
  return `<header class="topbar"><button class="brand" data-action="nav" data-screen="home" aria-label="Início"><span class="brand-mark">T<span>II</span></span><span>TACTICAL<br><b>STRIKE 2</b></span></button><nav aria-label="Navegação principal">${[['play','JOGAR'],['inventory','INVENTÁRIO'],['loadout','EQUIPAMENTOS'],['settings','CONFIGURAÇÕES']].map(([id,label])=>`<button class="nav-item ${this.screen===id?'active':''}" data-action="nav" data-screen="${id}">${label}${id==='play'?'<span class="nav-dot"></span>':''}</button>`).join('')}</nav><button class="exit-nav" data-action="quit" title="Sair">${icon('quit')}<span>SAIR</span></button></header>`;
 }
 private footer() { return `<footer class="menu-footer"><span><i class="status-dot"></i> SISTEMAS OPERACIONAIS <b>•</b> OFFLINE</span><span>TS2 <b>/</b> EDIÇÃO EXPERIMENTAL <b>/</b> 1.0.0</span><span>FEITO PARA JOGAR.</span></footer>`; }
 private heading(kicker:string,title:string,desc:string) { return `<div class="page-heading"><span class="eyebrow">${kicker}</span><h1>${title}</h1><p>${desc}</p></div>`; }
 private home() {
  return `${this.nav()}<main class="home-layout"><div class="home-hero"><div class="eyebrow"><span class="small-line"></span> OPERAÇÃO DUST <span class="edition">01 / 2026</span></div><h1>TACTICAL<br><span>STRIKE</span><em>2</em></h1><p>Instinto. Estratégia. Precisão.<br>Cada round é uma nova oportunidade.</p><button class="primary hero-play" data-action="nav" data-screen="play">${icon('play')}<span>ENTRAR EM COMBATE<small>PARTIDA LOCAL CONTRA BOTS</small></span>${icon('arrow')}</button><div class="hero-meta"><span><i class="status-dot"></i> PRONTO PARA O COMBATE</span><span>SEM CONEXÃO NECESSÁRIA</span></div></div><aside class="profile-panel"><div class="profile-head"><span class="avatar">${icon('user')}</span><div><small>OPERADOR</small><strong>GHOST</strong><span><i class="status-dot"></i> ONLINE LOCAL</span></div><span class="profile-level">01</span></div><div class="rank-row">${icon('shield')}<span>RECRUTA<small>O próximo nível começa aqui.</small></span><b>Ⅰ</b></div><div class="profile-meter"><i></i></div><div class="profile-meter-text"><span>PROGRESSO DO OPERADOR</span><span>0 / 1.000 XP</span></div></aside><div class="character-caption"><span class="caption-line"></span><span>UNIDADE DE OPERAÇÕES ESPECIAIS<small>FORÇA TÁTICA / ALPHA</small></span><b>01</b></div><section class="home-cards"><button class="feature-card dust-feature" data-action="nav" data-screen="play"><div class="feature-architecture"><i></i><i></i><i></i></div><span class="eyebrow">CENÁRIO EM DESTAQUE</span><strong>DUST II</strong><span>Um clássico. Infinitas possibilidades.</span><span class="feature-link">EXPLORAR OPERAÇÃO ${icon('arrow')}</span><span class="feature-coordinate">34° N / 6° W</span></button><button class="feature-card training-feature" data-action="nav" data-screen="inventory"><span class="eyebrow">SEU ARSENAL</span><strong>PREPARE-SE.</strong><span>Uma arma. A sua identidade.</span>${weaponSVG('ak')}<span class="feature-link">PERSONALIZAR EQUIPAMENTO ${icon('arrow')}</span></button><div class="field-notes"><span class="eyebrow">INFORMAÇÕES DA MISSÃO</span><p>DOMINE O OBJETIVO.<br>CONQUISTE O ROUND.</p><span>${icon('target')} DESARMAMENTO DE BOMBA</span><span>${icon('shield')} ATÉ 10 OPERADORES</span><span>${icon('monitor')} EXPERIÊNCIA 100% LOCAL</span></div></section></main>${this.footer()}`;
 }
 private miniMap(name:string,index:number) {
  return `<div class="map-art map-art-${index}" aria-hidden="true"><div class="map-sun"></div><span class="skyline s1"></span><span class="skyline s2"></span><span class="skyline s3"></span><span class="skyline s4"></span><span class="map-arch"></span><span class="map-road"></span><span class="map-label">${name==='Dust II'?'A':'B'}</span><span class="map-grid"></span></div>`;
 }
 private play() {
  const maps = [['Dust II','DESERTO / MARROCOS'],['Mirage','CIDADE / MARROCOS'],['Inferno','VILAREJO / ITÁLIA'],['Nuke','COMPLEXO / EUA'],['Ancient','RUÍNAS / MÉXICO'],['Anubis','TEMPLO / EGITO'],['Vertigo','ARRANHA-CÉU / EUA'],['Overpass','URBANO / ALEMANHA']];
  return `${this.nav()}<main class="page-content play-content">${this.heading('ESCOLHA SUA OPERAÇÃO','PREPARAR. MIRAR. JOGAR.','Desarme a bomba ou proteja o objetivo. O seu time conta com você.')}<div class="play-layout"><section class="maps-grid">${maps.map(([name,place],i)=>`<button class="map-card ${i===0?'selected':''}" data-action="map" ${i?'disabled':''} aria-label="${name}${i?', em desenvolvimento':''}">${this.miniMap(name,i)}<div class="map-card-text"><span class="map-name">${name} ${i===0?icon('check'):icon('lock')}</span><small>${place}</small><span class="map-availability">${i===0?'<i class="status-dot"></i> PRONTO PARA JOGAR':'EM DESENVOLVIMENTO'}</span></div></button>`).join('')}</section><aside class="match-panel panel"><span class="eyebrow">CONFIGURAÇÕES DA PARTIDA</span><div class="selected-map-title"><span>DUST II</span><small>DESARMAMENTO DE BOMBA</small></div><label class="field-label">01 <span>SEU TIME</span></label><div class="segmented teams">${[['T','TERRORISTAS'],['CT','CONTRA-TERRORISTAS'],['random','ALEATÓRIO']].map(([v,l])=>`<button class="${this.config.team===v?'selected':''}" data-action="config" data-key="team" data-value="${v}">${l}</button>`).join('')}</div><label class="field-label">02 <span>DIFICULDADE DOS BOTS</span></label><div class="segmented">${[['easy','FÁCIL'],['normal','NORMAL'],['hard','DIFÍCIL']].map(([v,l])=>`<button class="${this.config.difficulty===v?'selected':''}" data-action="config" data-key="difficulty" data-value="${v}">${l}</button>`).join('')}</div><label class="field-label">03 <span>TAMANHO DO CONFRONTO</span></label><div class="segmented match-size">${[1,3,5].map(n=>`<button class="${this.config.size===n?'selected':''}" data-action="config" data-key="size" data-value="${n}"><strong>${n}<i>VS</i>${n}</strong></button>`).join('')}</div><label class="practice-option"><input type="checkbox" name="practice" ${this.config.practice?'checked':''}><span><strong>ECONOMIA DE TREINO</strong><small>Comece com $ 16.000. Teste todo o arsenal.</small></span></label><div class="match-facts"><span>${icon('clock')} ROUNDS DE 1:55</span><span>${icon('flag')} PRIMEIRO A 7 VENCE</span></div><button class="primary start-match" data-action="start">INICIAR PARTIDA ${icon('arrow')}</button><div class="panel-note"><i class="status-dot"></i> PARTIDA OFFLINE • BOTS LOCAIS</div></aside></div></main>${this.footer()}`;
 }
 private inventory(loadout=false) {
  const weapon = WEAPONS.find(w=>w.id===this.selectedWeapon) || WEAPONS[0];
  const availableSkins = weaponSkins(weapon.id);
  const skin = SKINS.find(s=>s.id===this.selectedSkin) || SKINS[0];
  const equipped = this.skins[weapon.id] || 'default';
  const filtered=WEAPONS.filter(w=>this.filter==='all'||(this.filter==='rifle'?['RIFLE','PRECISÃO','SUBMETRALHADORA'].includes(w.type):this.filter==='pistol'?w.type==='PISTOLA':w.id==='knife'));
  return `${this.nav()}<main class="page-content inventory-content">${this.heading(loadout?'PERSONALIZAÇÃO / EQUIPAMENTOS':'COLEÇÃO DO OPERADOR',loadout?'SEU PRÓXIMO LOADOUT.':'FORÇA COM IDENTIDADE.',loadout?'Prepare seu acabamento favorito para a próxima operação.':'Acabamentos originais. Escolha um item para personalizar e inspecionar.')}<div class="inventory-toolbar"><div class="tab-row">${[['all','TODOS OS ITENS'],['rifle','RIFLES & SMGs'],['pistol','PISTOLAS'],['knife','FACAS']].map(([v,l])=>`<button class="${this.filter===v?'selected':''}" data-action="filter" data-value="${v}">${l}</button>`).join('')}</div><span>${WEAPONS.length} ITENS <b>•</b> ${SKINS.length} ACABAMENTOS</span></div><div class="inventory-layout"><section class="weapon-grid">${filtered.map(w=>{const s=SKINS.find(s=>s.id===(this.skins[w.id]||'default'))||SKINS[0];return `<button class="weapon-card ${this.selectedWeapon===w.id?'selected':''}" style="--skin:${s.color}" data-action="weapon" data-id="${w.id}"><span class="weapon-type">${w.type}<b>${w.team || 'AMBOS'}</b></span>${weaponSVG(w.id)}<div class="weapon-card-title"><strong>${w.name}</strong><small>${s.name}</small></div><span class="weapon-equipped">${icon('check')} EQUIPADO</span><span class="rarity-line"></span></button>`}).join('')}</section><aside class="skin-panel panel" style="--skin:${skin.color}"><span class="eyebrow">PERSONALIZAR ITEM</span><div class="skin-preview">${weaponSVG(weapon.id,skin.color)}<span>${weapon.tag}</span></div><span class="skin-rarity">${skin.rarity}</span><h2>${weapon.name}<br><span>${skin.name}</span></h2><p>${skin.desc}</p><label class="field-label">ACABAMENTO</label><div class="skin-swatches">${availableSkins.map(s=>`<button class="skin-swatch ${this.selectedSkin===s.id?'selected':''}" style="--swatch:${s.color}" data-action="skin" data-id="${s.id}" title="${s.name}" aria-label="Acabamento ${s.name}">${this.selectedSkin===s.id?icon('check'):''}</button>`).join('')}</div><button class="primary" data-action="equip" ${equipped===this.selectedSkin?'disabled':''}>${equipped===this.selectedSkin?'ACABAMENTO EQUIPADO':'EQUIPAR ACABAMENTO'} ${icon('check')}</button><button class="secondary" data-action="inspect" data-id="${weapon.id}" data-skin="${skin.id}">${icon('target')} INSPECIONAR EM 3D</button><div class="panel-note">ACABAMENTOS COSMÉTICOS • SEM VANTAGEM COMPETITIVA</div></aside></div></main>${this.footer()}`;
 }
 private settings() {
  const slider=(key:string,title:string,desc:string,min:number,max:number,step:number,suffix='')=>`<label class="setting-row"><span><strong>${title}</strong><small>${desc}</small></span><div class="setting-control"><input type="range" name="${key}" min="${min}" max="${max}" step="${step}" value="${this.values[key]}"><output data-output="${key}">${this.values[key]}${suffix}</output></div></label>`;
  return `${this.nav()}<main class="page-content settings-content">${this.heading('AJUSTES DO OPERADOR','DO SEU JEITO.','Ajuste a experiência. As alterações são salvas neste dispositivo.')}<div class="settings-layout"><section class="settings-panel panel"><div class="settings-section-title">${icon('mouse')} CONTROLES & MIRA</div>${slider('sensitivity','Sensibilidade do mouse','Precisão para cada movimento.',.2,3,.1)}${slider('fov','Campo de visão','Amplitude da câmera em primeira pessoa.',65,105,1,'°')}${slider('crosshairSize','Tamanho da mira','Defina a abertura da sua mira.',3,18,1)}<label class="setting-row"><span><strong>Cor da mira</strong><small>Visibilidade em qualquer cenário.</small></span><div class="color-control"><span class="crosshair-preview" style="color:${this.values.crosshair}">+</span><input type="color" name="crosshair" value="${this.values.crosshair}"></div></label><div class="settings-section-title">${icon('sound')} ÁUDIO</div>${slider('volume','Volume geral','Som do ambiente e da interface.',0,1,.05)}${slider('effects','Efeitos sonoros','Disparos, passos e impacto.',0,1,.05)}</section><section class="settings-panel panel"><div class="settings-section-title">${icon('monitor')} VÍDEO</div><label class="setting-row"><span><strong>Qualidade gráfica</strong><small>Equilíbrio entre imagem e desempenho.</small></span><select name="quality"><option value="low" ${this.values.quality==='low'?'selected':''}>BAIXA</option><option value="medium" ${this.values.quality==='medium'?'selected':''}>MÉDIA</option><option value="high" ${this.values.quality==='high'?'selected':''}>ALTA</option></select></label>${slider('scale','Escala de resolução','Resolução da renderização 3D.',.5,1.5,.1)}<label class="setting-row"><span><strong>Sombras dinâmicas</strong><small>Luz direcional e sombras do cenário.</small></span><input class="toggle" type="checkbox" name="shadows" ${this.values.shadows?'checked':''}></label><div class="settings-section-title controls-title">${icon('key')} MANUAL DE CAMPO</div><div class="controls-grid">${[['W A S D','Mover'],['MOUSE','Mirar / disparar'],['ESPAÇO','Pular'],['CTRL','Agachar'],['SHIFT','Andar'],['R','Recarregar'],['1 / 2 / 3','Trocar arma'],['4 / 5','Granadas / C4'],['Q','Arma anterior'],['B','Comprar'],['E','Plantar / desarmar'],['F','Inspecionar arma'],['G','Soltar arma'],['TAB','Placar'],['ESC','Pausar']].map(([k,v])=>`<span><kbd>${k}</kbd>${v}</span>`).join('')}</div></section></div><div class="settings-bottom"><button class="secondary" data-action="reset-settings">${icon('refresh')} RESTAURAR PADRÕES</button><span>Alterações aplicadas automaticamente.</span><button class="primary" data-action="nav" data-screen="${this.data.inMatch?'pause':'home'}">PRONTO ${icon('check')}</button></div></main>${this.footer()}`;
 }
 private pause() {
  return `<div class="modal-shade"><section class="pause-panel panel"><span class="eyebrow">OPERAÇÃO EM ESPERA</span><h1>RESPIRE.<br>REORGANIZE.</h1><p>A partida está pausada. O próximo movimento é seu.</p><button class="primary" data-action="resume">${icon('play')} VOLTAR AO COMBATE</button><button class="secondary" data-action="nav" data-screen="settings">${icon('gear')} CONFIGURAÇÕES</button><button class="secondary" data-action="restart">${icon('refresh')} REINICIAR PARTIDA</button><button class="secondary" data-action="home">${icon('home')} VOLTAR AO MENU</button><div class="pause-tip">ESC <span>VOLTAR À PARTIDA</span></div></section></div>`;
 }
 private buy() {
  const items = [
   {name:'EQUIPAMENTO',items:[{id:'armor',name:'Colete Kevlar',price:650,icon:'shield'},{id:'helmet',name:'Colete + capacete',price:1000,icon:'shield'},{id:'kit',name:'Kit de desarme',price:400,icon:'key'}]},
   {name:'PISTOLAS',items:WEAPONS.filter(w=>w.type==='PISTOLA')},
   {name:'RIFLES & SMGs',items:WEAPONS.filter(w=>w.type==='RIFLE'||w.id==='mp9')},
   {name:'PRECISÃO',items:WEAPONS.filter(w=>w.id==='awp')},
   {name:'GRANADAS',items:[{id:'he',name:'Explosiva HE',price:300,icon:'bomb'},{id:'smoke',name:'Granada de fumaça',price:300,icon:'bomb'},{id:'flash',name:'Granada de luz',price:200,icon:'sun'}]}
  ];
  return `<div class="buy-shade"><header class="buy-header"><div><span class="eyebrow">ZONA DE REABASTECIMENTO</span><h1>PREPARE O ARSENAL.</h1></div><div class="buy-cash"><small>SALDO DISPONÍVEL</small><strong>${cash(this.data.money)}</strong></div><button class="close-button" data-action="resume" title="Fechar compra">${icon('close')}</button></header><div class="buy-status"><span>${icon('clock')} TEMPO DE COMPRA <strong data-buy-time>${Math.ceil(this.data.buyTime || 0)}s</strong></span><span data-buy-reason>${this.data.reason?esc(this.data.reason):'Selecione um item para comprar e equipar.'}</span><span class="team-tag">TIME ${esc(this.data.team||'T')}</span></div><div class="buy-grid">${items.map(category=>`<section class="buy-category"><h2>${category.name}</h2>${category.items.map((w:any)=>{const wrongTeam=(!!w.team&&!!this.data.team&&w.team!==this.data.team)||(w.id==='kit'&&this.data.team==='T');const reason=this.data.buyTime<=0?'Período de compra encerrado':wrongTeam?'Disponível apenas para '+(w.team||'CT'):w.price>this.data.money?'Saldo insuficiente: '+cash(w.price):'Comprar '+w.name+' por '+cash(w.price);const unavailable=this.data.buyTime<=0||w.price>this.data.money||wrongTeam;return `<button class="buy-item ${unavailable?'unaffordable':''}" data-action="buy" data-id="${w.id}" title="${esc(reason)}" ${unavailable?'disabled':''}><span>${w.name}</span>${w.icon?icon(w.icon):weaponSVG(w.id)}<strong>${cash(w.price)}</strong>${w.team?`<small>${w.team}</small>`:''}</button>`}).join('')}</section>`).join('')}</div><footer class="buy-footer"><span><kbd>B</kbd> FECHAR COMPRA</span><span><kbd>ESC</kbd> VOLTAR AO COMBATE</span><span>${icon('info')} COMPRAS DISPONÍVEIS NO INÍCIO DO ROUND</span></footer></div>`;
 }
 private loading() {
  return `<div class="loading-screen">${this.miniMap('Dust II',0)}<div class="loading-content"><span class="eyebrow">INICIANDO OPERAÇÃO / 01</span><h1>DUST II</h1><p>DESARMAMENTO DE BOMBA <b>•</b> MARROCOS</p><div class="loading-track"><i></i></div><span class="loading-status">PREPARANDO CAMPO DE BATALHA<span>...</span></span><div class="loading-hint">${icon('info')} Controle o recuo com disparos curtos. Em movimento, sua precisão diminui.</div></div><div class="loading-bottom"><span>TACTICAL STRIKE 2</span><span>OPERADORES A CAMINHO</span></div></div>`;
 }
 private result() {
  const victory = this.data.victory;
  const winner = this.data.winner==='T'?'TERRORISTAS':'CONTRA-TERRORISTAS';
  const title = this.data.title || (victory===true?'VITÓRIA. MISSÃO CUMPRIDA.':victory===false?'DERROTA. VOLTE MAIS FORTE.':`${winner} VENCEM`);
  return `<div class="modal-shade"><section class="result-panel panel ${victory===false?'result-defeat':''}"><div class="result-emblem">${icon(victory===false?'flag':'shield')}</div><span class="eyebrow">OPERAÇÃO CONCLUÍDA / ${winner} VENCEM</span><h1>${esc(title)}</h1><p>${esc(this.data.reason || 'Cada round conta. A próxima missão espera por você.')}</p><div class="result-score"><span><small>TERRORISTAS</small>${this.data.score?.T ?? 0}</span><i>:</i><span><small>CONTRA-TERRORISTAS</small>${this.data.score?.CT ?? 0}</span></div><div class="result-stats"><span><strong>${this.data.kills ?? 0}</strong><small>ELIMINAÇÕES</small></span><span><strong>${this.data.deaths ?? 0}</strong><small>MORTES</small></span><span><strong>${((this.data.kills||0)/Math.max(1,this.data.deaths||0)).toFixed(2)}</strong><small>RELAÇÃO K / D</small></span></div><button class="primary" data-action="restart">NOVA OPERAÇÃO ${icon('refresh')}</button><button class="secondary" data-action="home">VOLTAR AO MENU ${icon('home')}</button></section></div>`;
 }
 private inspect() {
  const id=this.data.weapon || this.data.id || this.selectedWeapon;
  const w=WEAPONS.find(w=>w.id===id)||WEAPONS[0];
  const s=SKINS.find(s=>s.id===(this.data.skin || this.selectedSkin))||SKINS[0];
  return `<div class="inspect-screen" style="--skin:${s.color}"><div class="inspect-title"><span class="eyebrow">INSPEÇÃO DO ARSENAL / ${w.type}</span><h1>${w.name}<span> | ${s.name}</span></h1><p>COLEÇÃO TACTICAL STRIKE</p><i></i></div><div class="inspect-description"><span class="skin-rarity">${s.rarity}</span><p>${s.desc}</p><small>ACABAMENTO ORIGINAL • DESGASTE MÍNIMO</small></div><footer class="inspect-footer"><span>${icon('mouse')} MODELO 3D COM ROTAÇÃO AUTOMÁTICA</span><span>${w.tag}</span><button class="secondary" data-action="nav" data-screen="inventory">FECHAR ${icon('close')}</button></footer></div>`;
 }

 private hudHTML() {
  return `<div class="hud-vignette"></div><div class="hurt-overlay"></div><div class="flash-overlay"></div><div class="scope-overlay" hidden><div class="scope-glass"></div><div class="scope-lines"></div></div><div class="hud-top"><div class="team-number ct"><strong data-hud="ctAlive">5</strong><span>CT</span></div><div class="round-center"><strong data-hud="time">1:55</strong><div><b data-hud="ctScore">0</b><span>ROUND <i data-hud="round">1</i></span><b data-hud="tScore">0</b></div></div><div class="team-number t"><strong data-hud="tAlive">5</strong><span>T</span></div></div><div class="radar-wrap"><canvas id="radar" width="240" height="240"></canvas><div class="radar-center"></div><span class="radar-north">N</span></div><div class="hud-site" data-hud="site">BASE T</div><div class="hud-fps" data-hud="fps"></div><div class="kill-feed"></div><div class="round-notice" hidden><span class="round-notice-icon">${icon('shield')}</span><div><strong data-hud="phase"></strong><small data-hud="phaseDetail"></small></div></div><div class="bomb-notice" hidden>${icon('bomb')}<span>BOMBA PLANTADA</span><strong data-hud="bomb"></strong></div><div class="interaction" hidden><div><kbd>E</kbd><span data-hud="interaction"></span></div><div class="interaction-track"><i></i></div></div><div class="crosshair"><i></i><i></i><i></i><i></i><b></b></div><div class="hitmarker">×</div><div class="hud-bottom"><div class="hud-money"><strong data-hud="money">$ 16.000</strong><span><kbd>B</kbd> COMPRAR EQUIPAMENTO</span></div><div class="hud-health"><span class="health-icon">+</span><strong data-hud="health">100</strong><span class="hud-armor">${icon('shield')}<b data-hud="armor">0</b></span><div class="health-track"><i></i></div></div><div class="hud-team-emblem">${icon('shield')}</div><div class="hud-ammo"><strong data-hud="ammo">30</strong><span>/ <b data-hud="reserve">90</b></span><small data-hud="weapon">AK-47</small></div></div><div class="weapon-stack"><div class="weapon-stack-primary"><kbd>1</kbd>${weaponSVG('ak')}<span>RIFLE</span></div><div><kbd>2</kbd>${weaponSVG('glock')}<span>PISTOLA</span></div><div><kbd>3</kbd>${weaponSVG('knife')}<span>FACA</span></div><div class="hud-utility"><span data-hud="grenades"></span><b class="bomb-carrier" hidden>${icon('bomb')} C4</b></div></div><div class="hud-controls"><span><kbd>R</kbd> RECARREGAR</span><span><kbd>E</kbd> OBJETIVO</span><span><kbd>TAB</kbd> PLACAR</span></div>`;
 }
 updateHUD(data: any) {
  this.hudCache = {...this.hudCache,...data};
  const d=this.hudCache;
  if(this.screen==='buy'&&data.buyTime!==undefined){
   const timer=this.overlay.querySelector('[data-buy-time]');if(timer)timer.textContent=Math.max(0,Math.ceil(data.buyTime))+'s';
   if(data.buyTime<=0){this.overlay.querySelectorAll<HTMLButtonElement>('[data-action="buy"]').forEach(button=>{button.disabled=true;button.classList.add('unaffordable');button.title='Período de compra encerrado';});const status=this.overlay.querySelector('[data-buy-reason]');if(status)status.textContent='Período de compra encerrado. Volte ao combate.';}
  }
  const set=(key:string,value:any)=>{const el=this.hud.querySelector(`[data-hud="${key}"]`);if(el&&el.textContent!==String(value))el.textContent=String(value)};
  ['health','armor','ammo','reserve'].forEach(k=>set(k,Math.max(0,Math.ceil(d[k]||0))));
  set('money',cash(d.money));set('weapon',d.reloading?'RECARREGANDO...':d.weapon?.toUpperCase?.()||'');set('site',d.site||'DUST II');
  const seconds=Math.max(0,Math.ceil(d.time||0)); set('time',`${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`);
  set('ctScore',d.score?.CT??0);set('tScore',d.score?.T??0);set('ctAlive',d.alive?.CT??0);set('tAlive',d.alive?.T??0);set('round',d.round??(1+(d.score?.T||0)+(d.score?.CT||0)));
  set('fps',d.fps?`${Math.round(d.fps)} FPS`:'');
  (this.hud.querySelector('.health-track i') as HTMLElement).style.width=`${Math.max(0,Math.min(100,d.health||0))}%`;
  this.hud.classList.toggle('low-health',(d.health||0)<30);
  this.hud.classList.toggle('low-ammo',(d.ammo||0)<6);
  this.hud.classList.toggle('danger-time',seconds<15);
  const phase=this.hud.querySelector('.round-notice') as HTMLElement;
  const phaseText = typeof d.phase==='string'?d.phase:'';
  const texts:Record<string,string>={buy:'PREPARE-SE PARA O COMBATE',freeze:'PREPARE-SE PARA O COMBATE',warmup:'AQUECIMENTO',T:'TERRORISTAS VENCEM',CT:'CONTRA-TERRORISTAS VENCEM',dead:'VOCÊ FOI ELIMINADO',end:'ROUND CONCLUÍDO',intermission:'PRÓXIMO ROUND'};
  const showPhase=!!(phaseText && !['live','active','playing','round','combat'].includes(phaseText));
  phase.hidden=!showPhase;set('phase',texts[phaseText]||phaseText);set('phaseDetail',d.phaseDetail||(phaseText==='buy'||phaseText==='freeze'?'PRESSIONE B PARA COMPRAR EQUIPAMENTO':''));
  const bombEl=this.hud.querySelector('.bomb-notice') as HTMLElement;
  const planted=d.bomb&&(d.bomb===true||d.bomb.planted||d.bomb.state==='planted'||d.bomb.active||typeof d.bomb==='number');bombEl.hidden=!planted;
  if(planted)set('bomb',Math.ceil(typeof d.bomb==='number'?d.bomb:d.bomb===true?d.time:(d.bomb.time??d.bomb.timer??0))+'s');
  (this.hud.querySelector('.bomb-carrier') as HTMLElement).hidden=!d.hasBomb;
  const interaction=this.hud.querySelector('.interaction') as HTMLElement;interaction.hidden=!d.interaction;set('interaction',d.interaction||'');
  (this.hud.querySelector('.interaction-track i') as HTMLElement).style.width=`${Math.min(100,(d.progress||0)*(d.progress<=1?100:1))}%`;
  (this.hud.querySelector('.scope-overlay') as HTMLElement).hidden=!d.scoped;
  (this.hud.querySelector('.crosshair') as HTMLElement).hidden=!!d.scoped||d.health<=0;
  (this.hud.querySelector('.hurt-overlay') as HTMLElement).style.opacity=String(Math.min(.7,d.hurt||0));
  const hit=this.hud.querySelector('.hitmarker') as HTMLElement;hit.classList.toggle('active',!!d.hit);
  if(d.kills) { const feed=this.hud.querySelector('.kill-feed')!; const html=d.kills.slice(-5).reverse().map((k:any)=>`<div><b class="${k.team==='CT'?'ct':'t'}">${esc(k.killer)}</b><span>${esc(k.weapon||'▰')}</span><b>${esc(k.victim)}</b></div>`).join('');if(feed.innerHTML!==html)feed.innerHTML=html; }
  (this.hud.querySelector('.flash-overlay') as HTMLElement).style.opacity=String(Math.min(1,d.flash||0));
  if(d.grenades) set('grenades',Array.isArray(d.grenades)?d.grenades.map((g:string)=>g.toUpperCase()).join('  '):typeof d.grenades==='object'?Object.entries(d.grenades).filter(([,v])=>Number(v)>0).map(([k,v])=>`${k.toUpperCase()} ×${v}`).join('  '):d.grenades);
  const weaponId=WEAPONS.find(w=>w.name.toLowerCase()===String(d.weapon||'').toLowerCase()||w.id===d.weapon)?.id;
  if(weaponId) { const primary=this.hud.querySelector('.weapon-stack-primary')!;if(primary.getAttribute('data-weapon')!==weaponId){primary.setAttribute('data-weapon',weaponId);primary.innerHTML=`<kbd>${weaponId==='knife'?'3':['glock','usp','deagle'].includes(weaponId)?'2':'1'}</kbd>${weaponSVG(weaponId)}<span>${esc(d.weapon)}</span>`} }
  const now=performance.now();if(d.map&&now-this.lastMap>80){this.drawRadar(d.map);this.lastMap=now;}
 }
 private drawRadar(map:any) {
  const canvas=this.hud.querySelector('#radar') as HTMLCanvasElement;
  const ctx=canvas.getContext('2d');if(!ctx)return;
  const size=240, extent=map.extent||64, scale=210/extent;
  ctx.clearRect(0,0,size,size);ctx.save();ctx.beginPath();ctx.arc(120,120,117,0,Math.PI*2);ctx.clip();ctx.fillStyle='rgba(19,29,36,.75)';ctx.fillRect(0,0,size,size);
  const px=(x:number)=>120+x*scale,pz=(z:number)=>120+z*scale;
  ctx.strokeStyle='rgba(222,230,221,.12)';ctx.lineWidth=.8;
  for(let n=0;n<=240;n+=24){ctx.beginPath();ctx.moveTo(n,0);ctx.lineTo(n,240);ctx.moveTo(0,n);ctx.lineTo(240,n);ctx.stroke()}
  ctx.fillStyle='#81847b';ctx.strokeStyle='#a3a394';
  for(const c of map.colliders||[]){ const minX=c.minX??c.x1??((c.x??0)-(c.w??c.width??1)/2),maxX=c.maxX??c.x2??((c.x??0)+(c.w??c.width??1)/2),minZ=c.minZ??c.z1??((c.z??0)-(c.d??c.depth??1)/2),maxZ=c.maxZ??c.z2??((c.z??0)+(c.d??c.depth??1)/2);ctx.fillRect(px(minX),pz(minZ),(maxX-minX)*scale,(maxZ-minZ)*scale); }
  ctx.font='bold 19px Arial';ctx.textAlign='center';ctx.textBaseline='middle';
  const sites=map.sites||[];const siteList=Array.isArray(sites)?sites:Object.entries(sites).map(([name,v]:any)=>({...v,name}));
  siteList.forEach((s:any,i:number)=>{ctx.fillStyle='rgba(226,173,78,.2)';ctx.beginPath();ctx.arc(px(s.x),pz(s.z),13,0,Math.PI*2);ctx.fill();ctx.fillStyle='#edc580';ctx.fillText(s.name||s.id||(i===0?'A':'B'),px(s.x),pz(s.z));});
  (map.bots||[]).forEach((b:any)=>{if(b.health<=0||b.alive===false)return;ctx.fillStyle=b.team===map.player?.team?'#8dd5ec':'#eac170';ctx.beginPath();ctx.arc(px(b.x??b.position?.x??0),pz(b.z??b.position?.z??0),3.3,0,Math.PI*2);ctx.fill()});
  const p=map.player;if(p){ctx.save();ctx.translate(px(p.x),pz(p.z));ctx.rotate(-(p.yaw||0));ctx.fillStyle='#a9eacb';ctx.shadowColor='#a9eacb';ctx.shadowBlur=8;ctx.beginPath();ctx.moveTo(0,-8);ctx.lineTo(5,5);ctx.lineTo(0,2);ctx.lineTo(-5,5);ctx.closePath();ctx.fill();ctx.restore()}
  ctx.restore();ctx.strokeStyle='rgba(185,214,219,.5)';ctx.lineWidth=2;ctx.beginPath();ctx.arc(120,120,117,0,Math.PI*2);ctx.stroke();
 }
 updateScoreboard(rows: any[],score: any={}) {
  this.scoreboard.innerHTML=`<section class="scoreboard panel"><div class="scoreboard-head"><div><span class="eyebrow">DUST II / DESARMAMENTO</span><h1>RELATÓRIO DE COMBATE</h1></div><div><b class="ct">${score.CT??0}</b><span>:</span><b class="t">${score.T??0}</b></div></div><div class="scoreboard-table"><div class="scoreboard-row scoreboard-label"><span>OPERADOR</span><span>K</span><span>A</span><span>M</span><span>$</span><span>PTS</span></div>${['CT','T'].map(team=>`<div class="scoreboard-team ${team.toLowerCase()}">${team==='CT'?'CONTRA-TERRORISTAS':'TERRORISTAS'}</div>${rows.filter(r=>r.team===team).map(r=>`<div class="scoreboard-row ${r.player||r.isPlayer?'is-player':''} ${r.alive===false||r.health<=0?'is-dead':''}"><span>${r.alive===false||r.health<=0?icon('skull'):icon('user')} ${esc(r.name||r.id)} ${r.player||r.isPlayer?'<small>VOCÊ</small>':''}</span><span>${r.kills??0}</span><span>${r.assists??0}</span><span>${r.deaths??0}</span><span>${cash(r.money)}</span><span>${r.score??(r.kills||0)*2}</span></div>`).join('')}`).join('')}</div><footer>SEGURE <kbd>TAB</kbd> PARA EXIBIR O PLACAR</footer></section>`;
 }
 setScoreboard(visible: boolean) { this.scoreboard.hidden=!visible; }
 toast(text: string) {
  this.notice.textContent=text;this.notice.classList.add('visible');clearTimeout(this.toastTimer);this.toastTimer=setTimeout(()=>this.notice.classList.remove('visible'),3300);
 }
 private click(e: MouseEvent) {
  const button=(e.target as HTMLElement).closest<HTMLElement>('[data-action]');if(!button||button.hasAttribute('disabled'))return;
  const a=button.dataset.action;
  if(a==='nav'){this.actions.navigate?.(button.dataset.screen);return}
  if(a==='config'){const key=button.dataset.key!;(this.config as any)[key]=key==='size'?Number(button.dataset.value):button.dataset.value;this.show('play',this.data);return}
  if(a==='start'){this.actions.start?.({...this.config});return}
  if(a==='map'){this.toast('Dust II selecionado. Prepare a sua operação.');return}
  if(a==='filter'){this.filter=button.dataset.value!;this.show(this.screen,this.data);return}
  if(a==='weapon'){this.selectedWeapon=button.dataset.id!;this.selectedSkin=this.skins[this.selectedWeapon]||'default';this.show(this.screen,this.data);return}
  if(a==='skin'){this.selectedSkin=button.dataset.id!;this.show(this.screen,this.data);return}
  if(a==='equip'){this.skins[this.selectedWeapon]=this.selectedSkin;this.actions.equip?.(this.selectedWeapon,this.selectedSkin);this.data.skins={...this.skins};this.show(this.screen,this.data);this.toast(`${WEAPONS.find(w=>w.id===this.selectedWeapon)?.name} | ${SKINS.find(s=>s.id===this.selectedSkin)?.name} equipado`);return}
  if(a==='inspect'){this.actions.inspect?.(button.dataset.id,button.dataset.skin);return}
  if(a==='buy'){this.actions.buy?.(button.dataset.id);return}
  if(a==='reset-settings'){this.values={sensitivity:1,volume:.5,effects:.8,fov:80,quality:'medium',shadows:true,scale:1,crosshair:'#98e8c2',crosshairSize:8};this.actions.settings?.({...this.values});this.show('settings');this.toast('Configurações padrão restauradas.');return}
  if(a&&this.actions[a])this.actions[a]();
 }
 private input(e: Event) {
  const input=e.target as HTMLInputElement;
  if(this.screen!=='settings'||!input.name)return;
  this.values[input.name]=input.type==='checkbox'?input.checked:input.type==='range'?Number(input.value):input.value;
  const output=this.root.querySelector(`[data-output="${input.name}"]`);if(output)output.textContent=input.value+(input.name==='fov'?'°':'');
  if(input.name==='crosshair'){const preview=this.root.querySelector('.crosshair-preview') as HTMLElement;if(preview)preview.style.color=input.value}
  this.actions.settings?.({...this.values});
 }
 private change(e: Event) {
  const input=e.target as HTMLInputElement;
  if(input.name==='practice')this.config.practice=input.checked;
  if(this.screen==='settings')this.input(e);
 }
}
