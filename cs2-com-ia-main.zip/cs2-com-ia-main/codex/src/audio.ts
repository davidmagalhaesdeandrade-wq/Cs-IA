import { Vector3 } from 'three';
export class AudioSystem {
    context: AudioContext;
    master: GainNode;
    volume = .5;
    effects = .8;
    listener = new Vector3();
    yaw = 0;
    noise: AudioBuffer;
    init() { if (!this.context) {
        this.context = new AudioContext();
        this.master = this.context.createGain();
        this.master.connect(this.context.destination);
        this.noise = this.context.createBuffer(1, this.context.sampleRate, this.context.sampleRate);
        const d = this.noise.getChannelData(0);
        for (let i = 0; i < d.length; i++)
            d[i] = Math.random() * 2 - 1;
    } if (this.context.state === 'suspended')
        this.context.resume(); this.master.gain.value = this.volume * this.effects; }
    out(pos?: Vector3) { if (!pos)
        return this.master; const delta = pos.clone().sub(this.listener), dist = delta.length(); const gain = this.context.createGain(); gain.gain.value = Math.min(1, 3 / Math.max(3, dist)); const pan = this.context.createStereoPanner(); pan.pan.value = Math.max(-1, Math.min(1, (delta.x * Math.cos(this.yaw) - delta.z * Math.sin(this.yaw)) / Math.max(1, dist))); gain.connect(pan); pan.connect(this.master); return gain; }
    tone(freq: number, duration = .12, type: OscillatorType = 'sine', volume = .12, pos?: Vector3, end?: number) { if (!this.context)
        return; const t = this.context.currentTime, o = this.context.createOscillator(), g = this.context.createGain(); o.type = type; o.frequency.setValueAtTime(freq, t); if (end)
        o.frequency.exponentialRampToValueAtTime(end, t + duration); g.gain.setValueAtTime(volume, t); g.gain.exponentialRampToValueAtTime(.0001, t + duration); o.connect(g); g.connect(this.out(pos)); o.start(t); o.stop(t + duration + .01); o.onended = () => { o.disconnect(); g.disconnect(); }; }
    burst(duration: number, volume: number, cutoff: number, pos?: Vector3) { if (!this.context)
        return; const t = this.context.currentTime, s = this.context.createBufferSource(), g = this.context.createGain(), f = this.context.createBiquadFilter(); s.buffer = this.noise; f.type = 'lowpass'; f.frequency.value = cutoff; g.gain.setValueAtTime(volume, t); g.gain.exponentialRampToValueAtTime(.001, t + duration); s.connect(f); f.connect(g); g.connect(this.out(pos)); s.start(t, Math.random() * .5, duration); s.onended = () => { s.disconnect(); f.disconnect(); g.disconnect(); }; }
    shoot(id: string, pos?: Vector3) { if (!this.context)
        return; const heavy = id === 'awp', pistol = ['glock', 'usp'].includes(id); this.burst(heavy ? .6 : pistol ? .13 : .22, heavy ? .75 : pistol ? .26 : .45, heavy ? 2200 : id === 'm4s' || id === 'usp' ? 1400 : 4700, pos); this.tone(heavy ? 100 : pistol ? 220 : 140, .12, 'triangle', .4, pos, 35); }
    step(pos?: Vector3) { this.burst(.06, .065, 900, pos); this.tone(90, .045, 'triangle', .045, pos); }
    click() { this.tone(700, .045, 'sine', .08); }
    reload() { this.burst(.12, .16, 3800); this.tone(540, .08, 'triangle', .1); }
    hit() { this.tone(1100, .045, 'triangle', .1); }
    beep() { this.tone(1100, .085, 'square', .05); }
    explosion(pos?: Vector3) { this.burst(1.5, .9, 1000, pos); this.tone(80, .9, 'sawtooth', .45, pos, 18); }
    round(win: boolean) { [0, .16, .32].forEach((delay, i) => setTimeout(() => this.tone((win ? [440, 550, 660] : [330, 280, 220])[i], .3, 'triangle', .12), delay * 1000)); }
}
