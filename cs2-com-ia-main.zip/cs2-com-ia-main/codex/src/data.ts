export type Team = 'T' | 'CT';
export const other = (t: Team): Team => t === 'T' ? 'CT' : 'T';
export interface WeaponData {
    name: string;
    price: number;
    damage: number;
    mag: number;
    reserve: number;
    rate: number;
    reload: number;
    auto: boolean;
    spread: number;
    recoil: number;
    slot: number;
    speed: number;
}
export const WEAPONS: Record<string, WeaponData> = {
    ak: { name: 'AK-47', price: 2700, damage: 36, mag: 30, reserve: 90, rate: .105, reload: 2.4, auto: true, spread: .0015, recoil: .022, slot: 1, speed: 4.7 },
    m4: { name: 'M4A4', price: 3000, damage: 33, mag: 30, reserve: 90, rate: .09, reload: 2.8, auto: true, spread: .0012, recoil: .016, slot: 1, speed: 4.8 },
    m4s: { name: 'M4A1-S', price: 2900, damage: 35, mag: 20, reserve: 80, rate: .1, reload: 2.6, auto: true, spread: .001, recoil: .013, slot: 1, speed: 4.8 },
    awp: { name: 'AWP', price: 4750, damage: 115, mag: 5, reserve: 30, rate: 1.35, reload: 3.2, auto: false, spread: .008, recoil: .05, slot: 1, speed: 3.8 },
    glock: { name: 'Glock-18', price: 200, damage: 28, mag: 20, reserve: 100, rate: .16, reload: 2.1, auto: false, spread: .003, recoil: .012, slot: 2, speed: 5.1 },
    usp: { name: 'USP-S', price: 200, damage: 35, mag: 12, reserve: 36, rate: .19, reload: 2.2, auto: false, spread: .0018, recoil: .017, slot: 2, speed: 5.1 },
    deagle: { name: 'Desert Eagle', price: 700, damage: 53, mag: 7, reserve: 35, rate: .27, reload: 2.2, auto: false, spread: .002, recoil: .045, slot: 2, speed: 4.9 },
    mp9: { name: 'MP9', price: 1250, damage: 26, mag: 30, reserve: 120, rate: .075, reload: 2.1, auto: true, spread: .004, recoil: .012, slot: 1, speed: 5.2 },
    knife: { name: 'Faca tática', price: 0, damage: 60, mag: 0, reserve: 0, rate: .5, reload: 0, auto: false, spread: 0, recoil: 0, slot: 3, speed: 5.8 },
    c4: { name: 'C4', price: 0, damage: 0, mag: 0, reserve: 0, rate: 1, reload: 0, auto: false, spread: 0, recoil: 0, slot: 5, speed: 5 },
    he: { name: 'Granada HE', price: 300, damage: 90, mag: 1, reserve: 0, rate: 1, reload: 0, auto: false, spread: 0, recoil: 0, slot: 4, speed: 5 },
    smoke: { name: 'Smoke', price: 300, damage: 0, mag: 1, reserve: 0, rate: 1, reload: 0, auto: false, spread: 0, recoil: 0, slot: 4, speed: 5 },
    flash: { name: 'Flashbang', price: 200, damage: 0, mag: 1, reserve: 0, rate: 1, reload: 0, auto: false, spread: 0, recoil: 0, slot: 4, speed: 5 }
};
export const PRICES: Record<string, number> = { ...Object.fromEntries(Object.entries(WEAPONS).map(([k, v]) => [k, v.price])), armor: 650, helmet: 1000, kit: 400 };
export const defaults = { sensitivity: 1, volume: .5, effects: .8, fov: 80, quality: 'medium', shadows: true, scale: 1, crosshair: '#98e8c2', crosshairSize: 8 };
export function readStore<T>(key: string, fallback: T): T { try {
    return { ...fallback, ...JSON.parse(localStorage.getItem(key) || '{}') };
}
catch {
    return fallback;
} }
export function saveStore(key: string, value: any) { try {
    localStorage.setItem(key, JSON.stringify(value));
}
catch { } }
