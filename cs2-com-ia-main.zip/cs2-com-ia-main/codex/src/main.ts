import './style.css';
import { Game } from './game';
try {
    const game = new Game();
    (window as any).game = game;
}
catch (error) {
    console.error(error);
    document.getElementById('app')!.innerHTML = '<div style="background:#172027;color:#f4e5c8;padding:60px;font:20px system-ui"><h1>Não foi possível iniciar o WebGL</h1><p>Abra em Chrome ou Edge com aceleração de hardware ativada.</p><pre>' + String(error) + '</pre></div>';
}
