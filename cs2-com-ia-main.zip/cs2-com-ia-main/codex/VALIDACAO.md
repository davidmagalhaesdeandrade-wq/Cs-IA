# Validação — 20 de outubro de 2026

## Verificações executadas

- `npm.cmd run build`: TypeScript e build de produção aprovados.
- `npm.cmd test`: **14 testes aprovados**, cobrindo regras de rounds, economia, armadura, pathfinding, colisão, acesso físico aos dois sites e raycasts em arcos.
- `npm.cmd run test:browser`: **16 verificações aprovadas no Microsoft Edge**, incluindo ausência de erros fatais. Relatório: `artifacts/browser-results.json`.
- `npm.cmd run test:autoplay`: partida completa natural com bots em tempo acelerado, seed 2. Resultado **T 7 × 4 CT**, **11 rounds**, **7 plantios** e **2 desarmes**. Duração simulada: **839,8 segundos**. Nenhum bot permanentemente preso e nenhum erro fatal. Relatório: `artifacts/autoplay.json`.
- Inspeção visual em 1600×900 e 1280×720. Menus e compras não apresentam controles ativos fora da área visível em 1280×720.

## Fluxos de navegador

Menu e seleção de mapas; skins persistidas e visor 3D; configurações reais de câmera/renderização; criação de 3v3; compra e saldo; WASD, pulo e agachamento; pointer lock e mouse look; pausa com timers congelados; tiro real por raycast e eliminação; recarga e reserva; faca/rifle/inspeção; placar; plantio pela interação; manutenção do round depois que todos os T morrem com C4 plantada; explosão e pontuação; desarme CT; economia padrão e compra fora do spawn; arma solta/recolhida; smoke, flash e HE; movimento e dano dos bots; tela final e retorno ao menu.

Os testes de objetivos usam o próprio sistema de interação e regras com relógio acelerado e posicionamento controlado dos atores. O teste de autoplay, separadamente, deixa os bots navegarem, atirarem, plantarem e desarmarem sem forçar a vitória. O humano fica inativo/eliminado como espectador nessa simulação.

## Evidências visuais

- `artifacts/home.png` — menu e personagem 3D.
- `artifacts/maps.png` — mapas e configurações.
- `artifacts/inspect.png` — AK dourada no visor de itens.
- `artifacts/gameplay.png` — FPS, arma, site A e HUD.
- `artifacts/ui-*.png` — inspeção dos menus em 1280×720.

As capturas não representam um benchmark de desempenho. O FPS depende da GPU, da resolução e das configurações. A tentativa de abrir a prévia incorporada no chat retornou navegador indisponível; a execução e os testes foram realizados no Edge local.

O build emite apenas o aviso de tamanho do chunk do Three.js (aproximadamente 526 kB sem compressão); isso não impede a execução e a biblioteca está armazenada localmente.
