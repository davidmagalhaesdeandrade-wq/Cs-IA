@echo off
cd /d "%~dp0"
if not exist node_modules (
  call npm.cmd install --no-audit --no-fund --cache .npm-cache
  if errorlevel 1 exit /b 1
)
start "" /b powershell.exe -NoProfile -WindowStyle Hidden -Command "$taskUrl='http://127.0.0.1:5173'; for($taskAttempt=0;$taskAttempt -lt 30;$taskAttempt++){try{if((Invoke-WebRequest -UseBasicParsing -Uri $taskUrl -TimeoutSec 1).StatusCode -eq 200){Start-Process $taskUrl;break}}catch{};Start-Sleep -Milliseconds 500}"
call npm.cmd run dev
