# Tactical Strike 2

FPS 3D local inspirado na experiência de Counter-Strike, com mapa próprio inspirado no conceito de Dust II. Código, modelos, texturas e sons originais gerados proceduralmente. Todos os arquivos do projeto ficam nesta pasta `Codex`.

## Abrir no Windows

Requer Node.js 22.12 ou superior e Chrome/Edge com WebGL e aceleração de hardware.

**Dê dois cliques em `iniciar.bat`.** Ele instala dependências caso necessário, inicia o servidor e abre o navegador. Mantenha o terminal aberto enquanto joga. A primeira instalação usa a internet; depois o jogo funciona sem internet, servido pelo seu computador.

Também é possível executar no PowerShell:

```powershell
cd 'D:\video yotubue\Codex'
npm.cmd install
npm.cmd run dev
```

Abra **http://127.0.0.1:5173**. Usar `npm.cmd` evita depender da política de execução de scripts PowerShell. No terminal CMD, `npm install` e `npm run dev` também funcionam.

## Primeiro combate

1. Em **Inventário**, selecione AK-47, escolha um acabamento e equipe. A escolha fica salva no navegador. **Inspecionar** abre o modelo 3D: arraste para girar e use a roda do mouse para aproximar.
2. Em **Jogar**, selecione Dust II, time, dificuldade e 1v1, 3v3 ou 5v5. Os outros sete mapas estão explicitamente em desenvolvimento.
3. **Economia de treino** começa com $16.000 para testar o arsenal; desative para começar com $800.
4. No spawn, pressione **B**, compre e feche a compra. Os primeiros 15 segundos são de preparação. Os disparos ficam liberados quando o combate começa.
5. Como Terrorista, você recebe a C4. Use o radar para chegar ao site A ou B, pare e segure **E** por 3,2 segundos. Defenda por 40 segundos. Como CT, aproxime-se da bomba e segure **E** por 10 segundos, ou 5 com kit.
6. O primeiro time a vencer 7 rounds encerra a partida. **Esc** pausa de verdade, inclusive bots e temporizadores.

## Controles

| Tecla | Ação |
|---|---|
| WASD / mouse | Mover / olhar |
| Botão esquerdo | Disparar, atacar com faca ou lançar granada |
| Botão direito | Mira secundária; luneta da AWP |
| R | Recarregar |
| Espaço / Ctrl / Shift | Pular / agachar / andar |
| 1 / 2 / 3 | Primária / pistola / faca |
| 4 / 5 | Alternar granadas / C4 |
| Q / roda do mouse | Arma anterior / percorrer equipamentos |
| F | Animação de inspeção |
| B | Compra no spawn, durante preparação |
| E | Segurar para plantar/desarmar; recolher arma próxima |
| G | Soltar arma |
| Tab | Placar enquanto mantido pressionado |
| Esc | Pausar / liberar cursor |

## Implementado

- Mundo WebGL real, câmera FPS, aceleração, gravidade, salto, agachamento, colisões e deslizamento contra paredes.
- Mapa com spawns, mid, portas, longa, passagem curta, túneis e dois bombsites conectados; arcos, casas, texturas locais, caixotes, barris, palmeiras, cabos e iluminação solar com sombras.
- Personagens T/CT com animações procedurais; bots com navegação A*, reação e precisão por dificuldade, verificação de visão, ataques, plantio e desarme.
- AK-47, M4A4, M4A1-S, AWP, Glock-18, USP-S, Desert Eagle, MP9, faca e C4 com modelos 3D, atributos, recarga, recoil, dispersão e animações.
- Três acabamentos cada para AK-47, M4A4/M4A1-S e AWP, equipáveis e persistidos; inspeção 3D em depósito iluminado.
- HE com dano radial, flash com cegueira por direção/distância e smoke que bloqueia a visão dos bots.
- Rounds, dinheiro, compras, recompensas, HUD, radar, kill feed, placar, conclusão e reinício de partida.
- Áudio sintetizado, direção e atenuação de sons, passos, impactos, marcas de bala, efeitos de explosão e configurações persistidas.

## Simplificações e limites

- É uma recriação independente simplificada; não usa modelos, sons, logotipos ou código extraídos do jogo da Valve.
- O mapa preserva o conceito de três rotas e sites, sem reproduzir a planta ou a escala exata de Dust II. O piso principal é plano; não há sistema completo de escadarias/catwalk elevado.
- Modelos, animações e materiais são procedurais e estilizados, sem captura de movimento, ragdolls físicos ou qualidade fotorrealista.
- IA usa uma grade de navegação e decisões simples. Cobertura é aproximada; não há estratégias de equipe avançadas, penetração de paredes ou física balística completa. Não há fogo amigo.
- A bomba de um Terrorista eliminado é transferida para um companheiro vivo. Bots não fazem compras econômicas individuais; usam rifles de sua equipe e recarga própria.
- Granadas usam colisão e fumaça aproximadas. A pausa é local, e não existe multiplayer.
- Os sete mapas adicionais não são jogáveis. Armas opcionais além do arsenal listado não foram implementadas. Não há progressão de XP: patente e perfil do menu são fictícios.
- O botão Sair encerra a sessão e informa que a aba pode ser fechada; navegadores impedem que uma página feche uma aba aberta pelo usuário.

## Build e testes

```powershell
npm.cmd run build
npm.cmd test
npm.cmd run preview -- --port 4173
```

Com a prévia rodando em outro terminal:

```powershell
npm.cmd run test:browser
npm.cmd run test:autoplay
```

Os testes de navegador usam o Microsoft Edge instalado. `TEST_URL` pode apontar para outra porta. Evidências ficam em `artifacts/`.

Os testes de regras e navegação verificam vitória após plantio, desarme, explosão, armadura, economia, colisões, rotas físicas aos sites e passagem dos disparos por arcos. A suíte de navegador executa menus, skins, renderização, compra, mouse com pointer lock, WASD, salto, agachamento, combate, munição, recarga, pausa, plantio, desarme e conclusão. Para os objetivos, acelera o relógio e posiciona atores via estado interno, sem esperar minutos de cada round. O teste de autoplay roda bots e regras em tempo acelerado sem forçar vencedores.

O objetivo de 60 FPS depende da GPU e da resolução; use qualidade baixa e escala de renderização menor nas configurações se necessário.

## Estrutura

`src/game.ts` integra estados, jogador, combate, bots e rounds. `world.ts` cria o mapa e colisores; `navigation.ts` faz A* e movimentação; `models.ts` cria e anima os modelos; `presentation.ts` cria o visor 3D; `ui.ts` e `style.css` apresentam menus/HUD; `audio.ts`, `rules.ts` e `data.ts` separam áudio, regras e dados.

Referências de apresentação: [Counter-Strike 2](https://www.counter-strike.net/cs2). Renderização: [Three.js](https://threejs.org/docs/). Dependências e licenças em `THIRD_PARTY.md`.
